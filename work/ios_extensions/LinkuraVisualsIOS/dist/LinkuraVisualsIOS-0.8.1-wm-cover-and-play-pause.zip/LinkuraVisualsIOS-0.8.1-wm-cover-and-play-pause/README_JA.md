# LinkuraVisualsIOS 0.8.1 WM固定カバー抑止・再生停止ボタン版

Link! Like! Love Live! のiOS/iPadOS版に、映像品質・描画負荷・カメラ操作・
iPadレイアウト調整・活動記録の表示制御を追加するLiveContainer用Tweakです。

このビルドは、ネイティブ実体が **5.0.1** で、API向け表示を **5.1.0** に
合わせたIPA専用です。ネイティブ実体が5.1.0の別IPAには使用しないでください。

0.7.0のAFTER処理は、実際にはstaticである
`SchoolConnectArchiveListView.EnterToLiveScene`をinstanceメソッドとして接続し、
ネイティブ引数を1つずらしていたため、WM選択時にクラッシュする可能性がありました。
0.7.1ではAFTER修復用の5フックをコンパイル時に完全停止し、通常のWM再生、
カメラパネル、シークバー、縦横画面処理を復旧しました。0.7.1は安定した
ロールバック版として保持します。0.7.0は使用しないでください。

0.7.2では、`EnterToLiveScene`を正しいstatic ABI
`(LiveArchiveItemModel, MethodInfo*)`で接続し直したうえで、正規所持済み
With×MEETS AFTERが誤って未解放と判定される場合だけを補正します。
ただし、一覧の`LiveInfo[]`型確認で、利用していたResolverの
`Il2CppClass`内部レイアウトとUnity 2022.3.62Fの実際のレイアウトが一致せず、
誤ったアドレスをクラスとして参照していました。このためWM一覧を開いた直後に
クラッシュすることがあり、0.7.2は使用中止です。

0.7.3では、配列クラスの内部フィールドを一切参照せず、IL2CPPの公開API
`il2cpp_array_class_get`が返す`LiveInfo[]`クラスと一覧配列のクラス自体を
直接比較します。これにより、Resolverのバージョン依存な
`m_pElementClass`オフセットを通るクラッシュ経路を除去しました。
併せて、iPadで有効になる横画面ポップアップ補正の`BasePopup.OpenAsync`を、
5.0.1の実際のABIどおり16バイトの`UniTask`戻り値と`MethodInfo*`引数で接続し、
戻り値の一部を失う可能性があった旧宣言を修正しました。
それ以外のAFTER修復範囲は0.7.2と同じで、
一覧応答、選択モデル、入場要求、応答キャッシュを同じ
`archives_id` / `live_id`で一回限りに照合し、IL2CPPの正確なクラスと
バッキングフィールドを確認できた場合だけ
`GetWithArchiveDataResponse.<HasExtraAdmission>k__BackingField`を
`false`から`true`へ補正します。一般的なプロパティ呼び出しや
`List<T>.get_Count/get_Item`には依存しません。証拠が不足・不一致・曖昧な場合は
何も変更せず純正処理へ戻ります。

0.7.4では詳細応答内のポイントからAFTER到達を再計算していましたが、一覧に表示される
正規☆数と、詳細再生画面のセッションポイントが別管理であるため、一覧が☆4でも
詳細側が☆0〜2になるケースを修復できませんでした。

0.7.5では、純正WM一覧が構築された後の
`GetArchiveListResponse.LiveInfo`から、`LiveType=WithMeets`かつ
正規AFTER到達済みの行だけを記録します。詳細取得時は
`GetWithArchiveDataRequest.ArchivesId`を同じ一覧行へ完全一致で逆引きし、
30秒・1回限りの取引として詳細応答へ引き継ぎます。詳細応答にも実際のExtra
チャプターと、通常部分より長いExtra込み再生時間が存在する場合だけ、誤った
`HasExtraAdmission=false`を`true`へ補正します。WM以外、ID不一致、重複ID、
一覧未取得、期限切れ、応答矛盾では何も変更しません。再生時間、スター数、
必要スター数、購入状態、`HasExtra`は変更しません。

0.7.6では、0.7.5で完全一致検証した一覧行の正規
`HasExtraAdmission=true`と、その一覧行に対応する同じ詳細応答を、
その応答を保持する`WithConnectModelsFactory`の生成スコープ内だけで
プレイヤーの`GiftPointModel`へ引き継ぎます。プレイヤーモデル側でも
`HasExtra`とAFTER必要スター数が検証済み一覧行に一致する場合に限り、生成時に
失われた入場真偽値だけを一度だけ`false`から`true`へ補正します。スター数、
現在ポイント、報酬区間、必要スター数（閾値）、`HasExtra`、イベント種別は
読み取りと照合にだけ使用し、値そのものは変更しません。未所持AFTERを解放する
機能ではなく、一覧・詳細応答の完全一致証拠がない場合は純正値を維持します。

0.7.7では、WM/IARCの全長が50分ある一方で、純正シーク上限が固定映像区間の
29分（`0.579937...`）に設定される不一致を修復します。WMアーカイブかつ
`StreamingIarc`と確認できたセッションだけ、正の1未満のシーク上限を
全長`1.0`へ補正します。初期化時の`0`、通常WM/HLS、活動記録、Fes、
実際の全長・再生位置・AFTER入場判定は変更しません。

0.7.8では、0.7.7で表示上のシーク範囲を全長へ広げた後も、再生モデル内部の
`playableLengthRate`が固定映像区間の約29/50のまま残る不一致を修復しました。
対象WM/IARCセッションの正確な`LiveConnectPlayPositionModel`だけを照合し、
初期化時と後続更新時の再生可能率を全長`1.0`へ同期します。REPLAYパネルを
直接隠す処理や独立した一時停止処理は追加していません。ただし一部の遷移では、
この内部率とは独立した純正REPLAY表示判定が固定映像区間の終端で成立するため、
29分付近の中央`REPLAY`表示・暗転を止められませんでした。

0.7.9では、純正`ArchiveReplayButtonPresenter`の正確な入れ子クロージャにある
REPLAY表示判定を接続し、まず純正判定を呼び出します。その結果が`true`で、かつ
現在有効な同一WM/IARCセッションの`LiveConnectControlModel`と完全一致した場合
だけ、戻り値を`false`へ変更します。これにより、中央`REPLAY`表示と同じルートに
含まれる黒色0.6の暗転・入力遮断用raycastをまとめて非表示にします。
時刻、シーク範囲、一時停止、終端状態、`GameObject`は変更しません。
通常WM/HLS、活動記録、Fes、AFTER入場判定にも適用しません。
この設定が`true`の間は純正の実終端でもREPLAY表示を隠します。実終端の純正表示へ
戻す場合は`WithMeets.Archive.IarcReplayOverlay.Suppress=false`にしてください。

0.8.0では、29分付近の判定が0.7.9のREPLAY用クロージャへ到達する前に、
`LiveConnectPlayPositionModel.IsPlayToEnd`内の
`SeekTime >= floor(ContentsLength * PlayableLengthRate)`で短絡していたことを
修正します。まず純正`IsPlayToEnd`を呼び、その結果が`true`で、設定が有効、
かつ現在再生中のWM/IARCセッションの
`LiveConnectPlayPositionModel`実体と完全一致する場合だけ`false`へ補正します。
同じ終了通知を受けていた中央`REPLAY`、黒色0.6の暗転、入力遮断raycast、
純正自動停止を、固定映像区間の誤終端では発生させません。独立した一時停止機能や
UIの強制非表示は追加していません。通常WM/HLS、活動記録、Fes、他セッション、
実際の再生位置・全長・AFTER入場判定は変更しません。さらにモデル内部の実全長、
現在位置、再生可能率を照合し、現在位置が実全長へ到達した本来の終端では補正せず、
純正REPLAY表示を維持します。

0.8.1では、Android版の`removeRenderImageCover`と同じ2つの入口を
iOS 5.0.1の正確なメタデータで接続します。With×MEETSアーカイブの選択から
プレイヤーモデル破棄までのスコープ内だけ、
`Inspix.CoverImageCommandReceiver.Awake`による固定カバー受信開始を省略し、
`Inspix.LiveMain.AppsCoverScreen.SetActiveCoverImage(true)`を`false`へ
置き換えます。開始前やAFTER暗転区間で固定待機画像を前面へ出さず、
背後で描画されている映像を見える状態にします。
動画時刻、シーク、再生・停止、終端判定、REPLAY判定、AFTER入場判定は変更しません。
通常WM/HLSとALST/IARCの両方を対象にし、活動記録、Fes、ホーム、WM一覧では
純正カバー処理を維持します。プレイヤーモデルの破棄時には対象スコープを解除します。
WMアーカイブの再生画面では、標準シークバー左側に小さな再生／一時停止ボタンも
表示します。ボタンはアプリ既存の`LiveConnectControlModel.Play()`と`Pause()`だけを
呼び、現在位置を維持します。`PlayFromStartAsync`、シーク位置、再生終了、
REPLAY、AFTER判定には触れません。WM一覧へ戻ると、対象モデルの破棄に合わせて
ボタンも消えます。

また、活動記録とWith×MEETSのカメラ操作中に画面左端の小さなタブを押すと、
操作パネルと右ジョイスティックをまとめて隠せるスクリーンショットモードを
追加しました。非表示中はタブ自体も透明になりますが、同じ左端の位置を押すと
復帰します。カメラ位置・回転・ズームとFREE状態は維持し、押下中の操作入力だけを
解除します。

0.6.0では、Android版のローカルアーカイブDBで確認した59件の
With×MEETSアーカイブについて、各HLS URLと対応するALST/IARC `.md` URLを
完全一致で対応付けました。iOS側の応答に `.md` URLが欠けている場合だけ補い、
未知のURLを日付などから推測して生成することはありません。

また、With×MEETSアーカイブ応答の `IsHorizontal` を再生開始前に読み取り、
対象のWM再生中だけアプリ標準の縦横画面処理を復元します。縦型・横型のどちらも
同じ仕組みで扱い、終了時には状態を解除してホーム、活動記録、Fesライブへ
持ち越さない構成です。

0.5.0では、活動記録とWith×MEETS 3Dアーカイブの自由カメラに、Android版の
操作体系を基準とした右側パネルを追加しました。右ジョイスティックはカメラ全体を
前後左右へ連続平行移動し、ジョイスティック上の `←` / `→` は同じカメラ位置から
視線だけを左右へ連続回転します。`*` はジョイスティックの前後成分をワールド上下
移動へ切り替え、`R` はFREE開始位置へ戻します。メインパネルの `Q −` / `E +` は
押している間ズームアウト／インを継続します。0.4.3で修正したWM標準シークバーと
一覧へ戻った際のパネル解除も維持しています。

0.4.3では、`StreamingIarc` のWMアーカイブで標準シークバーのPresenterが
自分自身を破棄していた入口判定だけを補正し、アプリ標準の再生位置UIを利用できる
ようにしました。またWMアーカイブのモデル・DynamicCamera・AlphaBlendCameraの
各終了経路でカメラ操作パネルを冪等に解除し、一覧へ戻った後もパネルが残る問題を
修正しました。

0.4.0では、With×MEETSアーカイブ応答にALST/IARCのモーションデータと
HLS/USM動画の両方が含まれる場合、アプリ標準の
`WithArchiveContentTypeSelector` が常に固定動画を優先していた経路を補正します。
`ArchiveUrl` のURLパスが `.md` で終わるモーションアーカイブの場合だけ
`VideoUrl` を選択対象から外し、標準ローダーに `StreamingIarc` を選ばせます。
`.md` の `ArchiveUrl` がない回は従来のHLS/USM動画を選択します。URLの到達可否
までは事前検査しないため、無効な `.md` URLは再生時にエラーとなります。これにより、既存の
With×MEETS 3Dアーカイブ用カメラ操作パネルへ接続できます。

0.3.4では、カメラ操作の曖昧な `Pitch+/-` と `Zoom+/-` 表記を
`P ↑/↓` と `Z IN/OUT` に変更しました。パネル上部には直前に受け付けた操作、
現在のPitch角、およびFOV（平行投影ではSize）を表示します。PitchとZoomの内部
割り当ておよび描画解像度は変更していません。

0.3.3では、活動記録の遷移用カメラを早く取得してパネルが消えていた問題を修正し、
本編の `StoryModelSpaceManager.Setup` 完了後に登録するよう変更しました。
またWith×MEETSの3Dアーカイブでは、Realtime用factoryとは別の
`LiveConnectMrsPlayerPresenter` 経路を使用していたため、アーカイブ専用判定を
追加しました。`AlphaBlendCamera.UpdateCameras` で確定したメインカメラだけを
登録し、内部検索中のsub／presetカメラを誤って操作しないようにしています。
対象モデルの破棄時には、操作パネルとカメラ参照も解除します。

## 含まれる機能

- With/Fes LiveStreamの解像度調整
- Storyの描画解像度調整
- 目標FPSの調整
- アンチエイリアス調整
- MagicaClothのシミュレーション負荷調整
- Fesカメラの移動距離・回転角・FOV調整
- 正規所持済みFesアーカイブチケットのカメラ権限互換修正
- 正規所持済みWith×MEETS AFTERの一覧・詳細完全一致証拠だけを
  プレイヤーモデルへ伝播する入場互換修正
- Android版DBで確認済みの59件を含む、対応するWith×MEETSアーカイブの
  ALST/IARCモーション再生
- With×MEETSアーカイブごとの縦横画面判定の復元
- With×MEETSアーカイブ開始前・AFTER区間の固定待機カバー抑止
- 活動記録とWith×MEETS 3Dアーカイブの自由カメラ・ズーム操作
- 活動記録・With×MEETS共通のスクリーンショット用UI一時非表示
- 活動記録の背景・遷移・非キャラクター3D・被写界深度・
  プリセットエフェクトの個別非表示
- QuestLiveの任意の描画負荷軽減
- iPadの回転要求抑制と横画面ポップアップ補正
- 任意のStory表示速度・字幕QoL調整

初期値は、LiveStream短辺720/1080/1440、Story倍率0.6/1.0/1.4、
60 FPS、4x AA、布シミュレーション60 Hzです。QuestLiveの省略系機能、
Story QoL、活動記録の各非表示機能は初期状態では無効です。同梱JSONでは
活動記録とWith×MEETSのカメラ操作、対応WMアーカイブの
モーションキャプチャ再生、および
スクリーンショット用UI一時非表示を有効にしています。0.8.1の同梱JSONでは、
正規所持済みWith×MEETS AFTERの誤判定修復、WM/IARC全長シーク修復、および
WM/IARCの誤ったREPLAY表示・暗転の抑止に加えて、WMアーカイブの固定待機カバー
抑止も有効にしています。

同梱JSONでは、今回の利用者が対象チケットを正規所持しているという申告に基づき、
Fesアーカイブのカメラ権限互換修正を有効にしています。静的アーカイブDBでは
正規Sランクでも `SelectableCameraTypes` が `[DynamicView]` だけになる不整合が
実機で確認されたため、アーカイブ専用 `FesConnectModelsFactory` の応答キャッシュが
この完全一致の状態のときだけ、設定したカメラ一覧へ補正します。

サーバーから得られたS/Eランクはそのまま維持し、ランクが未設定またはGuestの場合
だけ設定値で補完します。さらに `CameraSelectModel` 生成時にも同じ条件を検査する
二段構成です。このFes補正はAFTER入場、購入状態、一般のFes入場応答を変更せず、
カメラ保存APIの呼び出しも抑止しません。

With×MEETS AFTERの修復は、純正一覧応答の
`LiveInfo.<HasExtraAdmission>`、または`HasExtra`・一覧☆数・必要☆数から
正規到達を確認し、同じ`ArchivesId`の詳細リクエストと一度だけ照合します。
再生対象の`WithArchiveContentTypeSelector._enterResponseCache`から正確な
`WithArchiveEnterResponseCache.Value`を取得し、Extraチャプターと
通常／Extra込み再生時間の整合性も確認します。この修復が詳細応答で変更するのは、
最終応答の
`<HasExtraAdmission>k__BackingField`が誤って`false`だった場合だけです。
さらに0.7.6では、その同じ検証済み詳細応答を
`WithConnectModelsFactory._enterResponseCache`の応答実体と完全一致で照合し、
同factoryが`GiftPointModel`を生成している間だけ、失われた入場真偽値を
プレイヤーモデルへ一度だけ伝播します。現在ポイント、報酬区間、スター数、
AFTER必要スター数（閾値）、`HasExtra`、イベント種別、所持ランク、購入状態、
チケット情報は変更しません。
未所持AFTERを解放する機能ではありません。同梱JSONでは
`WithMeets.After.ValidAdmissionRepair.Enable=true`ですが、キーを省略した場合の
実行時既定値は`false`で、証拠検証に失敗した場合もfail-closedです。

## 意図的に含めていない機能

- 翻訳
- フォント置換
- 正規権利証拠のないAFTERの解放、未所持AFTERの解放
- 未所持チケットの付与や購入状態の変更
- Focus範囲制限の回避
- WMアーカイブ以外のLiveStreamカバー画像・チャプター情報の改変
- プレイヤーID表示の改変

無効設定を残しているのではなく、これらのフック実装をバイナリから除外しています。

## 必要なもの

- LiveContainer
- JITを有効にできる環境
- Linkuraのネイティブ5.0.1実体を使う、動作中のHASU API静的置換版

iOS/iPadOS 26では、現行LiveContainerの仕様により、対応する新しい
LiveContainerに加えて `dobby.dylib` と `Geode.js` が必要です。
`dobby.dylib` はTweakフォルダへ置き、アプリ設定のJIT起動スクリプトには
`Geode.js` を指定します。この配布物には両ファイルを含めていません。

## LiveContainerへの導入

現在アプリ内データをダウンロード中なら、先に完了させてアプリを終了してください。
データコンテナを作り直す必要はありません。

1. 配布ZIPを展開します。
2. LiveContainerの「調整」画面で `LinkuraVisualsIOS` などの新しい調整フォルダを作ります。
   旧版から更新する場合は、既存の `LinkuraVisualsIOS.json` を先に複製して
   バックアップしてください。
3. ZIP内の `Install` にある次の3ファイルを同じ調整フォルダへコピーします。
   - `LinkuraVisualsIOS.dylib`
   - `LinkuraVisualsIOS.json`
   - `IL2CPP_OFFSETS_5.0.1.json`
   同梱JSONで既存JSONを置換すると、利用者が変更した活動記録などの値は初期値へ
   戻ります。設定を保つ場合は既存JSONを残し、
   次のキーをBooleanの `true` として追加してください。
   - `WithMeets.Archive.MotionCaptureReplay.Enable`
   - `WithMeets.Archive.IarcFullSeek.Enable`
   - `WithMeets.Archive.IarcReplayOverlay.Suppress`
   - `WithMeets.Archive.RenderImageCover.Suppress`
   - `WithMeets.After.ValidAdmissionRepair.Enable`
   - `CameraControl.UI.ScreenshotHide.Enable`
   置換する場合は、バックアップを見ながら必要な値を設定し直します。
4. iOS/iPadOS 26の場合は、同じフォルダへ対応版の `dobby.dylib` も追加します。
5. HASU API静的置換版のアプリ設定で、その調整フォルダを選択します。
6. 「JITで起動」を有効にします。iOS/iPadOS 26ではJIT起動スクリプトに
   `Geode.js` を選びます。
7. LiveContainerからアプリを起動します。

問題が出た場合は、アプリのデータコンテナを消さずに、調整フォルダの選択だけを
`None`へ戻してください。

## 設定

`LinkuraVisualsIOS.json` を編集すると次回起動時に反映されます。
JSONのキー名や型を変えないでください。
0.4.3以前の既存JSONを残した場合も、0.5.0で追加したジョイスティックと長押し速度、
0.6.0で追加したWM縦横画面修復と、0.7.0で追加した
スクリーンショットUIは下表の初期値で動作します。
`WithMeets.After.ValidAdmissionRepair.Enable`はキーが存在しない場合は
安全のため`false`です。正規所持済みAFTERの誤判定修復を使用する場合だけ
Booleanの`true`を追加してください。速度を変えたい場合だけ対応する新しいキーを
追加してください。
`WithMeets.Archive.IarcFullSeek.Enable`もキーが存在しない場合は`false`です。
WM/IARCの固定映像区間より後へシークする場合は、配布JSONを使うか同キーを
Booleanの`true`として追加してください。
`WithMeets.Archive.IarcReplayOverlay.Suppress`は全長シーク修復が有効な
WM/IARCセッションだけに適用されます。`true`では同一再生モデルの誤った終端通知を
抑止し、中央REPLAY表示、それに含まれる黒色0.6の暗転・入力遮断用raycast、
および同じ通知による純正自動停止を発生させません。純正判定へ戻す場合は`false`に
してください。
`WithMeets.Archive.RenderImageCover.Suppress`はキーが存在しない場合は
安全のため`false`です。`true`ではWith×MEETSアーカイブ再生中に限り、
開始前とAFTER区間の固定待機カバーを表示せず、背後の描画映像を見える状態にします。
再生・シーク・終端・REPLAYの状態には作用しません。

主な項目:

| 設定 | 初期値 | 内容 |
|---|---:|---|
| `Compatibility.BinaryVersion` | `"5.0.1"` | IL2CPP解決に使う実体バージョン。変更禁止 |
| `TargetFPS` | `60` | 目標FPS |
| `AntiAliasingSamples` | `4` | AAサンプル数。通常は1/2/4/8 |
| `LiveStream.Quality.*.ShortSide` | `720/1080/1440` | 各品質の短辺ピクセル数 |
| `Story.Quality.*.Factor` | `0.6/1.0/1.4` | Storyの解像度倍率 |
| `MagicaCloth.SimulationFrequency` | `60` | 布シミュレーション周波数 |
| `MagicaCloth.MaxSimulationCountPerFrame` | `3` | 1フレーム当たり最大計算回数 |
| `Enable.FesCameraHook` | `true` | Fesカメラの移動・回転・FOV調整 |
| `FesArchive.ValidTicketRepair.Enable` | `true`（配布JSON） | 正規所持済みFesアーカイブチケットのカメラ権限を補完 |
| `FesArchive.ValidTicketRepair.TicketRank` | `6` | 所持チケットのランク。`6`はS |
| `FesArchive.ValidTicketRepair.SelectableCameraTypes` | `[1,2,3,4]` | 所持チケットで選択できるカメラ種別 |
| `ActivityRecord.HideBackground` | `false` | 活動記録の背景表示・移動・回転命令を除外 |
| `ActivityRecord.HideTransition` | `false` | 暗転・遷移命令を除外 |
| `ActivityRecord.HideNonCharacter3D` | `false` | キャラクター以外の3Dオブジェクト命令を除外 |
| `ActivityRecord.HideDepthOfField` | `false` | 被写界深度命令を除外 |
| `ActivityRecord.HidePresetEffect` | `false` | プリセットポストエフェクト命令を除外 |
| `ActivityRecord.CameraControl.Enable` | `true`（配布JSON） | 活動記録だけで自由カメラUIを有効化 |
| `ActivityRecord.LandscapeRepair.Enable` | `true` | 活動記録中だけ純正の縦横回転処理を復元 |
| `ActivityRecord.LandscapeRepair.RebindGraceSeconds` | `5.0` | 回転で再生成されたStoryCameraを再取得する猶予秒数 |
| `WithMeets.CameraControl.Enable` | `true`（配布JSON） | With×MEETSの3D `StreamingIarc` アーカイブで自由カメラUIを有効化 |
| `WithMeets.Archive.MotionCaptureReplay.Enable` | `true`（配布JSON） | `.md` モーションデータがあるWMアーカイブをALST/IARCで再生 |
| `WithMeets.Archive.IarcFullSeek.Enable` | `true`（配布JSON、キー未設定時`false`） | WM/IARCだけ固定映像区間の境界を越えてアーカイブ全長へシーク可能にする |
| `WithMeets.Archive.IarcReplayOverlay.Suppress` | `true`（配布JSON、キー未設定時`true`） | 全長シーク中の同一WM/IARC再生モデルだけ、固定映像区間の誤終端通知と、それによるREPLAY・暗転・入力遮断・自動停止を抑止 |
| `WithMeets.Archive.OrientationRepair.Enable` | `true` | WMアーカイブ中だけ応答の `IsHorizontal` に従う純正回転処理を復元 |
| `WithMeets.Archive.OrientationRepair.RebindGraceSeconds` | `5.0` | 回転・終了時に再生成されるWMモデルを安全に再取得する猶予秒数 |
| `WithMeets.Archive.RenderImageCover.Suppress` | `true`（配布JSON、キー未設定時`false`） | WMアーカイブの開始前・AFTER区間で固定待機カバーだけを抑止 |
| `WithMeets.After.ValidAdmissionRepair.Enable` | `true`（配布JSON、キー未設定時`false`） | 正規所持済みWM AFTERの完全一致証拠がある場合だけ詳細応答とプレイヤーモデルの入場誤判定を補正 |
| `CameraControl.UI.Enable` | `true` | 共通カメラ操作パネルを表示 |
| `CameraControl.UI.ScreenshotHide.Enable` | `true` | 左端タブで操作パネルとジョイスティックを一時非表示 |
| `CameraControl.Joystick.Enable` | `true` | 右側の連続移動ジョイスティックを表示 |
| `CameraControl.Joystick.MoveSpeed` | `0.8` | ジョイスティック最大入力時の移動速度 |
| `CameraControl.HoldYawDegreesPerSecond` | `60.0` | 右側 `←` / `→` 長押し時の首振り速度（度/秒） |
| `CameraControl.HoldPerspectiveZoomPerSecond` | `50.0` | 透視カメラのQ/E長押し時のFOV変化速度 |
| `CameraControl.HoldOrthographicZoomPerSecond` | `10.0` | 平行投影カメラのQ/E長押し時のSize変化速度 |
| `CameraControl.MoveStep` | `0.15` | 移動ボタン1回の距離 |
| `CameraControl.RotateStepDegrees` | `3.0` | 回転ボタン1回の角度 |
| `CameraControl.PerspectiveZoomStep` | `2.0` | 透視カメラのFOV変更量 |
| `CameraControl.OrthographicZoomStep` | `0.5` | 平行投影カメラのサイズ変更量 |
| `Enable.NoOrientationHook` | iPad: `true` / iPhone: `false` | 回転要求抑制 |
| `Enable.LandscapePopupSizeFixHook` | iPad: `true` / iPhone: `false` | 横画面ポップアップ補正 |

`FesArchive.ValidTicketRepair.Enable` は対象チケットを正規に所持している場合だけ
有効にしてください。所持ランクやカメラ種別が異なる場合は、そのチケットの内容に
合わせて値を変更します。通常状態へ戻すにはこの設定を `false` にします。
`LiveTicketRank` は `Guest=1, D=2, C=3, B=4, A=5, S=6, E=7`、
カメラ種別は `Dynamic=1, Arena=2, Stand=3, SchoolIdle=4` です。

活動記録の5項目は、読み込んだストーリースクリプトから対象の表示命令を1行単位で
除外します。まず1項目ずつ有効にして確認してください。組み合わせによっては
背景が空になる、意図した暗転が消える、演出タイミングが変わることがあります。
実機確認では、3D背景セットは `HideNonCharacter3D`、背景上のグラデーションは
`HidePresetEffect` の対象でした。

活動記録またはWith×MEETSの対象カメラを取得すると、画面左上に共通の操作パネルが
表示され、右下には連続移動用パネルが表示されます。`GAME` を押して `FREE` に
切り替えてから操作します。

画面左端中央の `◀` タブを押すと、両方の操作UIが非表示になります。非表示中は
タブも透明ですが、同じ左端中央の44×44ポイントの位置を押すと再表示されます。
非表示にしてもFREEカメラの位置・向き・ズームは変わりません。画面を離れると
非表示状態は解除され、パネルを次の画面へ残しません。

- 右ジョイスティック: カメラ全体をカメラ基準で前後左右へ連続平行移動
- 右パネルの `←` / `→`: カメラ位置は変えず、視線だけを左右へ連続回転
- 右パネルの `* XZ` / `* XY`: ジョイスティックの前後成分を前後移動／
  ワールド上下移動へ切り替え
- 右パネルの `R`: `FREE` に切り替えた時点の位置・回転・ズームへ戻す
- 左パネルの `←` / `→`: カメラ基準で左右へ1段階移動
- 左パネルの `↑` / `↓`: カメラ基準で前後へ1段階移動
- `+Y` / `-Y`: ワールド基準で上下へ移動
- `YAW ←` / `YAW →`: 左右へ回転
- `P ↑` / `P ↓`: 上下へ回転
- `Q −` / `E +`: 押している間ズームアウト／ズームイン
- `RESET`: `FREE` に切り替えた時点の位置・回転・ズームへ戻す
- `FREE`: Tweakによる上書きを解除してゲーム側のカメラ制御へ戻す

パネル左上の1行目は対象（`A`=活動記録、`W`=With×MEETS）と直前の操作、
2行目はPitch角の `P` と透視カメラの `F`（FOV）または平行投影カメラの
`S`（Size）を示します。Pitch操作時に `F` / `S` が変化しなければ、Zoom処理は
実行されていません。

透視カメラでは `E +` がFOVを小さくし、平行投影カメラでは表示サイズを小さく
します。`Q −` はその逆です。対象カメラ自体が切り替わった場合は、安全のため
`GAME` 状態へ戻ります。
`FREE` から `GAME` へ戻す操作は古い演出位置へ巻き戻さず上書きだけを解除するため、
静止したカメラでは次にゲーム側がカメラを更新するまで最後のFREE位置が残る場合が
あります。

活動記録側は、通常の操作経路では活動記録の再生操作直後に生成され、
`StoryModelSpaceManager.Setup` を完了した本編カメラだけを対象にします。
一般Storyを直接登録する分岐はありません。

With×MEETS側は、0.4.0から `.md` の `ArchiveUrl` があるアーカイブに限り、
固定動画よりALST/IARCモーション再生を優先します。アーカイブ再生モデルが
`WithMeetConnect` かつ
`StreamingIarc` の場合だけ、`Inspix.AlphaBlendCamera.UpdateCameras` で
確定したメインカメラを取得します。HLS/USM形式のアーカイブは収録済み2D映像
しか存在しない場合は、3Dの視点変更はできず、この操作パネルも表示しません。
With×STATIONと
Fesライブのカメラにも接続しません。活動記録とWith×MEETSは同じUIを使いますが、
対象画面の判定とカメラ取得経路は別々です。

0.6.0では、iOS応答に `.md` が欠ける既知のWMについても、同梱した59件の
完全一致カタログから補完します。各項目にはAndroid版DBで確認した
`archives_id`、HLS URL、ALST/IARC URL、縦横情報が含まれますが、実行時の画面向きは
サーバー応答の `IsHorizontal` を正として扱います。カタログ外で `.md` が返らない
回は、誤ったURLへ接続しないため従来の固定映像を維持します。

解像度、AA、布シミュレーション値を上げると、発熱・消費電力・クラッシュの可能性が
増えます。まず初期値で動作確認してください。

上記2つの端末別設定は、同梱JSONでは省略しており、アプリが端末種別から自動設定
します。明示的に上書きしたい場合だけJSONへキーを追加してください。

## 検証済み範囲

- arm64 / arm64e Universal Mach-O
- iOS 14.0以上をデプロイメントターゲットとしてビルド
- ad-hoc署名
- 対象5.0.1 `UnityFramework` に対するIL2CPPシグネチャと主要オフセットの一致
- Fesアーカイブ専用factory／応答キャッシュ／`CameraSelectModel` ctorと、
  活動記録 `LoadStoryData` の解決
- 活動記録専用再生コールバック／`StoryModelSpaceManager.Setup` の解決
- With×MEETSの `StreamingIarc` 判定、
  `WithArchiveContentTypeSelector.Execute` のALST/IARC選択、
  `LiveConnectMrsPlayerPresenter.Initialize`／`AlphaBlendCamera.UpdateCameras`／
  `LiveSystemModels.Dispose` の解決
- Android版DB由来のWM 59件について、HLS URL・ALST/IARC URL・
  `archives_id` の重複がなく対応日付が一致すること
- WM応答の `IsHorizontal` を再生スコープ内だけ使用し、終了時に解除する経路
- `Inspix.CoverImageCommandReceiver.Awake`と
  `Inspix.LiveMain.AppsCoverScreen.SetActiveCoverImage(bool)`を正確なABIで解決し、
  WMアーカイブ再生スコープ内だけ固定カバーを抑止する経路
- `WithArchiveContentTypeSelector._enterResponseCache`、
  `WithArchiveEnterResponseCache.Value`、正確な
  `GetWithArchiveDataResponse`をたどり、
  スター報酬区間・AFTER必要スター数・ユーザー獲得ポイント・Extraチャプター・
  通常／Extra込み再生時間を同一応答で検証して、
  `<HasExtraAdmission>k__BackingField`だけを`false`から`true`へ変更する経路
- 検証済み詳細応答と
  `WithConnectModelsFactory._enterResponseCache.Value`の実体が完全一致し、
  `GiftPointModel`側の`HasExtra`とAFTER必要スター数も一致する生成スコープだけで、
  入場真偽値を一度だけプレイヤーモデルへ伝播する経路。現在ポイント、報酬区間、
  スター数、AFTER必要スター数（閾値）、`HasExtra`、イベント種別は変更しないこと
- 上記AFTER応答クラス名・バッキングフィールド名が生成バイナリの
  arm64 / arm64e両スライスに含まれること
- Realtime用のmanaged `Unit` 1引数factory／`DynamicCamera` の解決
- 対象カメラへの位置・回転・FOV／平行投影サイズの適用を
  `RenderPipeline.BeginCameraRendering` フック内の元コールバック後に限定
- 翻訳、フォント置換、未所持AFTERを解放する広範な制限回避フックが
  生成バイナリにないこと

カメラ操作UIは新規実装のため、実機での最終確認は端末・LiveContainer・
JIT環境と対象コンテンツの組み合わせごとに必要です。

## ビルド

同梱ソースの親にTheos iPhoneOS 16.5 SDKを配置してから実行します。

```sh
chmod +x build.sh verify_build.sh verify_il2cpp_offsets.py
./build.sh
UNITY_FRAMEWORK=/path/to/5.0.1/UnityFramework ./verify_build.sh
```

SDKは再配布物に含めていません。ビルドスクリプトの既定SDKパスは
`../toolchain/iPhoneOS16.5.sdk` です。配布アーカイブ名は16.5ですが、
SDK内部設定と生成Mach-Oの `LC_BUILD_VERSION` ではSDK 16.4として記録されます。

使用したSDKアーカイブ:

- URL:
  <https://github.com/theos/sdks/releases/download/master-146e41f/iPhoneOS16.5.sdk.tar.xz>
- SHA-256:
  `5e0fd3f01266cce4ce012d4a99b38eb56578fca40d09edc81cd83dee958202fb`

## 出典とライセンス

この成果物は
[LLLLResUpiOS v0.0.17](https://github.com/DYY-Studio/LLLLResUpiOS/tree/v0.0.17)
および
[IOS-Il2cppResolver](https://github.com/DYY-Studio/IOS-Il2cppResolver)
を元にしています。`txm_bypass.m` はLiveContainer/geode-sdk由来の
GNU AGPL v3コードです。詳細は `NOTICE.md`、`LICENSE-AGPL-3.0`、
`LICENSE-MIT-UPSTREAM` を参照してください。

結合された成果物全体の配布条件は `AGPL-3.0-only` です。元のMIT部分の
著作権表示と許諾表示もそのまま保持しています。

無保証です。公式アプリや各プロジェクトの開発者によるサポート対象ではありません。
