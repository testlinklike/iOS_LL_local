# Notices and provenance

## LinkuraVisualsIOS

This is a modified combined work prepared on 2026-07-18.

The modification intentionally removes translation, font replacement,
access-control bypasses, cover/chapter mutation, and player-ID decoration.
It retains visual, performance, camera-movement, story QoL, and iPad layout
hooks.

The modified combined work is distributed as `AGPL-3.0-only`. See
`LICENSE-AGPL-3.0`.

## LLLLResUpiOS

- Project: <https://github.com/DYY-Studio/LLLLResUpiOS>
- Upstream tag: `v0.0.17`
- Upstream tag commit: `e5e73cc66d0087750d286b95219e6e2040952867`
- Upstream license: MIT
- Original copyright:
  `Copyright © 2025 yyfll <yyfll1@qq.com>`

The original MIT notice is reproduced in `LICENSE-MIT-UPSTREAM`.

## IOS-Il2cppResolver

- Project: <https://github.com/DYY-Studio/IOS-Il2cppResolver>
- Vendored commit: `35e7ff8f57f315c6a33a3f7fb547011a81e41da2`
- Stated upstream license: MIT
- Authors named by the upstream project:
  - sneakyevil — base source
  - Batchh — iOS adaptation
  - DYY-Studio — generic method/class support and System.String handling

The vendored snapshot did not contain a separate license file; its README
states the MIT license. The standard MIT terms applicable to the upstream
work are retained with the source and noted here.

## txm_bypass.m

`txm_bypass.m` carries its original notice:

- Source: <https://github.com/geode-sdk/ios-launcher>
- License: GNU Affero General Public License v3.0
- License reference:
  <https://github.com/LiveContainer/LiveContainer/blob/main/LICENSE>

Because this source is compiled into the same dylib, the binary distribution
is accompanied by complete corresponding source and the GNU AGPL v3 text.

## No affiliation or warranty

This project is not affiliated with or endorsed by ODD No., Bandai Namco
Music Live, the Link! Like! Love Live! project, LiveContainer, or the upstream
tweak authors. The work is provided without warranty.
