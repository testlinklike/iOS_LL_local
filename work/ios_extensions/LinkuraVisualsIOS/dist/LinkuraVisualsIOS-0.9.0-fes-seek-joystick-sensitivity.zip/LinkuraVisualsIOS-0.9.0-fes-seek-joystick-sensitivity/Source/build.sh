#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
SDK="${SDKROOT:-${ROOT}/../toolchain/iPhoneOS16.5.sdk}"
BUILD_DIR="${ROOT}/build"
OUTPUT="${BUILD_DIR}/LinkuraVisualsIOS.dylib"

if [[ ! -d "${SDK}" ]]; then
  print -u2 "iPhoneOS SDK not found: ${SDK}"
  exit 1
fi

mkdir -p "${BUILD_DIR}"

common_flags=(
  -isysroot "${SDK}"
  -x objective-c++
  "${ROOT}/Tweak.xm"
  -std=c++20
  -stdlib=libc++
  -fobjc-arc
  -fblocks
  "-DLVI_WM_DIAGNOSTIC=${LVI_WM_DIAGNOSTIC:-0}"
  "-DLVI_WITH_AFTER_REPAIR=${LVI_WITH_AFTER_REPAIR:-1}"
  -Wno-vla
  -Wno-deprecated-declarations
  -O2
  -DNDEBUG
  -dynamiclib
  -framework Foundation
  -framework CoreGraphics
  -framework UIKit
  -Wl,-install_name,@rpath/LinkuraVisualsIOS.dylib
  -Wl,-dead_strip
)

/usr/bin/clang++ \
  -target arm64-apple-ios14.0 \
  "${common_flags[@]}" \
  -o "${BUILD_DIR}/LinkuraVisualsIOS.arm64.dylib"

/usr/bin/clang++ \
  -target arm64e-apple-ios14.0 \
  "${common_flags[@]}" \
  -o "${BUILD_DIR}/LinkuraVisualsIOS.arm64e.dylib"

/usr/bin/lipo -create \
  "${BUILD_DIR}/LinkuraVisualsIOS.arm64.dylib" \
  "${BUILD_DIR}/LinkuraVisualsIOS.arm64e.dylib" \
  -output "${OUTPUT}"

/usr/bin/codesign --force --sign - --timestamp=none "${OUTPUT}"

print "Built: ${OUTPUT}"
/usr/bin/lipo -archs "${OUTPUT}"
/usr/bin/shasum -a 256 "${OUTPUT}"
