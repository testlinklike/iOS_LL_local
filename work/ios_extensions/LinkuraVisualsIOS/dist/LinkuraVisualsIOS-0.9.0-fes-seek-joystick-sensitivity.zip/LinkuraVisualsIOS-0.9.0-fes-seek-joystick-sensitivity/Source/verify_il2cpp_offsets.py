#!/usr/bin/env python3
import json
import sys
from pathlib import Path


SIGNATURE = (
    "F4 4F BE A9 FD 7B 01 A9 FD 43 00 91 F3 03 00 AA "
    "?? ?? ?? ?? ?? ?? ?? ?? 00 00 80 52 ?? ?? ?? ?? "
    "E0 03 13 AA ?? ?? ?? ?? FD 7B 41 A9 F4 4F C2 A8 C0 03 5F D6"
).split()

EXPECTED_HEADERS = {
    "il2cpp_init": 0xF44FBEA9,
    "il2cpp_class_get_method_from_name": 0x03008052,
    "il2cpp_resolve_icall": 0xFFC301D1,
    "il2cpp_thread_detach": 0xFD7BBFA9,
    "il2cpp_method_get_param_name": 0xFF0301D1,
}


def find_signature(data: bytes) -> list[int]:
    pattern = bytes(int(value, 16) if value != "??" else 0 for value in SIGNATURE)
    mask = bytes(0 if value == "??" else 0xFF for value in SIGNATURE)
    prefix = pattern[:16]
    matches: list[int] = []
    cursor = 0
    while True:
        cursor = data.find(prefix, cursor)
        if cursor < 0:
            return matches
        if all(not mask[index] or data[cursor + index] == pattern[index]
               for index in range(len(pattern))):
            matches.append(cursor)
        cursor += 1


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: verify_il2cpp_offsets.py UnityFramework offsets.json",
              file=sys.stderr)
        return 2

    framework_path = Path(sys.argv[1])
    offsets_path = Path(sys.argv[2])
    data = framework_path.read_bytes()
    offsets = json.loads(offsets_path.read_text())
    matches = find_signature(data)
    if len(matches) != 1:
        raise SystemExit(f"expected one il2cpp_init signature, found {matches}")

    base = matches[0]
    for name, expected in EXPECTED_HEADERS.items():
        address = base + int(offsets[name])
        actual = int.from_bytes(data[address:address + 4], "big")
        if actual != expected:
            raise SystemExit(
                f"{name}: header mismatch at 0x{address:x}: "
                f"0x{actual:08x} != 0x{expected:08x}"
            )
        print(f"{name}: OK at file offset 0x{address:x}")

    print(f"IL2CPP offset set matches {framework_path.name}; base=0x{base:x}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
