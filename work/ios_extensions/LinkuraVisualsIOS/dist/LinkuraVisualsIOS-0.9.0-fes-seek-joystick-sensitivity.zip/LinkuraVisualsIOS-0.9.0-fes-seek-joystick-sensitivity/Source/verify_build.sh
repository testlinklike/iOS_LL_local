#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
DYLIB="${DYLIB_OVERRIDE:-${ROOT}/build/LinkuraVisualsIOS.dylib}"
UNITY_FRAMEWORK="${UNITY_FRAMEWORK:-${ROOT}/../../ios501_api/UnityFramework}"
GLOBAL_METADATA="${GLOBAL_METADATA:-${ROOT}/../../ios501_api/global-metadata.dat}"
EXPECTED_METADATA_SHA256="23baba872c71931313661246d9c8a43d33a3eedcb27ee1506a456d25901714ae"
VERIFY_DIAGNOSTIC="${LVI_VERIFY_DIAGNOSTIC:-0}"

[[ "${VERIFY_DIAGNOSTIC}" == "0" || "${VERIFY_DIAGNOSTIC}" == "1" ]] || {
  print -u2 "LVI_VERIFY_DIAGNOSTIC must be 0 or 1"
  exit 1
}

[[ -f "${DYLIB}" ]] || { print -u2 "missing ${DYLIB}"; exit 1; }
[[ -f "${UNITY_FRAMEWORK}" ]] || {
  print -u2 "missing UnityFramework: ${UNITY_FRAMEWORK}"
  exit 1
}
[[ -f "${GLOBAL_METADATA}" ]] || {
  print -u2 "missing global metadata: ${GLOBAL_METADATA}"
  exit 1
}

# A locally built release must not be older than any source input. An explicit
# override is used only to re-verify an already packaged/extracted dylib.
if [[ -z "${DYLIB_OVERRIDE:-}" ]]; then
  stale_source=$(/usr/bin/find "${ROOT}" \
    -path "${ROOT}/build" -prune -o \
    -path "${ROOT}/dist" -prune -o \
    -type f \
    \( -name '*.xm' -o -name '*.m' -o -name '*.mm' -o \
       -name '*.h' -o -name '*.hpp' -o -name '*.inc' -o \
       -name '*.json' -o -name '*.py' -o -name 'build.sh' \) \
    -newer "${DYLIB}" -print -quit)
  if [[ -n "${stale_source}" ]]; then
    print -u2 "build artifact is older than source: ${stale_source}"
    print -u2 "run ./build.sh before verification"
    exit 1
  fi
fi

metadata_sha=$(/usr/bin/shasum -a 256 "${GLOBAL_METADATA}" | /usr/bin/awk '{print $1}')
[[ "${metadata_sha}" == "${EXPECTED_METADATA_SHA256}" ]] || {
  print -u2 "unexpected global-metadata.dat SHA-256: ${metadata_sha}"
  exit 1
}

archs=$(/usr/bin/lipo -archs "${DYLIB}")
[[ "${archs}" == *arm64* && "${archs}" == *arm64e* ]] || {
  print -u2 "unexpected architectures: ${archs}"
  exit 1
}

/usr/bin/vtool -show-build "${DYLIB}" | /usr/bin/grep -q "platform IOS"
/usr/bin/codesign --verify --strict "${DYLIB}"

excluded=(
  NoAfterLimitation
  NoFesCameraLimitation
  MakeExtraAdmissionObservable
  SetTotalUserGiftPoint
  LiveConnectChapterModel
  TitleSceneController
  FocusAreaDelimiter
  TMP_Text
  TMP_FontAsset
  Translation
  translation
  PurchaseStatus
)

required=(
  SchoolResolution
  set_targetFrameRate
  set_antiAliasing
  InitializeStackedCameraData
  MagicaManager
  FesLiveFixedCamera
  FesLiveCameraSwitcher
  IdolTargetingCamera
  SetPortraitImpl
  BasePopup
  Compatibility.BinaryVersion
  FesConnectModelsFactory
  WithConnectModelsFactory
  School.LiveMain.ILiveSystemModelsFactory.CreateOwnGiftPointModel
  GiftPointModel
  _enterResponseCache
  ILiveSystemModelsFactory.CreateCameraSelectModel
  CameraSelectModel
  LiveCameraType
  SelectableCameraTypes
  CurrentCameraType
  TicketRank
  LoadStoryData
  ActivityRecord.HideBackground
  ActivityRecord.HidePresetEffect
  ActivityRecord.CameraControl.Enable
  ActivityRecord.LandscapeRepair.Enable
  ActivityRecord.LandscapeRepair.RebindGraceSeconds
  WithMeets.CameraControl.Enable
  WithMeets.Archive.MotionCaptureReplay.Enable
  WithMeets.Archive.IarcFullSeek.Enable
  WithMeets.Archive.IarcReplayOverlay.Suppress
  WithMeets.Archive.RenderImageCover.Suppress
  WithMeets.Archive.PlayPauseButton.Enable
  WithMeets.Archive.OrientationRepair.Enable
  WithMeets.Archive.OrientationRepair.RebindGraceSeconds
  WithMeets.After.ValidAdmissionRepair.Enable
  CameraControl.UI.ScreenshotHide.Enable
  WithArchiveContentTypeSelector
  built-in-catalog
  VideoArchiveSeekBarPresenter
  ArchiveSeekBarView
  SetSeekLimit
  LiveConnectPlayPositionModel
  IsPlayToEnd
  SetPlayableLengthRate
  School.LiveMain.ILiveSystemPresenter.Initialize
  ArchiveReplayButtonPresenter
  CoverImageCommandReceiver
  AppsCoverScreen
  SetActiveCoverImage
  LVIWithArchivePlayPauseButton
  '<>c__DisplayClass5_0'
  '<School.LiveMain.ILiveSystemPresenter.Initialize>b__0'
  connectControlModel
  ConnectControlModel
  LiveConnectControlModel
  ArchiveUrl
  VideoUrl
  Timelines
  GiftPtRankings
  CameraControl.MoveStep
  CameraControl.Joystick.Enable
  CameraControl.Joystick.MoveSpeed
  CameraControl.HoldYawDegreesPerSecond
  CameraControl.HoldPitchDegreesPerSecond
  CameraControl.HoldPerspectiveZoomPerSecond
  CameraControl.HoldOrthographicZoomPerSecond
  BeginCameraRendering
  StoryModelSpaceManager
  Setup
  LiveConnectMrsPlayerPresenter
  LiveSystemModels
  Inspix.AlphaBlendCamera
  UpdateCameras
  WithLiveCameraReference
  '<.ctor>b__2'
  DynamicCamera
  FesArchive.CameraControl.Enable
  FesArchive.MotionCaptureReplay.Enable
  FesArchive.MotionCaptureReplay.UrlMap
  FesArchiveEnterResponseCache
  FesArchive.ValidTicketRepair.Enable
  FesArchive.ValidTicketRepair.TargetArchiveIds
  Tecotec.SchoolConnectArchiveListViewModel
  CreateArchiveList
  AddToArchiveList
  Org.OpenAPITools.Model.GetWithArchiveDataRequest
  GetArchiveListResponse
  LiveInfo
  GetWithArchiveDataResponse
  WithArchiveEnterResponseCache
  System.Collections.Generic
  'List`1'
  '<ArchiveList>k__BackingField'
  '<ArchivesId>k__BackingField'
  '<LiveId>k__BackingField'
  '<LiveType>k__BackingField'
  '<HasExtraAdmission>k__BackingField'
  '<HasExtra>k__BackingField'
  '<EarnedStarCount>k__BackingField'
  '<GiftStarsThresholdForExtraAdmission>k__BackingField'
  '<TotalPlayTimeSecondWithoutExtra>k__BackingField'
  '<TotalPlayTimeSecondIncludingExtra>k__BackingField'
  '<Chapters>k__BackingField'
  '<IsExtra>k__BackingField'
  ArchiveWithliveChapter
)

diagnostic_required=(
  LiveConnectChapterModel
  SetExtraAdmission
  after-player-chapter-admission
  chapterAdmissionDiagnosticHookInstalled
  wm-clock-hook-install
  wm-clock-seek-release
  wm-clock-replay-predicate
  wm-clock-false-end-suppression
  LiveConnectPlayPositionModel
  ArchiveReplayButtonPresenter
  RealtimeRenderingArchiveController
  wm-audio-runtime-schema
  CriWare.CriAtomSourceBase
  UnityEngine.Audio.AudioMixer
  '<PlayIfNeededAsync>d__3'
  methodPointerToken
  returnType
  parameters
)

VERIFY_DIR="$(mktemp -d "${TMPDIR:-/tmp}/linkura-visuals-verify.XXXXXX")"
cleanup() {
  rm -rf "${VERIFY_DIR}"
}
trap cleanup EXIT

# Verify every architecture independently so a valid universal signature cannot
# hide a stale or feature-incomplete slice.
for arch in arm64 arm64e; do
  slice="${VERIFY_DIR}/LinkuraVisualsIOS.${arch}.dylib"
  strings_file="${VERIFY_DIR}/LinkuraVisualsIOS.${arch}.strings"
  /usr/bin/lipo "${DYLIB}" -thin "${arch}" -output "${slice}"
  /usr/bin/vtool -show-build "${slice}" | /usr/bin/grep -q "platform IOS"
  /usr/bin/codesign --verify --strict "${slice}"
  /usr/bin/strings -a "${slice}" > "${strings_file}"

  for value in "${excluded[@]}"; do
    if [[ "${VERIFY_DIAGNOSTIC}" == "1" &&
          "${value}" == "LiveConnectChapterModel" ]]; then
      continue
    fi
    if /usr/bin/grep -Fq "${value}" "${strings_file}"; then
      print -u2 "excluded string remains in ${arch} slice: ${value}"
      exit 1
    fi
  done

  for value in "${required[@]}"; do
    /usr/bin/grep -Fq "${value}" "${strings_file}" || {
      print -u2 "required string missing from ${arch} slice: ${value}"
      exit 1
    }
  done

  if [[ "${VERIFY_DIAGNOSTIC}" == "1" ]]; then
    for value in "${diagnostic_required[@]}"; do
      /usr/bin/grep -Fq "${value}" "${strings_file}" || {
        print -u2 "diagnostic string missing from ${arch} slice: ${value}"
        exit 1
      }
    done
  fi
done

source_required=(
  'findMethodAndHook('
  '"School.LiveMain.LiveConnectMrsPlayerPresenter"'
  '"School.LiveMain.WithArchiveContentTypeSelector"'
  '"School.LiveMain.VideoArchiveSeekBarPresenter"'
  '"School.LiveMain.ILiveSystemPresenter.Initialize"'
  '"Execute"'
  '"WithMeets.Archive.MotionCaptureReplay.Enable"'
  '"WithMeets.Archive.IarcFullSeek.Enable"'
  '"WithMeets.Archive.IarcReplayOverlay.Suppress"'
  '"WithMeets.Archive.RenderImageCover.Suppress"'
  '"WithMeets.Archive.PlayPauseButton.Enable"'
  '"WithMeets.Archive.OrientationRepair.Enable"'
  '"WithMeets.After.ValidAdmissionRepair.Enable"'
  '"FesArchive.CameraControl.Enable"'
  '"FesArchive.MotionCaptureReplay.Enable"'
  '"FesArchive.MotionCaptureReplay.UrlMap"'
  '"FesArchive.ValidTicketRepair.TargetArchiveIds"'
  '"CameraControl.UI.ScreenshotHide.Enable"'
  '#define LVI_WITH_AFTER_REPAIR 1'
  '#if LVI_WITH_AFTER_REPAIR'
  '#include "WMArchiveCatalog.inc"'
  'kLVIWithArchiveCatalogCount'
  '"ActivityRecord.LandscapeRepair.Enable"'
  'hooked_PlayerGameViewUtilsImpl_SetLandscapeImpl'
  'lviActivityOrientationPassthroughActive'
  'lviWithArchiveOrientationPassthroughActive'
  '"IsHorizontal"'
  '"ArchiveUrl"'
  '"VideoUrl"'
  '"Inspix.AlphaBlendCamera"'
  '"School.LiveMain.LiveSystemModels"'
  '"School.LiveMain.ArchiveSeekBarView"'
  '"SetSeekLimit"'
  '"UpdateCameras"'
  'contentType == 5'
  'lviWithArchiveFullSeekActive.load(std::memory_order_acquire)'
  'lviWithArchiveFullSeekPlayPositionModel'
  'lviWithArchiveFullSeekControlModel'
  'lviWithArchiveFalseEndSuppressionReported'
  'lviWithArchiveReplayPredicateClosureClass'
  'lviWithArchiveIarcFullSeekMatchesPlayPositionModel(self)'
  'original_LiveConnectPlayPositionModel_IsPlayToEnd'
  'hooked_LiveConnectPlayPositionModel_IsPlayToEnd'
  'lviWithArchiveIarcIsPrematurePlayToEnd'
  'lviWithArchiveReplayPredicateMatches(self)'
  'lviForceWithArchiveIarcFullPlayableLength(models)'
  '"ConnectControlModel"'
  '"connectControlModel"'
  '"School.LiveMain.LiveConnectControlModel"'
  'hooked_ArchiveReplayButtonPresenter_ReplayPredicate'
  'installLVIWithArchiveReplayOverlayHook()'
  '"Inspix.CoverImageCommandReceiver"'
  '"Inspix.LiveMain.AppsCoverScreen"'
  '"SetActiveCoverImage"'
  'hooked_CoverImageCommandReceiver_Awake'
  'hooked_AppsCoverScreen_SetActiveCoverImage'
  'lviWithArchiveRenderImageCoverSuppressionActive'
  'lviWithArchiveLifecycleScopeActive'
  'lviCancelWithArchivePendingLifecycleScope'
  'active && !suppress'
  'lviWithArchiveControlPlay(controlModel, nullptr)'
  'lviWithArchiveControlPause(controlModel, nullptr)'
  'lviActivateWithArchivePlayPause(models)'
  'lviClearWithArchivePlayPause()'
  'lviWithArchivePlayPauseRefreshGeneration'
  'lviScheduleWithArchivePlayPauseRefresh'
  '[lviWithArchivePlayPauseButton removeFromSuperview]'
  '"SetPlayableLengthRate"'
  'std::isfinite(requestedRate)'
  'requestedRate > 0.0f'
  'requestedRate < 1.0f'
  'effectiveRate = 1.0f'
  'lviClearWithArchiveIarcFullSeek(self)'
  'LVICameraVisibilityTab'
  'lviCameraUIUserCollapsed'
  'lviClearPendingCameraInput'
  'lviHeldPitchDirection'
  '"CameraControl.HoldPitchDegreesPerSecond"'
  'CGRectMake(8, 82, 36, 70)'
  'CGRectMake(8, 160, 36, 70)'
  'lviCameraControlPanel.hidden = collapsed'
  'lviCameraJoystickPanel.hidden ='
  'lviWithMeetsAfterEnterResponse'
  'lviReadExactInstanceField'
  'lviWriteExactInstanceField'
  'lviReadWithMeetsAfterArchiveList'
  'lviWithMeetsAfterRowEvidence'
  'lviCacheWithMeetsAfterEvidence'
  'lviIngestWithMeetsAfterEvidence'
  'lviConfirmWithMeetsAfterRequest'
  'lviConsumeConfirmedWithMeetsAfterRequest'
  'lviMatchWithMeetsAfterPlayerFactoryScope'
  'lviConsumeWithMeetsAfterPlayerAdmissionScope'
  'hooked_WithConnectModelsFactory_CreateOwnGiftPointModel'
  'hooked_GiftPointModel_ctor'
  'hooked_LiveConnectChapterModel_SetExtraAdmission'
  '"after-player-chapter-admission"'
  'lviWithMeetsAfterPlayerFactoryScopeGeneration'
  'lviWithMeetsAfterResponseHasAdmissionEvidence'
  'lviWithMeetsAfterResponseHasExtendedDuration'
  'lviWithMeetsAfterResponseHasExtraChapter'
  'lviWithMeetsLiveInfoArrayClass'
  'lviWithMeetsArchiveChapterArrayClass'
  'IL2CPP::Functions.m_ArrayGetClass'
  'items->m_pClass != lviWithMeetsLiveInfoArrayClass()'
  'items->m_pClass != lviWithMeetsArchiveChapterArrayClass()'
  'totalIncludingExtra > totalWithoutExtra'
  '"Tecotec.SchoolConnectArchiveListViewModel"'
  '"CreateArchiveList"'
  '"AddToArchiveList"'
  '"Org.OpenAPITools.Model.GetWithArchiveDataRequest"'
  '"<LiveType>k__BackingField"'
  'if (liveType != 2)'
  'lviAfterLiveIdByArchivesId.find(requested)'
  'requestId != confirmed.archivesId'
  'struct alignas(8) LVIUniTaskResult'
  'sizeof(LVIUniTaskResult) == 16'
  'original_LiveMain_BasePopup_OpenAsync(self, methodInfo)'
  '"School.LiveMain.WithConnectModelsFactory"'
  '"School.LiveMain.ILiveSystemModelsFactory.CreateOwnGiftPointModel"'
  '"School.LiveMain.GiftPointModel"'
  'LVICameraScene::FesArchive'
  'lviFesCameraSessionActive'
  'lviCacheFesCamera'
  'lviPublishSelectedFesCamera'
  'lviResetFesArchiveCameraAdapter'
  '"School.LiveMain.FesLiveCameraSwitcher"'
  '"SwitchCamera"'
  'hooked_FesLiveCameraSwitcher_SwitchCamera'
  'hooked_FesLiveFixedCamera_GetCamera'
  'hooked_IdolTargetingCamera_GetCamera'
  'configuredFesArchiveTargetAllows'
  'hooked_FesConnectModelsFactory_CreateCameraSelectModelDirect'
  'hooked_FesArchiveEnterResponseCache_ctor'
  'original_FesArchiveEnterResponseCache_ctor'
  '"School.LiveMain.FesArchiveEnterResponseCache"'
  'lviConfiguredVerifiedFesArchive1228MotionURL'
  'lviPrepareExactFesArchive1228MotionResponse'
  '"<ArchiveUrl>k__BackingField"'
  '"<VideoUrl>k__BackingField"'
  '"set_ArchiveUrl"'
  '"set_VideoUrl"'
  'IL2CPP::String::New'
  '"https://assets.link-like-lovelive.app/archive/hls/20251228/index.m3u8"'
  '"20251228195000-5f0cc1ec-e91e-4287-9263-0327686c0b07/"'
  '"811c9dc5a5f86.md"'
  '"af23d18c-ba54-41cd-b69e-af391744a6e9"'
  '"8ccceeea-2c46-4ecd-a57d-703376ac5c81"'
)

for value in "${source_required[@]}"; do
  /usr/bin/grep -Fq "${value}" "${ROOT}/Tweak.xm" || {
    print -u2 "required source marker missing: ${value}"
    exit 1
  }
done

if /usr/bin/grep -Fq \
  'hooked_FesArchiveContentTypeSelector_ExecuteAsync_MoveNext' \
  "${ROOT}/Tweak.xm"; then
  print -u2 \
    "unsafe by-value Fes archive ExecuteAsync state-machine hook remains"
  exit 1
fi

unsafe_fes_route_markers=(
  'hooked_GetFesArchiveDataResponse_get_VideoUrl'
  'hooked_GetFesArchiveDataResponseAllOf_get_VideoUrl'
  'hooked_LiveEnterContentTypeSelector_CreateContentTypeSelectedScope'
  'lviPrepareFesArchiveMotionResponse'
)
for value in "${unsafe_fes_route_markers[@]}"; do
  if /usr/bin/grep -Fq "${value}" "${ROOT}/Tweak.xm"; then
    print -u2 "unsafe Fes archive route marker remains: ${value}"
    exit 1
  fi
done

if /usr/bin/grep -Fq 'm_pElementClass' "${ROOT}/Tweak.xm"; then
  print -u2 \
    "version-private Il2CppClass element layout access remains in Tweak.xm"
  exit 1
fi

/usr/bin/grep -Fq \
  'https://assets.link-like-lovelive.app/archive/hls/20250823/index.m3u8' \
  "${ROOT}/WMArchiveCatalog.inc"
/usr/bin/grep -Fq \
  'https://assets.link-like-lovelive.app/archive/hls/20260328/index.m3u8' \
  "${ROOT}/WMArchiveCatalog.inc"
catalog_count=$(/usr/bin/grep -c '^    {"' "${ROOT}/WMArchiveCatalog.inc")
[[ "${catalog_count}" == "59" ]] || {
  print -u2 "unexpected WM archive catalog count: ${catalog_count}"
  exit 1
}

/usr/bin/python3 -m json.tool "${ROOT}/LinkuraVisualsIOS.json" >/dev/null
/usr/bin/python3 -m json.tool "${ROOT}/IL2CPP_OFFSETS_5.0.1.json" >/dev/null
/usr/bin/python3 - "${ROOT}" <<'PY'
import json
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])
config = json.loads((root / "LinkuraVisualsIOS.json").read_text(encoding="utf-8"))
if config.get("WithMeets.After.ValidAdmissionRepair.Enable") is not True:
    raise SystemExit("0.9.0 package JSON must explicitly enable valid AFTER repair")
if config.get("WithMeets.Archive.IarcFullSeek.Enable") is not True:
    raise SystemExit("0.9.0 package JSON must explicitly enable WM/IARC full seek")
if config.get("WithMeets.Archive.IarcReplayOverlay.Suppress") is not True:
    raise SystemExit(
        "0.9.0 package JSON must explicitly enable WM/IARC REPLAY "
        "overlay suppression"
    )
if config.get("WithMeets.Archive.RenderImageCover.Suppress") is not True:
    raise SystemExit(
        "0.9.0 package JSON must explicitly enable WM archive render-cover "
        "suppression"
    )
if config.get("WithMeets.Archive.PlayPauseButton.Enable") is not True:
    raise SystemExit(
        "0.9.0 package JSON must explicitly enable the WM archive "
        "play/pause button"
    )
if config.get("CameraControl.HoldPitchDegreesPerSecond") != 60.0:
    raise SystemExit(
        "0.9.0 package JSON must set continuous pitch speed to 60 degrees/s"
    )
if config.get("FesArchive.CameraControl.Enable") is not True:
    raise SystemExit(
        "0.9.0 package JSON must explicitly enable Fes archive camera control"
    )
if config.get("FesArchive.MotionCaptureReplay.Enable") is not True:
    raise SystemExit(
        "0.9.0 package JSON must explicitly enable exact-target Fes motion replay"
    )
expected_fes_hls = (
    "https://assets.link-like-lovelive.app/archive/hls/20251228/index.m3u8"
)
expected_fes_motion = (
    "https://assets.link-like-lovelive.app/archive/alst/"
    "20251228195000-5f0cc1ec-e91e-4287-9263-0327686c0b07/"
    "811c9dc5a5f86.md"
)
fes_motion_map = config.get("FesArchive.MotionCaptureReplay.UrlMap")
if (
    not isinstance(fes_motion_map, dict)
    or fes_motion_map.get(expected_fes_hls) != expected_fes_motion
):
    raise SystemExit(
        "0.9.0 package JSON must contain the exact verified 2025-12-28 "
        "HLS -> ALST/IARC mapping"
    )
if config.get("FesArchive.ValidTicketRepair.Enable") is not True:
    raise SystemExit(
        "0.9.0 package JSON must explicitly enable valid Fes ticket repair"
    )
if config.get("FesArchive.ValidTicketRepair.TicketRank") != 6:
    raise SystemExit("0.9.0 package JSON must preserve S ticket rank 6")
if config.get("FesArchive.ValidTicketRepair.SelectableCameraTypes") != [1, 2, 3, 4]:
    raise SystemExit(
        "0.9.0 package JSON must expose the four confirmed Fes camera types"
    )
expected_fes_ids = {
    "af23d18c-ba54-41cd-b69e-af391744a6e9",
    "8ccceeea-2c46-4ecd-a57d-703376ac5c81",
}
actual_fes_ids = config.get("FesArchive.ValidTicketRepair.TargetArchiveIds")
if not isinstance(actual_fes_ids, list) or set(actual_fes_ids) != expected_fes_ids:
    raise SystemExit(
        "0.9.0 package JSON must scope Fes repair to the two confirmed archive IDs"
    )
if config.get("FesArchive.SeekBar.Enable") is not True:
    raise SystemExit(
        "0.9.0 package JSON must explicitly enable the stock Fes archive seek bar"
    )

source = (root / "Tweak.xm").read_text(encoding="utf-8")

mapping_start = source.find(
    "static NSString* lviConfiguredVerifiedFesArchive1228MotionURL()"
)
mapping_end = source.find(
    "\ntypedef void (*original_FesArchiveEnterResponseCacheCtor_t)",
    mapping_start,
)
if mapping_start < 0 or mapping_end < 0:
    raise SystemExit("missing exact 2025-12-28 JSON mapping validator")
mapping_body = source[mapping_start:mapping_end]
for marker in (
    'qualityConfig[@"FesArchive.MotionCaptureReplay.UrlMap"]',
    "kLVIFesArchive1228HLSURL",
    "isEqualToString:kLVIFesArchive1228MotionURL",
    "return kLVIFesArchive1228MotionURL;",
):
    if marker not in mapping_body:
        raise SystemExit(
            "exact 2025-12-28 JSON mapping validator lost marker: " + marker
        )
if "return (NSString*)candidate;" in mapping_body:
    raise SystemExit(
        "verified JSON mapping must authorize the immutable built-in URL, "
        "not return a potentially mutable config object"
    )

repair_start = source.find(
    "static bool lviPrepareExactFesArchive1228MotionResponse("
)
repair_end = source.find(
    "\nstatic void hooked_FesArchiveEnterResponseCache_ctor(",
    repair_start,
)
if repair_start < 0 or repair_end < 0:
    raise SystemExit("missing exact 2025-12-28 Fes cache repair body")
repair_body = source[repair_start:repair_end]
for marker in (
    '"Org.OpenAPITools.Model",',
    '"GetFesArchiveDataResponse"',
    '"<ArchiveUrl>k__BackingField"',
    '"<VideoUrl>k__BackingField"',
    "kLVIFesArchive1228MotionURL",
    "kLVIFesArchive1228HLSURL",
    "lviConfiguredVerifiedFesArchive1228MotionURL()",
    'GetMethodPointer("set_ArchiveUrl", 1)',
    'GetMethodPointer("set_VideoUrl", 1)',
    "IL2CPP::String::New",
    "archiveMissing",
    "storedVideoUrl != nullptr",
    "rollbackVerified",
    "videoRollbackVerified",
    "archiveRollbackVerified",
):
    if marker not in repair_body:
        raise SystemExit(
            "exact 2025-12-28 Fes cache repair lost safety marker: " + marker
        )
for forbidden in (
    "GetMemberValue",
    "SetMemberValue",
    "replaceManagedFesArchiveCameraTypeList",
    "lviClearManagedList",
    "SelectableCameraTypes",
    "Timelines",
    "GiftPtRankings",
    "lviCanonicalArchiveURL",
):
    if forbidden in repair_body:
        raise SystemExit(
            "exact 2025-12-28 Fes cache repair became destructive: "
            + forbidden
        )

set_archive_resolve = repair_body.find(
    'GetMethodPointer("set_ArchiveUrl", 1)'
)
set_video_resolve = repair_body.find(
    'GetMethodPointer("set_VideoUrl", 1)'
)
managed_string_create = repair_body.find("IL2CPP::String::New")
set_archive_call = repair_body.find(
    "response->CallMethodSafe<void, Unity::System_String*>(\n"
    "\t\t\tsetArchiveUrl,"
)
archive_reread = repair_body.find(
    '"<ArchiveUrl>k__BackingField"',
    set_archive_call,
)
set_video_call = repair_body.find(
    "response->CallMethodSafe<void, Unity::System_String*>(\n"
    "\t\tsetVideoUrl,"
)
video_reread = repair_body.find(
    '"<VideoUrl>k__BackingField"',
    set_video_call,
)
if not (
    0 <= set_archive_resolve < managed_string_create
    and 0 <= set_video_resolve < managed_string_create
    and managed_string_create < set_archive_call < archive_reread
    and archive_reread < set_video_call < video_reread
):
    raise SystemExit(
        "exact 2025-12-28 URL repair must resolve both stock setters, "
        "create/store/verify ArchiveUrl, then clear/verify VideoUrl"
    )
if repair_body.count("setArchiveUrl,") < 3:
    raise SystemExit(
        "exact 2025-12-28 repair must restore the original ArchiveUrl "
        "after either post-write verification failure"
    )
if repair_body.count("setVideoUrl,") < 2:
    raise SystemExit(
        "exact 2025-12-28 repair must restore the original VideoUrl "
        "when clearing cannot be verified"
    )

ctor_start = source.find(
    "static void hooked_FesArchiveEnterResponseCache_ctor("
)
ctor_end = source.find(
    "\nstatic bool managedStringsHaveEqualValue(",
    ctor_start,
)
if ctor_start < 0 or ctor_end < 0:
    raise SystemExit("missing Fes archive response-cache constructor hook")
ctor_body = source[ctor_start:ctor_end]
stock_ctor_call = ctor_body.find(
    "original_FesArchiveEnterResponseCache_ctor("
)
exact_repair_call = ctor_body.find(
    "lviPrepareExactFesArchive1228MotionResponse(response)"
)
if (
    stock_ctor_call < 0
    or exact_repair_call < 0
    or stock_ctor_call >= exact_repair_call
):
    raise SystemExit(
        "Fes cache hook must call the stock constructor before exact repair"
    )

cache_installers = re.findall(
    r'findMethodAndHook\(\s*'
    r'"School\.LiveMain\.FesArchiveEnterResponseCache"\s*,\s*'
    r'"\.ctor"\s*,\s*1\s*,\s*'
    r'\(void\*\)hooked_FesArchiveEnterResponseCache_ctor',
    source,
    re.DOTALL,
)
if len(cache_installers) != 1:
    raise SystemExit(
        "Fes archive route repair must install exactly one cache ctor hook"
    )

match = re.search(
    r"static bool lviWithMeetsValidAfterRepairEnabled\(\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing lviWithMeetsValidAfterRepairEnabled")
body = match.group("body")
if not re.search(
    r'configBoolDefault\(\s*'
    r'@"WithMeets\.After\.ValidAdmissionRepair\.Enable"\s*,\s*'
    r"false\s*\)",
    body,
    re.DOTALL,
):
    raise SystemExit("AFTER repair must remain fail-closed when the key is absent")

match = re.search(
    r"static bool lviWithArchiveIarcFullSeekEnabled\(\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing lviWithArchiveIarcFullSeekEnabled")
body = match.group("body")
if not re.search(
    r'configBoolDefault\(\s*'
    r'@"WithMeets\.Archive\.IarcFullSeek\.Enable"\s*,\s*'
    r"false\s*\)",
    body,
    re.DOTALL,
):
    raise SystemExit("WM/IARC full seek must remain fail-closed when the key is absent")

match = re.search(
    r"static bool "
    r"lviWithArchiveIarcReplayOverlaySuppressionEnabled\(\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit(
        "missing lviWithArchiveIarcReplayOverlaySuppressionEnabled"
    )
body = match.group("body")
if "lviWithArchiveIarcFullSeekEnabled()" not in body:
    raise SystemExit(
        "WM/IARC REPLAY suppression must remain scoped to full-seek mode"
    )
if not re.search(
    r'configBoolDefault\(\s*'
    r'@"WithMeets\.Archive\.IarcReplayOverlay\.Suppress"\s*,\s*'
    r"true\s*\)",
    body,
    re.DOTALL,
):
    raise SystemExit(
        "WM/IARC REPLAY suppression must default on only inside "
        "full-seek mode"
    )

match = re.search(
    r"static bool "
    r"lviWithArchiveRenderImageCoverSuppressionEnabled\(\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit(
        "missing lviWithArchiveRenderImageCoverSuppressionEnabled"
    )
body = match.group("body")
if not re.search(
    r'configBoolDefault\(\s*'
    r'@"WithMeets\.Archive\.RenderImageCover\.Suppress"\s*,\s*'
    r"false\s*\)",
    body,
    re.DOTALL,
):
    raise SystemExit(
        "WM archive render-cover suppression must remain fail-closed when "
        "the key is absent"
    )

match = re.search(
    r"static bool lviWithArchivePlayPauseButtonEnabled\(\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing lviWithArchivePlayPauseButtonEnabled")
body = match.group("body")
if not re.search(
    r'configBoolDefault\(\s*'
    r'@"WithMeets\.Archive\.PlayPauseButton\.Enable"\s*,\s*'
    r"false\s*\)",
    body,
    re.DOTALL,
):
    raise SystemExit(
        "WM archive play/pause button must remain fail-closed when the key "
        "is absent"
    )

if "PlayFromStartAsync" in source:
    raise SystemExit(
        "WM archive play/pause button must never restart playback from zero"
    )
for marker in (
    '"School.LiveMain.LiveConnectControlModel",\n'
    '\t\t\t\t\t"Play",',
    '"School.LiveMain.LiveConnectControlModel",\n'
    '\t\t\t\t\t"Pause",',
    "*contentType == 4 || *contentType == 5",
    "lviActivateWithArchivePlayPause(models);",
    "lviClearWithArchivePlayPause();",
    "lviScheduleWithArchivePlayPauseRefresh(refreshGeneration, 250);",
    "lviWithArchivePlayPauseRefreshGeneration.fetch_add(",
    "[lviWithArchivePlayPauseButton removeFromSuperview];",
):
    if marker not in source:
        raise SystemExit(
            "WM archive play/pause integration lost required scope: "
            + marker
        )

camera_reset_match = re.search(
    r"static void lviResetWithArchiveCameraAdapter\(\)\s*\{(?P<body>.*?)\n\}",
    source,
    re.S,
)
if not camera_reset_match:
    raise SystemExit("missing WM archive camera reset boundary")
if "lviClearWithArchivePlayPause();" not in camera_reset_match.group("body"):
    raise SystemExit(
        "WM archive camera reset must remove the play/pause overlay"
    )

pause_refresh_start = source.find(
    "static void lviRefreshWithArchivePlayPauseButtonOnMain() {"
)
pause_refresh_end = source.find(
    "\nstatic void lviScheduleWithArchivePlayPauseRefresh(",
    pause_refresh_start,
)
if pause_refresh_start < 0 or pause_refresh_end < 0:
    raise SystemExit("missing WM archive play/pause refresh body")
pause_refresh_body = source[pause_refresh_start:pause_refresh_end]
for marker in (
    "lviCameraUIEffectiveCollapsed()",
    "cameraUIHiddenForScreenshot",
    "[lviWithArchivePlayPauseButton cancelTrackingWithEvent:nil];",
    "lviWithArchivePlayPauseButton.hidden = YES;",
):
    if marker not in pause_refresh_body:
        raise SystemExit(
            "WM play/pause refresh must honor the shared camera UI hide "
            "state: " + marker
        )

effective_collapse_start = source.find(
    "static bool lviCameraUIEffectiveCollapsed() {"
)
effective_collapse_end = source.find("\n}", effective_collapse_start)
if effective_collapse_start < 0 or effective_collapse_end < 0:
    raise SystemExit("missing shared effective camera UI collapse helper")
effective_collapse_body = source[
    effective_collapse_start:effective_collapse_end
]
for marker in (
    '@"CameraControl.UI.ScreenshotHide.Enable"',
    "lviCameraUIUserCollapsed.load(std::memory_order_acquire)",
):
    if marker not in effective_collapse_body:
        raise SystemExit(
            "effective camera UI collapse helper lost required state: "
            + marker
        )

camera_layout_start = source.find(
    "static void lviRefreshCameraOverlayLayoutOnMain() {"
)
camera_layout_end = source.find(
    "\nstatic void publishLVICameraPanel(",
    camera_layout_start,
)
if camera_layout_start < 0 or camera_layout_end < 0:
    raise SystemExit("missing camera overlay layout body")
if "bool collapsed = lviCameraUIEffectiveCollapsed();" not in source[
    camera_layout_start:camera_layout_end
]:
    raise SystemExit(
        "camera panels and WM play/pause must share the same effective "
        "collapse state"
    )

visibility_tab_start = source.find(
    "- (void)visibilityTabPressed:(UIButton *)sender {"
)
visibility_tab_end = source.find("\n}\n\n@end", visibility_tab_start)
if visibility_tab_start < 0 or visibility_tab_end < 0:
    raise SystemExit("missing camera visibility-tab action body")
visibility_tab_body = source[visibility_tab_start:visibility_tab_end]
if "lviRefreshWithArchivePlayPauseButtonOnMain();" not in visibility_tab_body:
    raise SystemExit(
        "camera visibility tab must immediately refresh the WM play/pause "
        "button"
    )

for marker in (
    "static std::atomic<float> lviHeldPitchDirection { 0.0f };",
    "lviHeldPitchDirection.store(-value, std::memory_order_release);",
    "lviHeldPitchDirection.store(value, std::memory_order_release);",
    '@"CameraControl.HoldPitchDegreesPerSecond",',
    "CGRectMake(8, 82, 36, 70)",
    "CGRectMake(8, 160, 36, 70)",
    "CGRectGetWidth(lviCameraJoystickPanel.bounds) - 16.0",
    "216.0,\n\t\t\t236.0",
):
    if marker not in source:
        raise SystemExit(
            "continuous pitch/right-panel geometry lost required behavior: "
            + marker
        )

if source.count("lviResetHeldCameraInput();") < 4:
    raise SystemExit(
        "continuous camera input must be reset on every panel/scene exit path"
    )

if not re.search(
    r"result\.enterResult\s*==\s*2\s*&&\s*"
    r"\(result\.contentType\s*==\s*4\s*\|\|\s*"
    r"result\.contentType\s*==\s*5\)",
    source,
    re.DOTALL,
):
    raise SystemExit(
        "failed/cancelled WM archive selector results must close the "
        "pending cover lifecycle scope"
    )
if "lviCancelWithArchivePendingLifecycleScope();" not in source:
    raise SystemExit(
        "missing pending WM archive lifecycle cancellation"
    )

match = re.search(
    r"static bool "
    r"lviWithArchiveRenderImageCoverSuppressionActive\(\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit(
        "missing lviWithArchiveRenderImageCoverSuppressionActive"
    )
body = match.group("body")
for marker in (
    "lviWithArchiveRenderImageCoverSuppressionEnabled()",
    "lviWithArchiveLifecycleScopeActive()",
):
    if marker not in body:
        raise SystemExit(
            "WM archive render-cover suppression lost lifecycle scope: "
            + marker
        )

cover_receiver_hook_targets = re.findall(
    r'findMethodAndHook\(\s*'
    r'"Inspix\.CoverImageCommandReceiver"\s*,\s*'
    r'"Awake"\s*,\s*'
    r'0\s*,\s*'
    r'\(void\*\)\s*'
    r'hooked_CoverImageCommandReceiver_Awake\s*,\s*'
    r'\(void\*\*\)\s*'
    r'&original_CoverImageCommandReceiver_Awake\s*'
    r'\)',
    source,
    re.DOTALL,
)
if len(cover_receiver_hook_targets) != 1:
    raise SystemExit(
        "CoverImageCommandReceiver.Awake must have exactly one exact hook "
        "installer"
    )

cover_screen_hook_targets = re.findall(
    r'findMethodAndHook\(\s*'
    r'"Inspix\.LiveMain\.AppsCoverScreen"\s*,\s*'
    r'"SetActiveCoverImage"\s*,\s*'
    r'1\s*,\s*'
    r'\(void\*\)\s*'
    r'hooked_AppsCoverScreen_SetActiveCoverImage\s*,\s*'
    r'\(void\*\*\)\s*'
    r'&original_AppsCoverScreen_SetActiveCoverImage\s*'
    r'\)',
    source,
    re.DOTALL,
)
if len(cover_screen_hook_targets) != 1:
    raise SystemExit(
        "AppsCoverScreen.SetActiveCoverImage(Boolean) must have exactly one "
        "exact hook installer"
    )

match = re.search(
    r"static void hooked_CoverImageCommandReceiver_Awake"
    r"\(\s*void \*self,\s*void \*methodInfo\s*\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing CoverImageCommandReceiver.Awake hook body")
body = match.group("body")
if (
    "lviWithArchiveRenderImageCoverSuppressionActive()" not in body
    or "return;" not in body
    or "original_CoverImageCommandReceiver_Awake(" not in body
):
    raise SystemExit(
        "CoverImageCommandReceiver.Awake hook lost scoped early-return "
        "behavior"
    )
if body.index("return;") > body.index(
    "original_CoverImageCommandReceiver_Awake("
):
    raise SystemExit(
        "CoverImageCommandReceiver.Awake must suppress before calling stock"
    )

match = re.search(
    r"static void hooked_AppsCoverScreen_SetActiveCoverImage"
    r"\(\s*void \*self,\s*bool active,\s*void \*methodInfo\s*\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing AppsCoverScreen.SetActiveCoverImage hook body")
body = match.group("body")
for marker in (
    "lviWithArchiveRenderImageCoverSuppressionActive()",
    "original_AppsCoverScreen_SetActiveCoverImage(",
    "active && !suppress",
):
    if marker not in body:
        raise SystemExit(
            "AppsCoverScreen.SetActiveCoverImage lost scoped false-forward: "
            + marker
        )

for forbidden in (
    "WithLiveBeforeImagePresenter",
    "DestroyImage",
):
    if forbidden in source:
        raise SystemExit(
            "WM render-cover suppression expanded beyond exact endpoints: "
            + forbidden
        )

hook_targets = re.findall(
    r'findMethodAndHook\(\s*'
    r'"School\.LiveMain\.ArchiveSeekBarView"\s*,\s*'
    r'"SetSeekLimit"',
    source,
    re.DOTALL,
)
if len(hook_targets) != 1:
    raise SystemExit(
        "ArchiveSeekBarView.SetSeekLimit must have exactly one hook installer"
    )

playable_rate_hook_targets = re.findall(
    r'findMethodAndHook\(\s*'
    r'"School\.LiveMain\.LiveConnectPlayPositionModel"\s*,\s*'
    r'"SetPlayableLengthRate"',
    source,
    re.DOTALL,
)
if len(playable_rate_hook_targets) != 1:
    raise SystemExit(
        "LiveConnectPlayPositionModel.SetPlayableLengthRate must have "
        "exactly one hook installer"
    )

play_to_end_hook_targets = re.findall(
    r'findInstanceBoolFuncMethodAndHook\(\s*'
    r'"School\.LiveMain\.LiveConnectPlayPositionModel"\s*,\s*'
    r'"IsPlayToEnd"\s*,\s*'
    r'\(void\*\)\s*'
    r'hooked_LiveConnectPlayPositionModel_IsPlayToEnd\s*,\s*'
    r'\(void\*\*\)\s*'
    r'&original_LiveConnectPlayPositionModel_IsPlayToEnd\s*'
    r'\)',
    source,
    re.DOTALL,
)
if len(play_to_end_hook_targets) != 1:
    raise SystemExit(
        "LiveConnectPlayPositionModel.IsPlayToEnd must have exactly "
        "one hook installer"
    )

exact_predicate_helper = re.search(
    r"static bool findInstanceBoolFuncMethodAndHook"
    r"\(.*?\)\s*\{(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not exact_predicate_helper:
    raise SystemExit("missing exact instance Boolean/Func predicate resolver")
exact_predicate_body = exact_predicate_helper.group("body")
for marker in (
    "IL2CPP::Class::Utils::GetMethod(",
    "method->m_pClass != declaringClass",
    "method->m_uArgsCount != 1",
    "(method->m_uFlags & 0x0010) != 0",
    "IL2CPP::Class::Utils::GetMethodParamType(method, 0)",
    "IL2CPP::Class::Utils::ClassFromType(",
    '"Boolean"',
    '"Func`1"',
    "method->m_pMethodPointer",
):
    if marker not in exact_predicate_body:
        raise SystemExit(
            "exact instance Boolean/Func predicate resolver lost ABI guard: "
            + marker
        )

match = re.search(
    r"static bool "
    r"hooked_LiveConnectPlayPositionModel_IsPlayToEnd"
    r"\(\s*void \*self,\s*void \*isPlayToEndDelegate,\s*"
    r"void \*methodInfo\s*\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing WM/IARC false-end suppression hook body")
body = match.group("body")
for marker in (
    "original_LiveConnectPlayPositionModel_IsPlayToEnd(",
    "stockValue &&",
    "lviWithArchiveIarcReplayOverlaySuppressionEnabled()",
    "lviWithArchiveIarcIsPrematurePlayToEnd(",
    "return suppress ? false : stockValue;",
):
    if marker not in body:
        raise SystemExit(
            "WM/IARC false-end suppression lost exact stock-first scope: "
            + marker
        )

match = re.search(
    r"static bool lviWithArchiveIarcIsPrematurePlayToEnd"
    r"\(\s*void \*playPositionModel,\s*float& contentsLength,\s*"
    r"float& seekTime,\s*float& playableLengthRate\s*\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing exact WM/IARC premature-end classifier")
body = match.group("body")
for marker in (
    "lviWithArchiveIarcFullSeekMatchesPlayPositionModel(",
    "model + 0x10",
    "model + 0x18",
    "model + 0x20",
    "sizeof(Unity::il2cppObject)",
    "seekTime + 0.5f < contentsLength",
):
    if marker not in body:
        raise SystemExit(
            "WM/IARC premature-end classifier lost real-end scope: "
            + marker
        )

if "playableLengthRate < 0.999f" in body:
    raise SystemExit(
        "WM/IARC premature-end classifier must not depend on the playable "
        "rate normalized by full-seek repair"
    )

if "lviClearWithArchiveIarcFullSeek(self);" not in source:
    raise SystemExit(
        "WM/IARC full-seek ownership must clear from exact-owner Dispose"
    )

seek_initializer = re.search(
    r"static void hooked_VideoArchiveSeekBarPresenter_Initialize"
    r"\(.*?\)\s*\{(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not seek_initializer:
    raise SystemExit("missing VideoArchiveSeekBarPresenter initializer hook")
seek_initializer_body = seek_initializer.group("body")
if "lviClearWithArchiveIarcFullSeek(" in seek_initializer_body:
    raise SystemExit(
        "seek-bar re-entry must not clear the active WM/IARC owner"
    )
for marker in (
    'configBool(@"FesArchive.SeekBar.Enable")',
    "sceneType == 5",
    "*contentType == 5",
    "exposeWithArchiveSeekBar || exposeFesArchiveSeekBar",
    "*contentType = 4;",
    "*contentType = originalContentType;",
):
    if marker not in seek_initializer_body:
        raise SystemExit(
            "Fes archive stock seek-bar scope/restore invariant is missing: "
            + marker
        )

if "lviJoystickSensitivityIndex" not in source:
    raise SystemExit("missing shared joystick sensitivity state")
if "static constexpr int multipliers[] = { 1, 5, 10, 20 };" not in source:
    raise SystemExit(
        "joystick sensitivity choices must remain exactly x1/x5/x10/x20"
    )
if "if (index < 0 || index >= 4)" not in source:
    raise SystemExit("joystick sensitivity index must cover all four choices")
if "% 4;" not in source:
    raise SystemExit("joystick sensitivity selector must cycle through four choices")
if "_sensitivityButton.frame = CGRectMake(8, 7, 36, 69);" not in source:
    raise SystemExit("joystick sensitivity selector lost its dedicated panel column")
if (
    ") * static_cast<float>(lviJoystickSensitivityMultiplier());"
    not in source
):
    raise SystemExit("joystick translation no longer applies the selected multiplier")

hook_install_body_match = re.search(
    r"bool withArchiveOrientationRepair =.*?"
    r"bool seekLimitHookNeeded = withArchiveIarcFullSeek;",
    source,
    re.DOTALL,
)
if not hook_install_body_match:
    raise SystemExit("archive seek-bar hook installation block is missing")
hook_install_body = hook_install_body_match.group(0)
for marker in (
    'bool fesArchiveSeekBar =',
    'configBool(@"FesArchive.SeekBar.Enable")',
    'withArchivePlayPauseButton ||\n\t\tfesArchiveSeekBar',
):
    if marker not in hook_install_body:
        raise SystemExit(
            "Fes-only configuration no longer installs the stock seek adapter: "
            + marker
        )

replay_closure_targets = re.findall(
    r'IL2CPP::Class::Utils::GetNestedClass\(\s*'
    r'"School\.LiveMain\.ArchiveReplayButtonPresenter"\s*,\s*'
    r'"<>c__DisplayClass5_0"\s*\)',
    source,
    re.DOTALL,
)
if len(replay_closure_targets) != 1:
    raise SystemExit(
        "ArchiveReplayButtonPresenter replay closure must have exactly "
        "one metadata lookup"
    )

replay_predicate_hook_targets = re.findall(
    r'findMethodAndHook\(\s*'
    r'replayClosure\s*,\s*'
    r'"<School\.LiveMain\.ILiveSystemPresenter\.Initialize>b__0"\s*,\s*'
    r'0\s*,\s*'
    r'\(void\*\)\s*'
    r'hooked_ArchiveReplayButtonPresenter_ReplayPredicate\s*,\s*'
    r'\(void\*\*\)\s*'
    r'&original_ArchiveReplayButtonPresenter_ReplayPredicate\s*'
    r'\)',
    source,
    re.DOTALL,
)
if len(replay_predicate_hook_targets) != 1:
    raise SystemExit(
        "ArchiveReplayButtonPresenter replay predicate must have exactly "
        "one hook installer"
    )

match = re.search(
    r"static bool lviWithArchiveReplayPredicateMatches"
    r"\(void \*closureSelf\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing exact WM/IARC replay predicate matcher")
body = match.group("body")
for marker in (
    "lviWithArchiveFullSeekActive.load(",
    "lviWithArchiveReplayPredicateClosureClass.load(",
    "closure->m_Object.m_pClass != expectedClosureClass",
    "lviReadExactInstanceField(",
    '"connectControlModel"',
    "lviWithArchiveFullSeekControlModel.load(",
    "controlModel == activeControlModel",
    "lviManagedObjectIsExactClass(",
    '"LiveConnectControlModel"',
):
    if marker not in body:
        raise SystemExit(
            "WM/IARC replay predicate matcher lost exact metadata scope: "
            + marker
        )

match = re.search(
    r"static bool "
    r"hooked_ArchiveReplayButtonPresenter_ReplayPredicate"
    r"\(\s*void \*self,\s*void \*methodInfo\s*\)\s*\{"
    r"(?P<body>.*?)\n\}",
    source,
    re.DOTALL,
)
if not match:
    raise SystemExit("missing WM/IARC replay predicate hook body")
body = match.group("body")
for marker in (
    "original_ArchiveReplayButtonPresenter_ReplayPredicate(",
    "stockValue &&",
    "lviWithArchiveReplayPredicateMatches(self)",
    "return suppress ? false : stockValue;",
):
    if marker not in body:
        raise SystemExit(
            "WM/IARC replay predicate hook no longer preserves stock-first "
            "behavior: " + marker
        )

for forbidden in (
    "original_UnityEngine_GameObject_SetActive",
    "hooked_UnityEngine_GameObject_SetActive",
    "original_ArchiveReplayButtonPresenter_Initialize",
    "hooked_ArchiveReplayButtonPresenter_Initialize",
    "lviWithArchiveReplayPanel",
    "lviCaptureWithArchiveReplayPanel",
    "lviHideCapturedWithArchiveReplayPanel",
):
    if forbidden in source:
        raise SystemExit(
            "unsafe global REPLAY panel interception remains: " + forbidden
        )
PY

/usr/bin/grep -Fq \
  '"-DLVI_WITH_AFTER_REPAIR=${LVI_WITH_AFTER_REPAIR:-1}"' \
  "${ROOT}/build.sh"
/usr/bin/grep -Fq 'Version: 0.9.0' "${ROOT}/control"
/usr/bin/grep -Fq 'VERSION="0.9.0"' "${ROOT}/package_release.sh"
/usr/bin/grep -Fq \
  'NAME="LinkuraVisualsIOS-${VERSION}-fes-seek-joystick-sensitivity"' \
  "${ROOT}/package_release.sh"

PYTHONPYCACHEPREFIX="${VERIFY_DIR}/pycache" \
  /usr/bin/python3 -m py_compile "${ROOT}/verify_after_safety.py"
/usr/bin/python3 "${ROOT}/verify_after_safety.py" "${ROOT}/Tweak.xm"
/usr/bin/python3 "${ROOT}/verify_il2cpp_offsets.py" \
  "${UNITY_FRAMEWORK}" \
  "${ROOT}/IL2CPP_OFFSETS_5.0.1.json"

print "Binary verification passed."
/usr/bin/shasum -a 256 "${DYLIB}"
