#!/usr/bin/env python3
"""Static fail-closed checks for the narrowly scoped WM AFTER repair."""

from __future__ import annotations

import pathlib
import re
import sys


def function_body(source: str, name: str) -> str:
    marker = source.find(name)
    if marker < 0:
        raise AssertionError(f"missing function: {name}")
    opening = source.find("{", marker)
    if opening < 0:
        raise AssertionError(f"missing body for: {name}")
    depth = 0
    for index in range(opening, len(source)):
        char = source[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[opening : index + 1]
    raise AssertionError(f"unterminated body for: {name}")


def require(body: str, needle: str, context: str) -> None:
    if needle not in body:
        raise AssertionError(f"{context}: missing {needle!r}")


def require_pattern(body: str, pattern: str, context: str) -> None:
    if not re.search(pattern, body, re.DOTALL):
        raise AssertionError(f"{context}: pattern did not match {pattern!r}")


def normalized_parameters(parameters: str) -> list[str]:
    return [
        re.sub(r"\s+", " ", parameter.strip()).replace(" *", "*")
        for parameter in parameters.split(",")
        if parameter.strip()
    ]


def function_parameters(source: str, name: str) -> list[str]:
    match = re.search(
        rf"\b{re.escape(name)}\s*\((?P<parameters>.*?)\)\s*\{{",
        source,
        re.DOTALL,
    )
    if not match:
        raise AssertionError(f"missing function signature: {name}")
    return normalized_parameters(match.group("parameters"))


def function_pointer_parameters(source: str, name: str) -> list[str]:
    match = re.search(
        rf"\(\s*\*\s*{re.escape(name)}\s*\)\s*"
        rf"\((?P<parameters>.*?)\)\s*=\s*nullptr\s*;",
        source,
        re.DOTALL,
    )
    if not match:
        raise AssertionError(f"missing function pointer signature: {name}")
    return normalized_parameters(match.group("parameters"))


def require_exact_call(
    body: str,
    name: str,
    expected_arguments: list[str],
    context: str,
) -> None:
    calls = re.findall(
        rf"\b{re.escape(name)}\s*\((?P<arguments>.*?)\)\s*;",
        body,
        re.DOTALL,
    )
    if len(calls) != 1:
        raise AssertionError(
            f"{context}: expected exactly one call to {name}, found "
            f"{len(calls)}"
        )
    arguments = normalized_parameters(calls[0])
    if arguments != expected_arguments:
        raise AssertionError(
            f"{context}: invalid arguments for {name}: {arguments!r}"
        )


def require_exact_hook_installation(
    body: str,
    class_name: str,
    method_name: str,
    parameter_count: int,
    hook_name: str,
    original_name: str,
    context: str,
) -> None:
    # Long IL2CPP explicit-interface method names may be split into adjacent
    # C string literals for formatting. Collapse those literals before
    # validating the exact managed name and hook tuple.
    collapsed_body = body
    adjacent_literals = re.compile(
        r'"(?P<left>[A-Za-z0-9_.$`]+)"\s*'
        r'"(?P<right>[A-Za-z0-9_.$`]+)"'
    )
    while True:
        collapsed_body, replacements = adjacent_literals.subn(
            lambda match: (
                f'"{match.group("left")}{match.group("right")}"'
            ),
            collapsed_body,
        )
        if replacements == 0:
            break
    target_pattern = re.compile(
        r"findMethodAndHook\s*\(\s*"
        rf'"{re.escape(class_name)}"\s*,'
        r".*?\)\s*;",
        re.DOTALL,
    )
    target_calls = target_pattern.findall(collapsed_body)
    if len(target_calls) != 1:
        raise AssertionError(
            f"{context}: expected exactly one explicit hook installation, "
            f"found {len(target_calls)}"
        )
    exact_pattern = re.compile(
        r"findMethodAndHook\s*\(\s*"
        rf'"{re.escape(class_name)}"\s*,\s*'
        rf'"{re.escape(method_name)}"\s*,\s*'
        rf"{parameter_count}\s*,\s*"
        rf"\(\s*void\s*\*\s*\)\s*{re.escape(hook_name)}\s*,\s*"
        rf"\(\s*void\s*\*\s*\*\s*\)\s*&{re.escape(original_name)}\s*"
        r"\)\s*;",
        re.DOTALL,
    )
    if not exact_pattern.fullmatch(target_calls[0]):
        raise AssertionError(
            f"{context}: class may only be hooked as "
            f"{method_name}/{parameter_count} with the verified hook and "
            "original pointer"
        )


def main() -> int:
    path = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "Tweak.xm")
    source = path.read_text(encoding="utf-8")

    if "m_pElementClass" in source:
        raise AssertionError(
            "Tweak source reads version-private Il2CppClass element layout"
        )

    exact_field = function_body(source, "lviExactInstanceField")
    for marker in (
        "IL2CPP::Functions.m_ClassGetFieldFromName",
        "field->m_iOffset >= static_cast<int>(sizeof(Unity::il2cppObject))",
        "field->m_iOffset <= 0x10000",
    ):
        require(exact_field, marker, "exact backing-field lookup")

    exact_read = function_body(source, "lviReadExactInstanceField")
    for marker in (
        "lviExactInstanceField(object, fieldName)",
        "if (!field)",
        "value = {};",
        "object->GetMemberValue<T>(field)",
    ):
        require(exact_read, marker, "exact backing-field read")

    exact_write = function_body(source, "lviWriteExactInstanceField")
    for marker in (
        "lviExactInstanceField(object, fieldName)",
        "if (!field)",
        "object->SetMemberValue<T>(field, value)",
    ):
        require(exact_write, marker, "exact backing-field write")

    enter_response = function_body(
        source, "lviWithMeetsAfterEnterResponse"
    )
    for marker in (
        '"School.LiveMain"',
        '"WithArchiveContentTypeSelector"',
        '"_enterResponseCache"',
        '"WithArchiveEnterResponseCache"',
        '"Value"',
        '"Org.OpenAPITools.Model"',
        '"GetWithArchiveDataResponse"',
    ):
        require(enter_response, marker, "exact selector response")

    admission = function_body(
        source, "lviWithMeetsAfterResponseHasAdmissionEvidence"
    )
    for marker in (
        '"GetWithArchiveDataResponse"',
        '"<HasExtra>k__BackingField"',
        '"<HasExtraAdmission>k__BackingField"',
    ):
        require(admission, marker, "response admission evidence")

    live_info_array = function_body(
        source, "lviWithMeetsLiveInfoArrayClass"
    )
    for marker in (
        "IL2CPP::Functions.m_ArrayGetClass",
        '"Org.OpenAPITools.Model.LiveInfo"',
        "IL2CPP::Functions.m_ArrayGetClass)(liveInfoClass, 1)",
    ):
        require(live_info_array, marker, "LiveInfo array class")

    archive_list = function_body(
        source, "lviReadWithMeetsAfterArchiveList"
    )
    for marker in (
        '"GetArchiveListResponse"',
        '"<ArchiveList>k__BackingField"',
        '"System.Collections.Generic"',
        '"List`1"',
        'lviReadExactInstanceField(archiveList, "_items", items)',
        'lviReadExactInstanceField(archiveList, "_size", count)',
        "items->m_pBounds != nullptr",
        "items->m_pClass != lviWithMeetsLiveInfoArrayClass()",
        "count < 0",
        "count > 10000",
        "static_cast<uintptr_t>(count) > items->m_uMaxLength",
        "items->m_uMaxLength > 100000",
    ):
        require(archive_list, marker, "authoritative archive list")

    row = function_body(source, "lviWithMeetsAfterRowEvidence")
    for marker in (
        '"Org.OpenAPITools.Model"',
        '"LiveInfo"',
        '"<LiveType>k__BackingField"',
        "if (liveType != 2)",
        '"<HasExtra>k__BackingField"',
        '"<HasExtraAdmission>k__BackingField"',
        '"<EarnedStarCount>k__BackingField"',
        '"<GiftStarsThresholdForExtraAdmission>k__BackingField"',
        "hasExtraAdmission ||",
        "earnedStarCount >= admissionThreshold",
        '"<ArchivesId>k__BackingField"',
        '"<LiveId>k__BackingField"',
    ):
        require(row, marker, "WithMeets archive-row evidence")

    cache = function_body(source, "lviCacheWithMeetsAfterEvidence")
    for marker in (
        "entitlement.catalogGeneration = lviAfterCatalogGeneration",
        "lviAmbiguousAfterLiveIds.count(entitlement.liveId)",
        "lviAmbiguousAfterArchivesIds.count(entitlement.archivesId)",
        "lviAfterLiveIdByArchivesId.find(entitlement.archivesId)",
        "reverse->second != entitlement.liveId",
        "lviAfterEntitlementByLiveId.find(entitlement.liveId)",
    ):
        require(cache, marker, "bidirectional catalog cache")

    ingest = function_body(source, "lviIngestWithMeetsAfterEvidence")
    for marker in (
        "lviReadWithMeetsAfterArchiveList(",
        "lviWithMeetsAfterRowEvidence(",
        "lviCacheWithMeetsAfterEvidence(entitlement)",
        "invalid LiveInfo row or entitlement field",
    ):
        require(ingest, marker, "archive-list evidence ingestion")

    duration = function_body(
        source, "lviWithMeetsAfterResponseHasExtendedDuration"
    )
    for marker in (
        '"GetWithArchiveDataResponse"',
        '"<TotalPlayTimeSecondWithoutExtra>k__BackingField"',
        '"<TotalPlayTimeSecondIncludingExtra>k__BackingField"',
        "totalWithoutExtra > 0",
        "totalIncludingExtra > totalWithoutExtra",
    ):
        require(duration, marker, "same-response duration proof")

    confirm = function_body(source, "lviConfirmWithMeetsAfterRequest")
    for marker in (
        "lviAmbiguousAfterArchivesIds.count(requested)",
        "lviAfterLiveIdByArchivesId.find(requested)",
        "lviAmbiguousAfterLiveIds.count(reverse->second)",
        "lviAfterEntitlementByLiveId.find(reverse->second)",
        "mapped->second.archivesId != requested",
        "reverse->second != mapped->second.liveId",
        "lviConfirmedAfterRequestId = requested",
        "lviConfirmedAfterRequestDeadline = now + 30.0",
    ):
        require(confirm, marker, "exact ArchivesId request confirmation")
    if "lviAfterEntitlementByLiveId.find(requested)" in confirm:
        raise AssertionError(
            "request constructor identifier is incorrectly treated as LiveId"
        )

    consume = function_body(
        source, "lviConsumeConfirmedWithMeetsAfterRequest"
    )
    for marker in (
        "lviConfirmedAfterRequestActive = false",
        "lviConfirmedAfterEntitlement = {}",
        "lviConfirmedAfterRequestId.clear()",
        "confirmed.catalogGeneration != lviAfterCatalogGeneration",
        "requestId != confirmed.archivesId",
        "CFAbsoluteTimeGetCurrent() > deadline",
    ):
        require(consume, marker, "one-shot request consumption")

    chapter_array = function_body(
        source, "lviWithMeetsArchiveChapterArrayClass"
    )
    for marker in (
        "IL2CPP::Functions.m_ArrayGetClass",
        '"Org.OpenAPITools.Model.ArchiveWithliveChapter"',
        "IL2CPP::Functions.m_ArrayGetClass)(chapterClass, 1)",
    ):
        require(chapter_array, marker, "chapter array class")

    chapters = function_body(
        source, "lviWithMeetsAfterResponseHasExtraChapter"
    )
    for marker in (
        '"GetWithArchiveDataResponse"',
        '"<Chapters>k__BackingField"',
        '"System.Collections.Generic"',
        '"List`1"',
        'lviReadExactInstanceField(chapters, "_items", items)',
        'lviReadExactInstanceField(chapters, "_size", count)',
        "items->m_pBounds != nullptr",
        "items->m_pClass != lviWithMeetsArchiveChapterArrayClass()",
        "count <= 0",
        "count > 1000",
        "static_cast<uintptr_t>(count) > items->m_uMaxLength",
        "items->m_uMaxLength > 10000",
        '"ArchiveWithliveChapter"',
        '"<IsExtra>k__BackingField"',
        "if (isExtra)",
    ):
        require(chapters, marker, "same-response extra chapter proof")

    repair = function_body(source, "lviRepairLegitimateWithMeetsAfter")
    for marker in (
        "lviConsumeConfirmedWithMeetsAfterRequest(entitlement)",
        "!entitlement.hasExtra",
        "!entitlement.derivedEligible",
        "lviWithMeetsAfterEnterResponse(selectorSelf)",
        "lviWithMeetsAfterResponseHasAdmissionEvidence(",
        "if (responseHasAdmission)",
        "!responseHasExtra",
        "!lviWithMeetsAfterResponseHasExtendedDuration(response)",
        "!lviWithMeetsAfterResponseHasExtraChapter(response)",
        "lviWriteExactInstanceField<bool>(",
        '"<HasExtraAdmission>k__BackingField"',
        "lviReadExactInstanceField(",
        "!responseHasAdmission",
    ):
        require(repair, marker, "narrow response repair")

    write_pattern = re.compile(
        r'lviWriteExactInstanceField\s*<\s*bool\s*>\s*\(\s*'
        r'response\s*,\s*'
        r'"<HasExtraAdmission>k__BackingField"\s*,\s*true\s*\)',
        re.DOTALL,
    )
    source_writes = write_pattern.findall(source)
    if len(source_writes) != 1:
        raise AssertionError(
            "HasExtraAdmission backing field must have exactly one literal "
            "false-to-true repair write"
        )
    write_match = write_pattern.search(repair)
    if not write_match:
        raise AssertionError(
            "HasExtraAdmission write escaped the legitimate repair helper"
        )
    for guard in (
        "lviConsumeConfirmedWithMeetsAfterRequest(entitlement)",
        "if (responseHasAdmission)",
        "!responseHasExtra",
        "!lviWithMeetsAfterResponseHasExtendedDuration(response)",
        "!lviWithMeetsAfterResponseHasExtraChapter(response)",
    ):
        position = repair.find(guard)
        if position < 0 or position > write_match.start():
            raise AssertionError(
                f"HasExtraAdmission write is not guarded by {guard!r}"
            )

    direct_writes = re.findall(
        r'SetMemberValue\s*<[^>]+>\s*\(\s*"([^"]+)"', source
    )
    exact_writes = re.findall(
        r'lviWriteExactInstanceField\s*<[^>]+>\s*\(\s*'
        r'[^,]+,\s*"([^"]+)"',
        source,
        re.DOTALL,
    )
    protected = {
        "HasExtra",
        "<HasExtra>k__BackingField",
        "EarnedStarCount",
        "<EarnedStarCount>k__BackingField",
        "GiftStarRewardSegments",
        "<GiftStarRewardSegments>k__BackingField",
        "GiftStarsThresholdForExtraAdmission",
        "<GiftStarsThresholdForExtraAdmission>k__BackingField",
        "UserGiftPtIncludingArchive",
        "<UserGiftPtIncludingArchive>k__BackingField",
        "TotalPlayTimeSecondWithoutExtra",
        "<TotalPlayTimeSecondWithoutExtra>k__BackingField",
        "TotalPlayTimeSecondIncludingExtra",
        "<TotalPlayTimeSecondIncludingExtra>k__BackingField",
        "Chapters",
        "<Chapters>k__BackingField",
        "IsExtra",
        "<IsExtra>k__BackingField",
        "PurchaseStatus",
        "<PurchaseStatus>k__BackingField",
        "GiftPt",
        "<GiftPt>k__BackingField",
    }
    illegal = sorted(protected.intersection(direct_writes + exact_writes))
    if illegal:
        raise AssertionError(
            "AFTER repair writes protected response evidence: "
            + ", ".join(illegal)
        )
    if "<HasExtraAdmission>k__BackingField" in direct_writes:
        raise AssertionError(
            "HasExtraAdmission backing field bypasses exact-field helper"
        )

    selector_hook = function_body(
        source, "hooked_WithArchiveContentTypeSelector_Execute"
    )
    require_pattern(
        selector_hook,
        r"if\s*\(\s*!original_WithArchiveContentTypeSelector_Execute"
        r"\s*\).*?return\s*\{\s*\}\s*;",
        "selector original NULL guard",
    )
    require(
        selector_hook,
        "lviRepairLegitimateWithMeetsAfter(self)",
        "selector response repair call",
    )
    require_exact_call(
        selector_hook,
        "original_WithArchiveContentTypeSelector_Execute",
        ["self", "methodInfo"],
        "selector Execute ABI",
    )

    expected_selector_parameters = ["void*self", "void*methodInfo"]
    if function_parameters(
        source, "hooked_WithArchiveContentTypeSelector_Execute"
    ) != expected_selector_parameters:
        raise AssertionError(
            "selector Execute hook must preserve self and MethodInfo"
        )
    if function_pointer_parameters(
        source, "original_WithArchiveContentTypeSelector_Execute"
    ) != expected_selector_parameters:
        raise AssertionError(
            "selector Execute original pointer must preserve self and "
            "MethodInfo"
        )

    installer = function_body(source, "hooked_didFinishLaunchingWithOptions")
    create_hook = function_body(
        source, "hooked_SchoolConnectArchiveListViewModel_CreateArchiveList"
    )
    expected_list_parameters = [
        "void*self",
        "void*archiveResponse",
        "void*thumbnailRepository",
        "void*methodInfo",
    ]
    if function_parameters(
        source,
        "hooked_SchoolConnectArchiveListViewModel_CreateArchiveList",
    ) != expected_list_parameters:
        raise AssertionError("CreateArchiveList hook ABI is incorrect")
    if function_pointer_parameters(
        source,
        "original_SchoolConnectArchiveListViewModel_CreateArchiveList",
    ) != expected_list_parameters:
        raise AssertionError("CreateArchiveList original ABI is incorrect")
    require_exact_call(
        create_hook,
        "original_SchoolConnectArchiveListViewModel_CreateArchiveList",
        ["self", "archiveResponse", "thumbnailRepository", "methodInfo"],
        "CreateArchiveList ABI",
    )
    original_position = create_hook.find(
        "original_SchoolConnectArchiveListViewModel_CreateArchiveList("
    )
    begin_position = create_hook.find(
        "lviBeginWithMeetsAfterCatalogGeneration()"
    )
    ingest_position = create_hook.find(
        "lviIngestWithMeetsAfterEvidence(archiveResponse)"
    )
    if not (0 <= original_position < begin_position < ingest_position):
        raise AssertionError(
            "CreateArchiveList must call stock first, then reset and ingest"
        )

    add_hook = function_body(
        source, "hooked_SchoolConnectArchiveListViewModel_AddToArchiveList"
    )
    if function_parameters(
        source,
        "hooked_SchoolConnectArchiveListViewModel_AddToArchiveList",
    ) != expected_list_parameters:
        raise AssertionError("AddToArchiveList hook ABI is incorrect")
    if function_pointer_parameters(
        source,
        "original_SchoolConnectArchiveListViewModel_AddToArchiveList",
    ) != expected_list_parameters:
        raise AssertionError("AddToArchiveList original ABI is incorrect")
    require_exact_call(
        add_hook,
        "original_SchoolConnectArchiveListViewModel_AddToArchiveList",
        ["self", "archiveResponse", "thumbnailRepository", "methodInfo"],
        "AddToArchiveList ABI",
    )
    if add_hook.find(
        "original_SchoolConnectArchiveListViewModel_AddToArchiveList("
    ) > add_hook.find("lviIngestWithMeetsAfterEvidence(archiveResponse)"):
        raise AssertionError("AddToArchiveList must call stock before ingest")

    request_hook = function_body(
        source, "hooked_GetWithArchiveDataRequest_ctor"
    )
    expected_request_parameters = [
        "void*self",
        "Unity::System_String*archivesId",
        "void*methodInfo",
    ]
    if function_parameters(
        source, "hooked_GetWithArchiveDataRequest_ctor"
    ) != expected_request_parameters:
        raise AssertionError("GetWithArchiveDataRequest .ctor ABI is incorrect")
    if function_pointer_parameters(
        source, "original_GetWithArchiveDataRequest_ctor"
    ) != expected_request_parameters:
        raise AssertionError(
            "GetWithArchiveDataRequest .ctor original ABI is incorrect"
        )
    require_exact_call(
        request_hook,
        "original_GetWithArchiveDataRequest_ctor",
        ["self", "archivesId", "methodInfo"],
        "GetWithArchiveDataRequest .ctor ABI",
    )
    if request_hook.find(
        "original_GetWithArchiveDataRequest_ctor("
    ) > request_hook.find("lviConfirmWithMeetsAfterRequest(archivesId)"):
        raise AssertionError("request .ctor must call stock before confirmation")

    player_arm = function_body(
        source, "lviArmWithMeetsAfterPlayerAdmissionScope"
    )
    for marker in (
        "entitlement.derivedEligible",
        "entitlement.hasExtra",
        "entitlement.hasExtraAdmission",
        "entitlement.admissionThreshold > 0",
        "entitlement.earnedStarCount >= entitlement.admissionThreshold",
        "entitlement.catalogGeneration == lviAfterCatalogGeneration",
        '"Org.OpenAPITools.Model"',
        '"GetWithArchiveDataResponse"',
        "lviAmbiguousAfterLiveIds.count(entitlement.liveId) == 0",
        "lviAmbiguousAfterArchivesIds.count(entitlement.archivesId) == 0",
        "lviWithMeetsAfterPlayerAdmissionScope.active = true",
        "lviWithMeetsAfterPlayerAdmissionScope.entitlement =",
        "lviWithMeetsAfterPlayerAdmissionScope.detailResponseIdentity =",
        "reinterpret_cast<uintptr_t>(detailResponse)",
        "lviWithMeetsAfterPlayerAdmissionScope.catalogGeneration =",
        "lviWithMeetsAfterPlayerAdmissionScope.scopeGeneration =",
        "CFAbsoluteTimeGetCurrent() + 120.0",
        "lviWithMeetsAfterPlayerAdmissionScope = {}",
    ):
        require(player_arm, marker, "validated player admission scope arm")

    arm_call_pattern = re.compile(
        r"\blviArmWithMeetsAfterPlayerAdmissionScope\s*\("
        r"(?P<arguments>.*?)\)\s*;",
        re.DOTALL,
    )
    arm_references = re.findall(
        r"\blviArmWithMeetsAfterPlayerAdmissionScope\s*\(",
        source,
    )
    if len(arm_references) != 3:
        raise AssertionError(
            "player admission scope helper must have one definition and "
            "exactly two narrow call sites"
        )
    repair_arm_calls = list(arm_call_pattern.finditer(repair))
    if len(repair_arm_calls) != 2:
        raise AssertionError(
            "player admission scope must be armed exactly for the two "
            "validated detail-response outcomes"
        )
    for call in repair_arm_calls:
        if normalized_parameters(
            call.group("arguments")
        ) != ["entitlement", "response"]:
            raise AssertionError(
                "player admission scope must bind the exact entitlement "
                "and detail response"
            )
    already_admitted_position = repair.find("if (responseHasAdmission)")
    if not (
        0 <= already_admitted_position <
        repair_arm_calls[0].start() <
        write_match.start() <
        repair_arm_calls[1].start()
    ):
        raise AssertionError(
            "player admission scope must arm after an already-valid response "
            "or after the exact admission write and readback"
        )

    require_pattern(
        source,
        r"static\s+thread_local\s+uint64_t\s+"
        r"lviWithMeetsAfterPlayerFactoryScopeGeneration\s*=\s*0\s*;",
        "thread-local player factory scope",
    )

    factory_match = function_body(
        source, "lviMatchWithMeetsAfterPlayerFactoryScope"
    )
    for marker in (
        '"School.LiveMain"',
        '"WithConnectModelsFactory"',
        'lviReadExactInstanceField(',
        '"_enterResponseCache"',
        '"WithArchiveEnterResponseCache"',
        '"Value"',
        '"Org.OpenAPITools.Model"',
        '"GetWithArchiveDataResponse"',
        "decision.detailResponseIdentity =",
        "reinterpret_cast<uintptr_t>(detailResponse)",
        "scope.detailResponseIdentity == 0",
        "scope.detailResponseIdentity != decision.detailResponseIdentity",
        "scope.catalogGeneration != lviAfterCatalogGeneration",
        "decision.scopeGeneration = scope.scopeGeneration",
    ):
        require(factory_match, marker, "exact player factory response scope")
    require_pattern(
        factory_match,
        r"lviReadExactInstanceField\s*\(\s*factory\s*,\s*"
        r'"_enterResponseCache"\s*,\s*cache\s*\)',
        "exact factory _enterResponseCache read",
    )
    require_pattern(
        factory_match,
        r"lviReadExactInstanceField\s*\(\s*cache\s*,\s*"
        r'"Value"\s*,\s*detailResponse\s*\)',
        "exact factory cache.Value read",
    )

    factory_hook = function_body(
        source, "hooked_WithConnectModelsFactory_CreateOwnGiftPointModel"
    )
    expected_factory_parameters = ["void*self", "void*methodInfo"]
    if function_parameters(
        source,
        "hooked_WithConnectModelsFactory_CreateOwnGiftPointModel",
    ) != expected_factory_parameters:
        raise AssertionError(
            "CreateOwnGiftPointModel hook must preserve self and MethodInfo"
        )
    if function_pointer_parameters(
        source,
        "original_WithConnectModelsFactory_CreateOwnGiftPointModel",
    ) != expected_factory_parameters:
        raise AssertionError(
            "CreateOwnGiftPointModel original pointer must preserve self "
            "and MethodInfo"
        )
    require_exact_call(
        factory_hook,
        "original_WithConnectModelsFactory_CreateOwnGiftPointModel",
        ["self", "methodInfo"],
        "CreateOwnGiftPointModel ABI",
    )
    for marker in (
        "lviMatchWithMeetsAfterPlayerFactoryScope(self)",
        "priorFactoryScopeGeneration =",
        "lviWithMeetsAfterPlayerFactoryScopeGeneration",
        "factoryDecision.matched",
        "? factoryDecision.scopeGeneration",
        ": 0",
        "lviFinishWithMeetsAfterPlayerFactoryScope(",
    ):
        require(factory_hook, marker, "thread-local player factory boundary")
    factory_original_match = re.search(
        r"\boriginal_WithConnectModelsFactory_CreateOwnGiftPointModel\s*"
        r"\(\s*self\s*,\s*methodInfo\s*\)\s*;",
        factory_hook,
        re.DOTALL,
    )
    if not factory_original_match:
        raise AssertionError(
            "CreateOwnGiftPointModel original call could not be located"
        )
    factory_scope_set = factory_hook.find(
        "lviWithMeetsAfterPlayerFactoryScopeGeneration =",
        factory_hook.find("lviMatchWithMeetsAfterPlayerFactoryScope(self)"),
    )
    factory_scope_restore = factory_hook.find(
        "lviWithMeetsAfterPlayerFactoryScopeGeneration =",
        factory_original_match.end(),
    )
    factory_scope_finish = factory_hook.find(
        "lviFinishWithMeetsAfterPlayerFactoryScope(",
        factory_original_match.end(),
    )
    if not (
        0 <= factory_scope_set < factory_original_match.start() <
        factory_scope_restore < factory_scope_finish
    ):
        raise AssertionError(
            "CreateOwnGiftPointModel must set the exact thread-local scope, "
            "call stock, restore the prior scope, then clear an unused scope"
        )
    require_pattern(
        factory_hook[factory_scope_restore:factory_scope_finish],
        r"lviWithMeetsAfterPlayerFactoryScopeGeneration\s*=\s*"
        r"priorFactoryScopeGeneration\s*;",
        "player factory thread-local restoration",
    )

    player_consume = function_body(
        source, "lviConsumeWithMeetsAfterPlayerAdmissionScope"
    )
    expected_consume_parameters = [
        "int modelAdmissionThreshold",
        "bool stockAdmission",
        "bool modelHasExtra",
        "uint64_t factoryScopeGeneration",
    ]
    if function_parameters(
        source, "lviConsumeWithMeetsAfterPlayerAdmissionScope"
    ) != expected_consume_parameters:
        raise AssertionError("player admission scope matcher ABI is incorrect")
    for marker in (
        "factoryScopeGeneration == 0",
        "factoryScopeGeneration !=",
        "lviWithMeetsAfterPlayerFactoryScopeGeneration",
        "factoryScopeGeneration != scope.scopeGeneration",
        "!modelHasExtra",
        "modelAdmissionThreshold <= 0",
        "modelAdmissionThreshold != scope.entitlement.admissionThreshold",
        "decision.shouldRepair = !stockAdmission",
        "scope = {}",
    ):
        require(player_consume, marker, "exact player admission scope match")

    gift_hook = function_body(source, "hooked_GiftPointModel_ctor")
    expected_gift_parameters = [
        "void*self",
        "int32_t currentGiftPoint",
        "void*giftStarRewardSegments",
        "int32_t extraAdmissionThreshold",
        "bool hasExtraAdmissionWhenEnter",
        "bool hasExtra",
        "int32_t schoolEventType",
        "void*methodInfo",
    ]
    if function_parameters(
        source, "hooked_GiftPointModel_ctor"
    ) != expected_gift_parameters:
        raise AssertionError("GiftPointModel six-argument .ctor ABI is incorrect")
    if function_pointer_parameters(
        source, "original_GiftPointModel_ctor"
    ) != expected_gift_parameters:
        raise AssertionError(
            "GiftPointModel six-argument .ctor original ABI is incorrect"
        )
    require_exact_call(
        gift_hook,
        "lviConsumeWithMeetsAfterPlayerAdmissionScope",
        [
            "extraAdmissionThreshold",
            "hasExtraAdmissionWhenEnter",
            "hasExtra",
            "lviWithMeetsAfterPlayerFactoryScopeGeneration",
        ],
        "GiftPointModel exact player scope consumption",
    )
    require_pattern(
        gift_hook,
        r"bool\s+effectiveAdmission\s*=\s*"
        r"hasExtraAdmissionWhenEnter\s*\|\|\s*"
        r"\(\s*decision\.matched\s*&&\s*decision\.shouldRepair\s*\)\s*;",
        "GiftPointModel admission-only repair",
    )
    require_exact_call(
        gift_hook,
        "original_GiftPointModel_ctor",
        [
            "self",
            "currentGiftPoint",
            "giftStarRewardSegments",
            "extraAdmissionThreshold",
            "effectiveAdmission",
            "hasExtra",
            "schoolEventType",
            "methodInfo",
        ],
        "GiftPointModel six-argument .ctor ABI",
    )
    preserved_gift_arguments = (
        "currentGiftPoint",
        "giftStarRewardSegments",
        "extraAdmissionThreshold",
        "hasExtra",
        "schoolEventType",
    )
    for argument in preserved_gift_arguments:
        if re.search(
            rf"\b{re.escape(argument)}\s*"
            r"(?:\+\+|--|[+\-*/%&|^]?=(?!=))",
            gift_hook,
        ):
            raise AssertionError(
                "GiftPointModel hook mutates preserved constructor argument: "
                + argument
            )

    ready_match = re.search(
        r"if\s*\(\s*withMeetsValidAfterRepair\s*\)\s*\{"
        r"(?P<body>.*?)"
        r"\}\s*else\s*\{",
        installer,
        re.DOTALL,
    )
    if not ready_match:
        raise AssertionError("missing catalog/request AFTER readiness block")
    ready = ready_match.group("body")
    for marker in (
        "lviWithArchiveSelectorReady",
        "original_WithArchiveContentTypeSelector_Execute != nullptr",
        '"Tecotec.SchoolConnectArchiveListViewModel"',
        '"CreateArchiveList"',
        '"AddToArchiveList"',
        '"Org.OpenAPITools.Model.GetWithArchiveDataRequest"',
        '".ctor"',
        "archiveListCreateReady",
        "archiveListAddReady",
        "archiveRequestReady",
        "original_SchoolConnectArchiveListViewModel_CreateArchiveList",
        "original_SchoolConnectArchiveListViewModel_AddToArchiveList",
        "original_GetWithArchiveDataRequest_ctor",
        "playerFactoryReady",
        "original_WithConnectModelsFactory_CreateOwnGiftPointModel",
        "playerModelReady",
        "original_GiftPointModel_ctor",
        "lviWithMeetsValidAfterRepairReady.store(",
    ):
        require(ready, marker, "catalog/request AFTER readiness")
    for forbidden in (
        "EnterToLiveScene",
        "GetAfterType",
        "get_ArchivesId",
    ):
        if forbidden in ready:
            raise AssertionError(
                "AFTER readiness depends on forbidden UI/property hook: "
                + forbidden
            )

    # Only the verified list methods and request constructor may be hooked.
    # The old selection and property hooks remain forbidden.
    forbidden_hook_targets = (
        "LiveArchiveItemModel",
        "EnterToLiveScene",
        "GetAfterType",
        "get_ArchivesId",
    )
    for target in forbidden_hook_targets:
        if re.search(
            r"findMethodAndHook\s*\([^;]*" + re.escape(target),
            installer,
            re.DOTALL,
        ):
            raise AssertionError(
                f"forbidden selection/property hook is installed: {target}"
            )

    require_exact_hook_installation(
        installer,
        "School.LiveMain.WithConnectModelsFactory",
        "School.LiveMain.ILiveSystemModelsFactory.CreateOwnGiftPointModel",
        0,
        "hooked_WithConnectModelsFactory_CreateOwnGiftPointModel",
        "original_WithConnectModelsFactory_CreateOwnGiftPointModel",
        "WithConnectModelsFactory player boundary",
    )
    require_exact_hook_installation(
        installer,
        "School.LiveMain.GiftPointModel",
        ".ctor",
        6,
        "hooked_GiftPointModel_ctor",
        "original_GiftPointModel_ctor",
        "GiftPointModel admission bridge",
    )

    base_popup = function_body(
        source, "hooked_LiveMain_BasePopup_OpenAsync"
    )
    expected_popup_parameters = ["void*self", "void*methodInfo"]
    if function_parameters(
        source, "hooked_LiveMain_BasePopup_OpenAsync"
    ) != expected_popup_parameters:
        raise AssertionError(
            "BasePopup.OpenAsync hook must preserve self and MethodInfo"
        )
    if function_pointer_parameters(
        source, "original_LiveMain_BasePopup_OpenAsync"
    ) != expected_popup_parameters:
        raise AssertionError(
            "BasePopup.OpenAsync original pointer must preserve self and "
            "MethodInfo"
        )
    for marker in (
        "struct alignas(8) LVIUniTaskResult",
        "sizeof(LVIUniTaskResult) == 16",
        "static LVIUniTaskResult hooked_LiveMain_BasePopup_OpenAsync",
    ):
        require(source, marker, "BasePopup UniTask value ABI")
    require_exact_call(
        base_popup,
        "original_LiveMain_BasePopup_OpenAsync",
        ["self", "methodInfo"],
        "BasePopup.OpenAsync ABI",
    )

    for forbidden in (
        "NoAfterLimitation",
        "MakeExtraAdmissionObservable",
        "SetTotalUserGiftPoint",
    ):
        if forbidden in source:
            raise AssertionError(f"forbidden broad bypass marker: {forbidden}")

    print(
        "WM AFTER catalog/request/player admission bridge safety "
        "verification passed."
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as error:
        print(
            f"WM AFTER safety verification failed: {error}",
            file=sys.stderr,
        )
        raise SystemExit(1)
