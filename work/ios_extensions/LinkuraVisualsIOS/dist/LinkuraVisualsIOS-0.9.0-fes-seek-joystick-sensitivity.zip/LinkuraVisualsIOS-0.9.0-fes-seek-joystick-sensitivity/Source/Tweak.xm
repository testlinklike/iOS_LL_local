/*
 * LinkuraVisualsIOS
 *
 * Visual, performance, camera, activity-record, and iPad layout hooks for
 * the decrypted Link! Like! Love Live! iOS 5.0.1 executable.
 *
 * Derived from LLLLResUpiOS v0.0.17 (MIT) and modified on 2026-07-18.
 * The Fes archive compatibility hook is narrowly scoped to restoring
 * camera entitlements for a ticket the user already owns. With×MEETS AFTER
 * repair is limited to correcting a false negative when the same archive
 * list row already proves admission; blanket/unowned admission, cover/chapter
 * mutation, player-ID decoration, translation, and font replacement are
 * intentionally not included.
 *
 * This combined distribution includes txm_bypass.m, which is derived from
 * LiveContainer/geode-sdk code under GNU AGPL v3. See LICENSE-AGPL-3.0 and
 * NOTICE.md. The modified combined work is distributed under
 * AGPL-3.0-only; the original MIT notices remain in
 * LICENSE-MIT-UPSTREAM.
 */

#define UNITY_VERSION_2022_3_8F1
#define UNITY_VERSION_2022_3_62F2

#include "IOS-Il2cppResolver/IL2CPP_Resolver.mm"
#include "txm_bypass.m"
#include "il2cpp_analyzer/il2cpp_symbol_hidden.mm"
#include "WMArchiveCatalog.inc"
#include <UIKit/UIKit.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <deque>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>

#ifndef LVI_WM_DIAGNOSTIC
#define LVI_WM_DIAGNOSTIC 0
#endif

#ifndef LVI_WITH_AFTER_REPAIR
#define LVI_WITH_AFTER_REPAIR 1
#endif

#if LVI_WM_DIAGNOSTIC
static void lviWriteWMDiagnostic(
	NSDictionary *entry,
	bool resetFile = false
);

static NSString* lviAfterDiagnosticIdentifier(
	const std::string& identifier
) {
	if (identifier.empty()) {
		return @"<empty>";
	}
	// A stable one-way token is enough to correlate the archive-list row with
	// the detail request without writing the raw API identifier to disk.
	uint64_t hash = 1469598103934665603ULL;
	for (unsigned char byte : identifier) {
		hash ^= static_cast<uint64_t>(byte);
		hash *= 1099511628211ULL;
	}
	return [NSString stringWithFormat:
		@"%016llx",
		static_cast<unsigned long long>(hash)
	];
}

static void lviWriteAfterDiagnostic(
	NSString *stage,
	NSDictionary *details = nil
) {
	NSMutableDictionary *entry = details
		? [details mutableCopy]
		: [NSMutableDictionary dictionary];
	entry[@"stage"] = stage ?: @"after-unknown";
	entry[@"feature"] = @"with-meets-after";
	entry[@"pipelineVersion"] = @1;
	lviWriteWMDiagnostic(entry);
}

static NSDictionary* lviDescribeAfterManagedClass(const char *className) {
	if (!className) {
		return @{
			@"class": @"<null>",
			@"found": @false
		};
	}
	NSString *managedName =
		[NSString stringWithUTF8String:className] ?: @"<invalid>";
	Unity::il2cppClass *managedClass = IL2CPP::Class::Find(className);
	if (!managedClass) {
		return @{
			@"class": managedName,
			@"found": @false
		};
	}
	std::vector<Unity::il2cppMethodInfo*> methods;
	IL2CPP::Class::FetchMethods(managedClass, &methods);
	NSMutableArray *methodDescriptions =
		[NSMutableArray arrayWithCapacity:methods.size()];
	for (Unity::il2cppMethodInfo *method : methods) {
		if (!method || !method->m_pName) {
			continue;
		}
		[methodDescriptions addObject:@{
			@"name": [NSString stringWithUTF8String:method->m_pName]
				?: @"<invalid>",
			@"argumentCount": @(method->m_uArgsCount),
			@"hasMethodPointer": @(method->m_pMethodPointer != nullptr)
		}];
	}
	std::vector<Unity::il2cppFieldInfo*> fields;
	IL2CPP::Class::FetchFields(managedClass, &fields);
	NSMutableArray *fieldDescriptions =
		[NSMutableArray arrayWithCapacity:fields.size()];
	for (Unity::il2cppFieldInfo *field : fields) {
		if (!field || !field->m_pName) {
			continue;
		}
		[fieldDescriptions addObject:@{
			@"name": [NSString stringWithUTF8String:field->m_pName]
				?: @"<invalid>",
			@"offset": @(field->m_iOffset)
		}];
	}
	return @{
		@"class": managedName,
		@"found": @true,
		@"methods": methodDescriptions,
		@"fields": fieldDescriptions
	};
}

static void lviWriteAfterRuntimeSchemaDiagnostic() {
	NSArray<NSString*> *classNames = @[
		@"School.LiveMain.ArchiveExtraAdmissionDispatchPresenter",
		@"Org.OpenAPITools.Model.ArchiveWithliveInfoResponse",
		@"Org.OpenAPITools.Model.ArchiveWithliveInfoResponseAllOf",
		@"Org.OpenAPITools.Model.GetWithArchiveDataResponse",
		@"Org.OpenAPITools.Model.GetWithArchiveDataResponseAllOf",
		@"School.LiveMain.WithArchiveEnterResponseCache",
		@"School.LiveMain.FesConnectArchivePlayer"
	];
	NSMutableArray *descriptions =
		[NSMutableArray arrayWithCapacity:classNames.count];
	for (NSString *className in classNames) {
		[descriptions addObject:lviDescribeAfterManagedClass(
			className.UTF8String
		)];
	}
	lviWriteAfterDiagnostic(@"after-runtime-schema", @{
		@"classes": descriptions
	});
}
#endif

static inline const char* IL2CPP_FRAMEWORK(const char* NAME) {
        NSString *appPath = [[NSBundle mainBundle] bundlePath];
        NSString *binaryPath = [NSString stringWithFormat:@"%s", NAME];
        if ([binaryPath isEqualToString:@"UnityFramework"])
        {
            binaryPath = [appPath stringByAppendingPathComponent:@"Frameworks/UnityFramework.framework/UnityFramework"];
        }
        else
        {
            binaryPath = [appPath stringByAppendingPathComponent:binaryPath];
        }
        return [binaryPath UTF8String];
    }

typedef void (*MSHookFunction_t)(void *symbol, void *hook, void **old);
static MSHookFunction_t MSHookFunction_p = NULL;

typedef void (*MSHookMessageEx_t)(Class _class, SEL message, IMP hook, IMP *old);
static MSHookMessageEx_t MSHookMessageEx_p = NULL;

static NSMutableDictionary *qualityConfig = nil;

static bool configBool(NSString *key) {
	id value = qualityConfig[key];
	return value && [value respondsToSelector:@selector(boolValue)] && [value boolValue];
}

static bool configBoolDefault(NSString *key, bool fallback) {
	id value = qualityConfig[key];
	return value && [value respondsToSelector:@selector(boolValue)]
		? [value boolValue]
		: fallback;
}

enum class LVICameraScene : int {
	None = 0,
	ActivityRecord = 1,
	WithMeets = 2,
	FesArchive = 3,
};

enum LiveCameraType { Undefined, Dynamic, Arena, Stand, SchoolIdle };

enum class LVICameraCommandType : int {
	None = 0,
	ToggleMode = 1,
	Reset = 2,
	Forward = 3,
	Backward = 4,
	Left = 5,
	Right = 6,
	Up = 7,
	Down = 8,
	YawLeft = 9,
	YawRight = 10,
	PitchUp = 11,
	PitchDown = 12,
	ZoomIn = 13,
	ZoomOut = 14,
	JoystickMove = 15,
};

struct LVICameraCommand {
	LVICameraCommandType type;
	uint64_t generation;
};

static std::atomic<uint64_t> lviPublishedCameraGeneration { 0 };
static std::atomic<uint64_t> lviCameraPanelPublishSerial { 0 };
static std::deque<LVICameraCommand> lviCameraCommands;
static std::mutex lviCameraCommandMutex;
static std::atomic<float> lviJoystickHorizontal { 0.0f };
static std::atomic<float> lviJoystickVertical { 0.0f };
static std::atomic<bool> lviJoystickHeightMode { false };
static std::atomic<int> lviJoystickSensitivityIndex { 0 };
static std::atomic<float> lviHeldYawDirection { 0.0f };
static std::atomic<float> lviHeldPitchDirection { 0.0f };
static std::atomic<float> lviHeldZoomDirection { 0.0f };

static int lviJoystickSensitivityMultiplier() {
	static constexpr int multipliers[] = { 1, 5, 10, 20 };
	int index = lviJoystickSensitivityIndex.load(
		std::memory_order_acquire
	);
	if (index < 0 || index >= 4) {
		index = 0;
		lviJoystickSensitivityIndex.store(
			index,
			std::memory_order_release
		);
	}
	return multipliers[index];
}

static void lviResetJoystickInput() {
	lviJoystickHorizontal.store(0.0f, std::memory_order_release);
	lviJoystickVertical.store(0.0f, std::memory_order_release);
}

static void lviResetHeldCameraInput() {
	lviHeldYawDirection.store(0.0f, std::memory_order_release);
	lviHeldPitchDirection.store(0.0f, std::memory_order_release);
	lviHeldZoomDirection.store(0.0f, std::memory_order_release);
}

static void lviSetHeldCameraCommand(
	LVICameraCommandType type,
	bool active
) {
	float value = active ? 1.0f : 0.0f;
	switch (type) {
		case LVICameraCommandType::YawLeft:
			lviHeldYawDirection.store(-value, std::memory_order_release);
			break;
		case LVICameraCommandType::YawRight:
			lviHeldYawDirection.store(value, std::memory_order_release);
			break;
		case LVICameraCommandType::PitchUp:
			lviHeldPitchDirection.store(-value, std::memory_order_release);
			break;
		case LVICameraCommandType::PitchDown:
			lviHeldPitchDirection.store(value, std::memory_order_release);
			break;
		case LVICameraCommandType::ZoomOut:
			lviHeldZoomDirection.store(value, std::memory_order_release);
			break;
		case LVICameraCommandType::ZoomIn:
			lviHeldZoomDirection.store(-value, std::memory_order_release);
			break;
		default:
			break;
	}
}

static void enqueueLVICameraCommand(LVICameraCommandType type) {
	LVICameraCommand command {
		type,
		lviPublishedCameraGeneration.load(std::memory_order_acquire)
	};
	std::lock_guard<std::mutex> guard(lviCameraCommandMutex);
	while (lviCameraCommands.size() >= 64) {
		lviCameraCommands.pop_front();
	}
	lviCameraCommands.push_back(command);
}

@interface LVICameraControlPanel : UIView
@property(nonatomic, strong) UILabel *statusLabel;
@property(nonatomic, strong) UIButton *modeButton;
- (void)updateScene:(LVICameraScene)scene
		   freeMode:(BOOL)freeMode
		  pitchText:(NSString *)pitchText
		   zoomText:(NSString *)zoomText
		 actionText:(NSString *)actionText;
@end

@interface LVICameraJoystickPad : UIView
@property(nonatomic, strong) UIView *knobView;
- (void)resetInput;
@end

@interface LVICameraJoystickPanel : UIView
@property(nonatomic, strong) UILabel *modeLabel;
@property(nonatomic, strong) UIButton *axisButton;
@property(nonatomic, strong) UIButton *sensitivityButton;
@property(nonatomic, strong) LVICameraJoystickPad *joystickPad;
- (void)updateSensitivityAppearance;
- (void)updateFreeMode:(BOOL)freeMode;
- (void)resetInput;
@end

@interface LVICameraVisibilityTab : UIButton
- (void)applyCollapsedAppearance:(BOOL)collapsed;
@end

@interface LVIWithArchivePlayPauseButton : UIButton
- (void)applyPlaying:(BOOL)playing ready:(BOOL)ready;
@end

static LVICameraControlPanel *lviCameraControlPanel = nil;
static LVICameraJoystickPanel *lviCameraJoystickPanel = nil;
static LVICameraVisibilityTab *lviCameraVisibilityTab = nil;
static LVIWithArchivePlayPauseButton *
	lviWithArchivePlayPauseButton = nil;
static std::atomic<bool> lviCameraUIUserCollapsed { false };
static std::atomic<int> lviCameraUIActiveScene {
	static_cast<int>(LVICameraScene::None)
};
static std::atomic<bool> lviWithArchivePlayPauseUIActive { false };
static std::atomic<bool> lviWithArchivePlayPauseLastPlaying { true };
static std::atomic<uint64_t>
	lviWithArchivePlayPauseRefreshGeneration { 0 };

static bool lviCameraUIEffectiveCollapsed() {
	return configBoolDefault(
		@"CameraControl.UI.ScreenshotHide.Enable",
		true
	) && lviCameraUIUserCollapsed.load(std::memory_order_acquire);
}

static void lviClearPendingCameraInput() {
	lviResetJoystickInput();
	lviResetHeldCameraInput();
	std::lock_guard<std::mutex> guard(lviCameraCommandMutex);
	lviCameraCommands.clear();
}

static UIWindow* lviActiveWindow();
static void lviRefreshCameraOverlayLayoutOnMain();
static void lviRefreshWithArchivePlayPauseButtonOnMain();
static void lviScheduleWithArchivePlayPauseRefresh(
	uint64_t generation,
	uint64_t delayMilliseconds
);
static void lviToggleWithArchivePlayPause();
static bool lviReadWithArchivePlayPauseState(
	bool& playing,
	bool& ready
);

static void lviCancelCameraControlTracking(UIView *view) {
	if (!view) {
		return;
	}
	if ([view isKindOfClass:[UIControl class]]) {
		[(UIControl *)view cancelTrackingWithEvent:nil];
	}
	for (UIView *subview in view.subviews) {
		lviCancelCameraControlTracking(subview);
	}
}

static UIButton* makeLVICameraButton(
	NSString *title,
	LVICameraCommandType command,
	CGRect frame,
	id target
) {
	UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
	button.frame = frame;
	button.tag = static_cast<NSInteger>(command);
	[button setTitle:title forState:UIControlStateNormal];
	[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	button.backgroundColor = [UIColor colorWithWhite:0.16 alpha:0.82];
	button.layer.cornerRadius = 7.0;
	[button addTarget:target
			   action:@selector(cameraButtonPressed:)
	 forControlEvents:UIControlEventTouchUpInside];
	return button;
}

static UIButton* makeLVICameraHoldButton(
	NSString *title,
	LVICameraCommandType command,
	CGRect frame,
	id target
) {
	UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
	button.frame = frame;
	button.tag = static_cast<NSInteger>(command);
	[button setTitle:title forState:UIControlStateNormal];
	[button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	button.backgroundColor = [UIColor colorWithWhite:0.16 alpha:0.82];
	button.layer.cornerRadius = 7.0;
	[button addTarget:target
			   action:@selector(cameraHoldBegan:)
	 forControlEvents:UIControlEventTouchDown];
	[button addTarget:target
			   action:@selector(cameraHoldEnded:)
	 forControlEvents:
		UIControlEventTouchUpInside |
		UIControlEventTouchUpOutside |
		UIControlEventTouchCancel];
	return button;
}

@implementation LVICameraJoystickPad

- (instancetype)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (!self) {
		return nil;
	}

	self.backgroundColor = [UIColor colorWithWhite:0.12 alpha:0.78];
	self.layer.cornerRadius = MIN(
		CGRectGetWidth(frame),
		CGRectGetHeight(frame)
	) * 0.5;
	self.layer.borderWidth = 1.0;
	self.layer.borderColor =
		[UIColor colorWithWhite:1.0 alpha:0.28].CGColor;
	self.multipleTouchEnabled = NO;
	self.exclusiveTouch = YES;

	CGFloat knobSize = 46.0;
	_knobView = [[UIView alloc] initWithFrame:CGRectMake(
		(CGRectGetWidth(frame) - knobSize) * 0.5,
		(CGRectGetHeight(frame) - knobSize) * 0.5,
		knobSize,
		knobSize
	)];
	_knobView.backgroundColor =
		[UIColor colorWithRed:0.14 green:0.62 blue:0.91 alpha:0.92];
	_knobView.layer.cornerRadius = knobSize * 0.5;
	_knobView.layer.borderWidth = 1.0;
	_knobView.layer.borderColor =
		[UIColor colorWithWhite:1.0 alpha:0.55].CGColor;
	_knobView.userInteractionEnabled = NO;
	[self addSubview:_knobView];

	return self;
}

- (void)updateInputForTouch:(UITouch *)touch {
	if (!touch) {
		return;
	}
	CGPoint center = CGPointMake(
		CGRectGetMidX(self.bounds),
		CGRectGetMidY(self.bounds)
	);
	CGPoint point = [touch locationInView:self];
	CGFloat dx = point.x - center.x;
	CGFloat dy = point.y - center.y;
	CGFloat maximumRadius =
		MAX(1.0, MIN(CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds))
			* 0.5 - CGRectGetWidth(self.knobView.bounds) * 0.5 - 5.0);
	CGFloat distance = hypot(dx, dy);
	if (distance > maximumRadius) {
		CGFloat scale = maximumRadius / distance;
		dx *= scale;
		dy *= scale;
	}
	self.knobView.center = CGPointMake(center.x + dx, center.y + dy);

	float horizontal = static_cast<float>(dx / maximumRadius);
	float vertical = static_cast<float>(-dy / maximumRadius);
	if (fabs(horizontal) < 0.06f) {
		horizontal = 0.0f;
	}
	if (fabs(vertical) < 0.06f) {
		vertical = 0.0f;
	}
	lviJoystickHorizontal.store(horizontal, std::memory_order_release);
	lviJoystickVertical.store(vertical, std::memory_order_release);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches
		   withEvent:(UIEvent *)event {
	[self updateInputForTouch:touches.anyObject];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches
		   withEvent:(UIEvent *)event {
	[self updateInputForTouch:touches.anyObject];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches
		   withEvent:(UIEvent *)event {
	[self resetInput];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches
			   withEvent:(UIEvent *)event {
	[self resetInput];
}

- (void)resetInput {
	lviResetJoystickInput();
	CGPoint center = CGPointMake(
		CGRectGetMidX(self.bounds),
		CGRectGetMidY(self.bounds)
	);
	[UIView animateWithDuration:0.08 animations:^{
		self.knobView.center = center;
	}];
}

@end

@implementation LVICameraJoystickPanel

- (instancetype)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (!self) {
		return nil;
	}

	self.backgroundColor = [UIColor colorWithWhite:0.04 alpha:0.76];
	self.layer.cornerRadius = 14.0;
	self.layer.borderWidth = 1.0;
	self.layer.borderColor =
		[UIColor colorWithWhite:1.0 alpha:0.22].CGColor;

	_sensitivityButton = [UIButton buttonWithType:UIButtonTypeSystem];
	_sensitivityButton.frame = CGRectMake(8, 7, 36, 69);
	[_sensitivityButton setTitleColor:[UIColor whiteColor]
							forState:UIControlStateNormal];
	_sensitivityButton.titleLabel.font =
		[UIFont systemFontOfSize:11 weight:UIFontWeightBold];
	_sensitivityButton.backgroundColor =
		[UIColor colorWithWhite:0.16 alpha:0.82];
	_sensitivityButton.layer.cornerRadius = 7.0;
	_sensitivityButton.accessibilityLabel =
		@"ジョイスティック移動感度";
	[_sensitivityButton addTarget:self
						 action:@selector(sensitivityButtonPressed:)
			   forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_sensitivityButton];

	// The original controls are shifted right by exactly 44 points while the
	// panel remains anchored to the screen's right edge. Their screen-space
	// positions therefore stay unchanged and the new pitch column grows only
	// toward the left.
	_modeLabel = [[UILabel alloc] initWithFrame:CGRectMake(54, 7, 45, 30)];
	_modeLabel.textColor = [UIColor whiteColor];
	_modeLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
	_modeLabel.textAlignment = NSTextAlignmentCenter;
	_modeLabel.numberOfLines = 2;
	_modeLabel.text = @"MOVE\nGAME";
	[self addSubview:_modeLabel];

	_axisButton = [UIButton buttonWithType:UIButtonTypeSystem];
	_axisButton.frame = CGRectMake(103, 7, 51, 30);
	[_axisButton setTitle:@"* XZ" forState:UIControlStateNormal];
	[_axisButton setTitleColor:[UIColor whiteColor]
					 forState:UIControlStateNormal];
	_axisButton.titleLabel.font =
		[UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
	_axisButton.backgroundColor = [UIColor colorWithWhite:0.16 alpha:0.82];
	_axisButton.layer.cornerRadius = 7.0;
	[_axisButton addTarget:self
					action:@selector(axisButtonPressed:)
		  forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_axisButton];

	UIButton *resetButton = makeLVICameraButton(
		@"R",
		LVICameraCommandType::Reset,
		CGRectMake(159, 7, 47, 30),
		self
	);
	resetButton.titleLabel.font =
		[UIFont systemFontOfSize:12 weight:UIFontWeightBold];
	[self addSubview:resetButton];

	UIButton *lookLeftButton = makeLVICameraHoldButton(
		@"←",
		LVICameraCommandType::YawLeft,
		CGRectMake(56, 42, 70, 34),
		self
	);
	lookLeftButton.accessibilityLabel = @"カメラを左に振る";
	[self addSubview:lookLeftButton];

	UIButton *lookRightButton = makeLVICameraHoldButton(
		@"→",
		LVICameraCommandType::YawRight,
		CGRectMake(134, 42, 70, 34),
		self
	);
	lookRightButton.accessibilityLabel = @"カメラを右に振る";
	[self addSubview:lookRightButton];

	UIButton *pitchUpButton = makeLVICameraHoldButton(
		@"↑",
		LVICameraCommandType::PitchUp,
		CGRectMake(8, 82, 36, 70),
		self
	);
	pitchUpButton.accessibilityLabel = @"カメラを上に振る";
	[self addSubview:pitchUpButton];

	UIButton *pitchDownButton = makeLVICameraHoldButton(
		@"↓",
		LVICameraCommandType::PitchDown,
		CGRectMake(8, 160, 36, 70),
		self
	);
	pitchDownButton.accessibilityLabel = @"カメラを下に振る";
	[self addSubview:pitchDownButton];

	_joystickPad = [[LVICameraJoystickPad alloc]
		initWithFrame:CGRectMake(56, 82, 148, 148)];
	[self addSubview:_joystickPad];
	[self updateSensitivityAppearance];

	return self;
}

- (void)cameraButtonPressed:(UIButton *)sender {
	enqueueLVICameraCommand(
		static_cast<LVICameraCommandType>(sender.tag)
	);
}

- (void)cameraHoldBegan:(UIButton *)sender {
	LVICameraCommandType command =
		static_cast<LVICameraCommandType>(sender.tag);
	enqueueLVICameraCommand(command);
	lviSetHeldCameraCommand(command, true);
}

- (void)cameraHoldEnded:(UIButton *)sender {
	lviSetHeldCameraCommand(
		static_cast<LVICameraCommandType>(sender.tag),
		false
	);
}

- (void)axisButtonPressed:(UIButton *)sender {
	bool heightMode = !lviJoystickHeightMode.load(
		std::memory_order_acquire
	);
	lviJoystickHeightMode.store(heightMode, std::memory_order_release);
	[sender setTitle:(heightMode ? @"* XY" : @"* XZ")
			forState:UIControlStateNormal];
	sender.backgroundColor = heightMode
		? [UIColor colorWithRed:0.08 green:0.55 blue:0.82 alpha:0.92]
		: [UIColor colorWithWhite:0.16 alpha:0.82];
}

- (void)sensitivityButtonPressed:(UIButton *)sender {
	int nextIndex =
		(lviJoystickSensitivityIndex.load(std::memory_order_acquire) + 1)
		% 4;
	lviJoystickSensitivityIndex.store(
		nextIndex,
		std::memory_order_release
	);
	[self updateSensitivityAppearance];
}

- (void)updateSensitivityAppearance {
	int multiplier = lviJoystickSensitivityMultiplier();
	[self.sensitivityButton
		setTitle:[NSString stringWithFormat:@"×%d", multiplier]
		forState:UIControlStateNormal];
	if (multiplier >= 20) {
		self.sensitivityButton.backgroundColor =
			[UIColor colorWithRed:0.78 green:0.22 blue:0.18 alpha:0.92];
	} else if (multiplier >= 10) {
		self.sensitivityButton.backgroundColor =
			[UIColor colorWithRed:0.88 green:0.48 blue:0.10 alpha:0.92];
	} else if (multiplier >= 5) {
		self.sensitivityButton.backgroundColor =
			[UIColor colorWithRed:0.08 green:0.55 blue:0.82 alpha:0.92];
	} else {
		self.sensitivityButton.backgroundColor =
			[UIColor colorWithWhite:0.16 alpha:0.82];
	}
	self.sensitivityButton.accessibilityValue =
		[NSString stringWithFormat:@"%d倍", multiplier];
}

- (void)updateFreeMode:(BOOL)freeMode {
	self.modeLabel.text = freeMode ? @"MOVE\nFREE" : @"MOVE\nGAME";
	for (UIView *subview in self.subviews) {
		if (![subview isKindOfClass:[UIButton class]]) {
			continue;
		}
		UIButton *button = (UIButton *)subview;
		button.enabled = freeMode;
		button.alpha = freeMode ? 1.0 : 0.42;
	}
	bool heightMode = lviJoystickHeightMode.load(
		std::memory_order_acquire
	);
	[self.axisButton setTitle:(heightMode ? @"* XY" : @"* XZ")
					forState:UIControlStateNormal];
	self.axisButton.backgroundColor = heightMode
		? [UIColor colorWithRed:0.08 green:0.55 blue:0.82 alpha:0.92]
		: [UIColor colorWithWhite:0.16 alpha:0.82];
	[self updateSensitivityAppearance];
	self.joystickPad.userInteractionEnabled = freeMode;
	self.joystickPad.alpha = freeMode ? 1.0 : 0.42;
	if (!freeMode) {
		[self resetInput];
	}
}

- (void)resetInput {
	[self.joystickPad resetInput];
	lviResetHeldCameraInput();
}

@end

@implementation LVICameraControlPanel

- (instancetype)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (!self) {
		return nil;
	}

	self.backgroundColor = [UIColor colorWithWhite:0.04 alpha:0.82];
	self.layer.cornerRadius = 12.0;
	self.layer.borderWidth = 1.0;
	self.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.22].CGColor;

	_statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 7, 174, 30)];
	_statusLabel.textColor = [UIColor whiteColor];
	_statusLabel.text = @"Camera";
	_statusLabel.numberOfLines = 2;
	[self addSubview:_statusLabel];

	_modeButton = makeLVICameraButton(
		@"GAME",
		LVICameraCommandType::ToggleMode,
		CGRectMake(190, 7, 78, 30),
		self
	);
	[self addSubview:_modeButton];

	UIButton *resetButton = makeLVICameraButton(
		@"RESET",
		LVICameraCommandType::Reset,
		CGRectMake(274, 7, 78, 30),
		self
	);
	[self addSubview:resetButton];

	NSArray<NSString *> *titles = @[
		@"←", @"→", @"↑", @"↓", @"+Y", @"-Y",
		@"YAW ←", @"YAW →", @"P ↑", @"P ↓", @"Q −", @"E +"
	];
	LVICameraCommandType commands[] = {
		LVICameraCommandType::Left,
		LVICameraCommandType::Right,
		LVICameraCommandType::Forward,
		LVICameraCommandType::Backward,
		LVICameraCommandType::Up,
		LVICameraCommandType::Down,
		LVICameraCommandType::YawLeft,
		LVICameraCommandType::YawRight,
		LVICameraCommandType::PitchUp,
		LVICameraCommandType::PitchDown,
		LVICameraCommandType::ZoomOut,
		LVICameraCommandType::ZoomIn,
	};

	for (NSInteger index = 0; index < 12; ++index) {
		NSInteger row = index / 6;
		NSInteger column = index % 6;
		CGRect buttonFrame = CGRectMake(
			10 + column * 58,
			44 + row * 42,
			52,
			34
		);
		bool isHoldButton =
			commands[index] == LVICameraCommandType::ZoomIn ||
			commands[index] == LVICameraCommandType::ZoomOut;
		UIButton *button = isHoldButton
			? makeLVICameraHoldButton(
				titles[index],
				commands[index],
				buttonFrame,
				self
			)
			: makeLVICameraButton(
				titles[index],
				commands[index],
				buttonFrame,
				self
			);
		[self addSubview:button];
	}

	return self;
}

- (void)cameraButtonPressed:(UIButton *)sender {
	enqueueLVICameraCommand(
		static_cast<LVICameraCommandType>(sender.tag)
	);
}

- (void)cameraHoldBegan:(UIButton *)sender {
	LVICameraCommandType command =
		static_cast<LVICameraCommandType>(sender.tag);
	enqueueLVICameraCommand(command);
	lviSetHeldCameraCommand(command, true);
}

- (void)cameraHoldEnded:(UIButton *)sender {
	lviSetHeldCameraCommand(
		static_cast<LVICameraCommandType>(sender.tag),
		false
	);
}

- (void)updateScene:(LVICameraScene)scene
		   freeMode:(BOOL)freeMode
		  pitchText:(NSString *)pitchText
		   zoomText:(NSString *)zoomText
		 actionText:(NSString *)actionText {
	NSString *sceneText =
		scene == LVICameraScene::ActivityRecord
			? @"A"
			: (scene == LVICameraScene::WithMeets ? @"W" : @"F");
	self.statusLabel.text = [NSString stringWithFormat:@"%@ %@\n%@ %@",
		sceneText,
		actionText,
		pitchText,
		zoomText
	];
	[self.modeButton setTitle:(freeMode ? @"FREE" : @"GAME")
					forState:UIControlStateNormal];
	self.modeButton.backgroundColor = freeMode
		? [UIColor colorWithRed:0.08 green:0.55 blue:0.82 alpha:0.92]
		: [UIColor colorWithWhite:0.16 alpha:0.82];
	for (UIView *subview in self.subviews) {
		if (![subview isKindOfClass:[UIButton class]]) {
			continue;
		}
		UIButton *button = (UIButton *)subview;
		bool isModeButton =
			button.tag == static_cast<NSInteger>(
				LVICameraCommandType::ToggleMode
			);
		button.enabled = isModeButton || freeMode;
		button.alpha = (isModeButton || freeMode) ? 1.0 : 0.42;
	}
}

@end

@implementation LVICameraVisibilityTab

- (instancetype)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (!self) {
		return nil;
	}
	[self addTarget:self
			   action:@selector(visibilityTabPressed:)
	 forControlEvents:UIControlEventTouchUpInside];
	self.titleLabel.font =
		[UIFont systemFontOfSize:17 weight:UIFontWeightBold];
	self.layer.cornerRadius = 9.0;
	self.clipsToBounds = YES;
	self.exclusiveTouch = YES;
	self.autoresizingMask =
		UIViewAutoresizingFlexibleTopMargin |
		UIViewAutoresizingFlexibleBottomMargin |
		UIViewAutoresizingFlexibleRightMargin;
	self.accessibilityHint =
		@"スクリーンショット用にカメラ操作UIを切り替えます";
	[[NSNotificationCenter defaultCenter]
		addObserver:self
		   selector:@selector(overlayEnvironmentChanged:)
			   name:UIDeviceOrientationDidChangeNotification
			 object:nil];
	[[NSNotificationCenter defaultCenter]
		addObserver:self
		   selector:@selector(overlayEnvironmentChanged:)
			   name:UIWindowDidBecomeKeyNotification
			 object:nil];
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)overlayEnvironmentChanged:(NSNotification *)notification {
	dispatch_async(dispatch_get_main_queue(), ^{
		lviRefreshCameraOverlayLayoutOnMain();
	});
}

- (void)applyCollapsedAppearance:(BOOL)collapsed {
	if (collapsed) {
		[self setTitle:@"" forState:UIControlStateNormal];
		self.backgroundColor = [UIColor clearColor];
		self.layer.borderWidth = 0.0;
		self.accessibilityLabel = @"カメラ操作を表示";
	} else {
		[self setTitle:@"◀" forState:UIControlStateNormal];
		[self setTitleColor:[UIColor whiteColor]
				  forState:UIControlStateNormal];
		self.backgroundColor = [UIColor colorWithWhite:0.04 alpha:0.82];
		self.layer.borderWidth = 1.0;
		self.layer.borderColor =
			[UIColor colorWithWhite:1.0 alpha:0.28].CGColor;
		self.accessibilityLabel = @"カメラ操作を隠す";
	}
}

- (void)visibilityTabPressed:(UIButton *)sender {
	if (lviCameraUIActiveScene.load(std::memory_order_acquire) ==
		static_cast<int>(LVICameraScene::None)) {
		return;
	}
	bool collapsed = !lviCameraUIUserCollapsed.load(
		std::memory_order_acquire
	);
	lviCameraUIUserCollapsed.store(collapsed, std::memory_order_release);
	lviCameraControlPanel.userInteractionEnabled = NO;
	lviCameraJoystickPanel.userInteractionEnabled = NO;
	lviCancelCameraControlTracking(lviCameraControlPanel);
	lviCancelCameraControlTracking(lviCameraJoystickPanel);
	lviClearPendingCameraInput();
	[lviCameraJoystickPanel resetInput];
	[self applyCollapsedAppearance:collapsed];
	lviRefreshCameraOverlayLayoutOnMain();
	lviRefreshWithArchivePlayPauseButtonOnMain();
}

@end

@implementation LVIWithArchivePlayPauseButton

- (instancetype)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (!self) {
		return nil;
	}
	self.backgroundColor = [UIColor colorWithWhite:0.04 alpha:0.82];
	self.layer.cornerRadius = CGRectGetWidth(frame) * 0.5;
	self.layer.borderWidth = 1.0;
	self.layer.borderColor =
		[UIColor colorWithWhite:1.0 alpha:0.35].CGColor;
	self.tintColor = [UIColor whiteColor];
	self.exclusiveTouch = YES;
	[self addTarget:self
			   action:@selector(playPausePressed:)
	 forControlEvents:UIControlEventTouchUpInside];
	[[NSNotificationCenter defaultCenter]
		addObserver:self
		   selector:@selector(playPauseEnvironmentChanged:)
			   name:UIDeviceOrientationDidChangeNotification
			 object:nil];
	[[NSNotificationCenter defaultCenter]
		addObserver:self
		   selector:@selector(playPauseEnvironmentChanged:)
			   name:UIWindowDidBecomeKeyNotification
			 object:nil];
	return self;
}

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)playPausePressed:(UIButton *)sender {
	lviToggleWithArchivePlayPause();
}

- (void)playPauseEnvironmentChanged:(NSNotification *)notification {
	dispatch_async(dispatch_get_main_queue(), ^{
		lviRefreshWithArchivePlayPauseButtonOnMain();
	});
}

- (void)applyPlaying:(BOOL)playing ready:(BOOL)ready {
	NSString *symbolName = playing ? @"pause.fill" : @"play.fill";
	UIImage *symbol = [UIImage systemImageNamed:symbolName];
	if (symbol) {
		UIImageSymbolConfiguration *configuration =
			[UIImageSymbolConfiguration configurationWithPointSize:18.0
														weight:UIImageSymbolWeightBold];
		[self setImage:[symbol imageByApplyingSymbolConfiguration:configuration]
			 forState:UIControlStateNormal];
		[self setTitle:@"" forState:UIControlStateNormal];
	} else {
		[self setImage:nil forState:UIControlStateNormal];
		[self setTitle:(playing ? @"Ⅱ" : @"▶")
			 forState:UIControlStateNormal];
		[self setTitleColor:[UIColor whiteColor]
				  forState:UIControlStateNormal];
		self.titleLabel.font =
			[UIFont systemFontOfSize:18 weight:UIFontWeightBold];
	}
	self.enabled = ready;
	self.alpha = ready ? 1.0 : 0.42;
	self.accessibilityLabel = playing ? @"一時停止" : @"再生";
	self.accessibilityHint =
		@"現在位置を保ったままWith×MEETSアーカイブを再生または一時停止します";
}

@end

static UIWindow* lviActiveWindow() {
	UIApplication *application = [UIApplication sharedApplication];
	for (UIScene *scene in application.connectedScenes) {
		if (![scene isKindOfClass:[UIWindowScene class]] ||
			scene.activationState != UISceneActivationStateForegroundActive) {
			continue;
		}
		for (UIWindow *window in ((UIWindowScene *)scene).windows) {
			if (window.isKeyWindow) {
				return window;
			}
		}
	}
	for (UIWindow *window in application.windows) {
		if (window.isKeyWindow) {
			return window;
		}
	}
	return application.windows.firstObject;
}

static void lviRefreshWithArchivePlayPauseButtonOnMain() {
	if (![NSThread isMainThread]) {
		dispatch_async(dispatch_get_main_queue(), ^{
			lviRefreshWithArchivePlayPauseButtonOnMain();
		});
		return;
	}

	bool uiActive = lviWithArchivePlayPauseUIActive.load(
		std::memory_order_acquire
	);
	bool cameraUIHiddenForScreenshot = lviCameraUIEffectiveCollapsed();
	if (!uiActive ||
		!configBoolDefault(
			@"WithMeets.Archive.PlayPauseButton.Enable",
			false
		) || cameraUIHiddenForScreenshot) {
		[lviWithArchivePlayPauseButton cancelTrackingWithEvent:nil];
		lviWithArchivePlayPauseButton.hidden = YES;
		lviWithArchivePlayPauseButton.userInteractionEnabled = NO;
		return;
	}

	UIWindow *window = lviActiveWindow();
	if (!window) {
		return;
	}
	if (!lviWithArchivePlayPauseButton) {
		lviWithArchivePlayPauseButton =
			[[LVIWithArchivePlayPauseButton alloc]
				initWithFrame:CGRectMake(0, 0, 44.0, 44.0)];
	}
	if (lviWithArchivePlayPauseButton.superview != window) {
		[lviWithArchivePlayPauseButton removeFromSuperview];
		[window addSubview:lviWithArchivePlayPauseButton];
	}

	CGFloat width = CGRectGetWidth(window.bounds);
	CGFloat height = CGRectGetHeight(window.bounds);
	bool portrait = height > width;
	CGFloat seekBarCenterY = portrait
		? height * 0.805
		: height * 0.875;
	seekBarCenterY = MIN(
		MAX(
			seekBarCenterY,
			window.safeAreaInsets.top + 30.0
		),
		height - window.safeAreaInsets.bottom - 30.0
	);
	lviWithArchivePlayPauseButton.frame = CGRectMake(
		window.safeAreaInsets.left + 8.0,
		seekBarCenterY - 22.0,
		44.0,
		44.0
	);
	lviWithArchivePlayPauseButton.autoresizingMask =
		UIViewAutoresizingFlexibleRightMargin |
		UIViewAutoresizingFlexibleTopMargin;

	bool playing = lviWithArchivePlayPauseLastPlaying.load(
		std::memory_order_acquire
	);
	bool ready = false;
	lviReadWithArchivePlayPauseState(playing, ready);
	lviWithArchivePlayPauseLastPlaying.store(
		playing,
		std::memory_order_release
	);
	[lviWithArchivePlayPauseButton applyPlaying:playing ready:ready];
	lviWithArchivePlayPauseButton.hidden = NO;
	lviWithArchivePlayPauseButton.userInteractionEnabled = ready;
	[window bringSubviewToFront:lviWithArchivePlayPauseButton];
}

static void lviScheduleWithArchivePlayPauseRefresh(
	uint64_t generation,
	uint64_t delayMilliseconds
) {
	dispatch_after(
		dispatch_time(
			DISPATCH_TIME_NOW,
			static_cast<int64_t>(delayMilliseconds) * NSEC_PER_MSEC
		),
		dispatch_get_main_queue(),
		^{
			if (generation !=
					lviWithArchivePlayPauseRefreshGeneration.load(
						std::memory_order_acquire
					) ||
				!lviWithArchivePlayPauseUIActive.load(
					std::memory_order_acquire
				)) {
				return;
			}
			lviRefreshWithArchivePlayPauseButtonOnMain();
			// The concrete WM contents controller is attached asynchronously.
			// Keep refreshing for the lifetime of this exact session so the
			// button becomes tappable as soon as Play/Pause is actually ready,
			// and so its symbol follows playback started by the game itself.
			lviScheduleWithArchivePlayPauseRefresh(generation, 500);
		}
	);
}

static void lviRefreshCameraOverlayLayoutOnMain() {
	if (![NSThread isMainThread]) {
		dispatch_async(dispatch_get_main_queue(), ^{
			lviRefreshCameraOverlayLayoutOnMain();
		});
		return;
	}

	LVICameraScene activeScene = static_cast<LVICameraScene>(
		lviCameraUIActiveScene.load(std::memory_order_acquire)
	);
	bool uiEnabled = configBool(@"CameraControl.UI.Enable");
	if (activeScene == LVICameraScene::None || !uiEnabled) {
		lviCameraControlPanel.userInteractionEnabled = NO;
		lviCameraJoystickPanel.userInteractionEnabled = NO;
		lviCancelCameraControlTracking(lviCameraControlPanel);
		lviCancelCameraControlTracking(lviCameraJoystickPanel);
		lviCameraControlPanel.hidden = YES;
		[lviCameraJoystickPanel resetInput];
		lviCameraJoystickPanel.hidden = YES;
		lviCameraVisibilityTab.hidden = YES;
		return;
	}

	UIWindow *window = lviActiveWindow();
	UIView *container = window;
	if (!container) {
		return;
	}
	NSArray<UIView *> *overlays = @[
		lviCameraControlPanel ?: (UIView *)[NSNull null],
		lviCameraJoystickPanel ?: (UIView *)[NSNull null],
		lviCameraVisibilityTab ?: (UIView *)[NSNull null],
	];
	for (id overlayValue in overlays) {
		if (overlayValue == [NSNull null]) {
			continue;
		}
		UIView *overlay = (UIView *)overlayValue;
		if (overlay.superview != container) {
			[overlay removeFromSuperview];
			[container addSubview:overlay];
		}
	}

	if (lviCameraControlPanel) {
		CGRect frame = lviCameraControlPanel.frame;
		frame.origin.x = MIN(
			MAX(frame.origin.x, 4.0),
			MAX(
				4.0,
				CGRectGetWidth(container.bounds) - frame.size.width - 4.0
			)
		);
		frame.origin.y = MIN(
			MAX(
				frame.origin.y,
				container.safeAreaInsets.top + 4.0
			),
			MAX(
				container.safeAreaInsets.top + 4.0,
				CGRectGetHeight(container.bounds) - frame.size.height -
					container.safeAreaInsets.bottom - 4.0
			)
		);
		lviCameraControlPanel.frame = frame;
		lviCameraControlPanel.autoresizingMask =
			UIViewAutoresizingFlexibleRightMargin |
			UIViewAutoresizingFlexibleBottomMargin;
	}

	if (lviCameraJoystickPanel) {
		CGFloat joystickX = MAX(
			4.0,
			CGRectGetWidth(container.bounds) -
				CGRectGetWidth(lviCameraJoystickPanel.bounds) - 16.0
		);
		CGFloat joystickY = MAX(
			container.safeAreaInsets.top + 4.0,
			CGRectGetHeight(container.bounds) -
				CGRectGetHeight(lviCameraJoystickPanel.bounds) -
				container.safeAreaInsets.bottom - 16.0
		);
		lviCameraJoystickPanel.frame = CGRectMake(
			joystickX,
			joystickY,
			216.0,
			236.0
		);
		lviCameraJoystickPanel.autoresizingMask =
			UIViewAutoresizingFlexibleLeftMargin |
			UIViewAutoresizingFlexibleTopMargin;
	}

	bool screenshotHideEnabled = configBoolDefault(
		@"CameraControl.UI.ScreenshotHide.Enable",
		true
	);
	bool collapsed = lviCameraUIEffectiveCollapsed();
	if (lviCameraVisibilityTab) {
		CGFloat tabMinimumY = container.safeAreaInsets.top + 52.0;
		CGFloat tabMaximumY = MAX(
			tabMinimumY,
			CGRectGetHeight(container.bounds) -
				container.safeAreaInsets.bottom - 52.0
		);
		CGFloat tabY = MIN(
			MAX(
				CGRectGetMidY(container.bounds) - 22.0,
				tabMinimumY
			),
			tabMaximumY
		);
		lviCameraVisibilityTab.frame = CGRectMake(0, tabY, 44.0, 44.0);
		[lviCameraVisibilityTab applyCollapsedAppearance:collapsed];
		lviCameraVisibilityTab.hidden = !screenshotHideEnabled;
	}

	bool joystickEnabled = configBoolDefault(
		@"CameraControl.Joystick.Enable",
		true
	);
	lviCameraControlPanel.userInteractionEnabled = !collapsed;
	lviCameraJoystickPanel.userInteractionEnabled =
		!collapsed && joystickEnabled;
	lviCameraControlPanel.hidden = collapsed;
	lviCameraJoystickPanel.hidden = collapsed || !joystickEnabled;
	if (!joystickEnabled) {
		[lviCameraJoystickPanel resetInput];
	}

	if (lviCameraControlPanel && !lviCameraControlPanel.hidden) {
		[container bringSubviewToFront:lviCameraControlPanel];
	}
	if (lviCameraJoystickPanel && !lviCameraJoystickPanel.hidden) {
		[container bringSubviewToFront:lviCameraJoystickPanel];
	}
	if (lviCameraVisibilityTab && !lviCameraVisibilityTab.hidden) {
		[container bringSubviewToFront:lviCameraVisibilityTab];
	}
}

static void publishLVICameraPanel(
	LVICameraScene scene,
	bool freeMode,
	bool orthographic,
	float zoomValue,
	float pitchDegrees,
	LVICameraCommandType lastCommand
) {
	bool shouldHide =
		scene == LVICameraScene::None ||
		!configBool(@"CameraControl.UI.Enable");
	if (shouldHide) {
		// This is logical session state, not UIKit state.  Reset it
		// synchronously so a superseded main-thread hide block cannot leak the
		// screenshot-collapse state into the next playback session.
		lviCameraUIActiveScene.store(
			static_cast<int>(LVICameraScene::None),
			std::memory_order_release
		);
		lviCameraUIUserCollapsed.store(false, std::memory_order_release);
		lviClearPendingCameraInput();
	}
	uint64_t publishSerial =
		lviCameraPanelPublishSerial.fetch_add(
			1,
			std::memory_order_acq_rel
		) + 1;
	dispatch_async(dispatch_get_main_queue(), ^{
		if (publishSerial != lviCameraPanelPublishSerial.load(
			std::memory_order_acquire
		)) {
			return;
		}
		if (shouldHide) {
			lviRefreshCameraOverlayLayoutOnMain();
			return;
		}

		UIWindow *window = lviActiveWindow();
		UIView *container = window;
		if (!container) {
			return;
		}
		if (!lviCameraControlPanel) {
			lviCameraControlPanel = [[LVICameraControlPanel alloc]
				initWithFrame:CGRectMake(16, 72, 362, 132)];
		}
		bool screenshotHideEnabled = configBoolDefault(
			@"CameraControl.UI.ScreenshotHide.Enable",
			true
		);
		if (screenshotHideEnabled) {
			if (!lviCameraVisibilityTab) {
				lviCameraVisibilityTab = [[LVICameraVisibilityTab alloc]
					initWithFrame:CGRectMake(0, 0, 44, 44)];
			}
		} else {
			lviCameraUIUserCollapsed.store(false, std::memory_order_release);
		}
		NSString *zoomText = orthographic
			? [NSString stringWithFormat:@"S %.1f", zoomValue]
			: [NSString stringWithFormat:@"FOV %.1f", zoomValue];
		NSString *pitchText =
			[NSString stringWithFormat:@"P %.1f°", pitchDegrees];
		NSString *actionText = @"READY";
		switch (lastCommand) {
			case LVICameraCommandType::ToggleMode:
				actionText = @"MODE";
				break;
			case LVICameraCommandType::Reset:
				actionText = @"RESET";
				break;
			case LVICameraCommandType::Forward:
				actionText = @"M ↑";
				break;
			case LVICameraCommandType::Backward:
				actionText = @"M ↓";
				break;
			case LVICameraCommandType::Left:
				actionText = @"M ←";
				break;
			case LVICameraCommandType::Right:
				actionText = @"M →";
				break;
			case LVICameraCommandType::Up:
				actionText = @"M +Y";
				break;
			case LVICameraCommandType::Down:
				actionText = @"M -Y";
				break;
			case LVICameraCommandType::YawLeft:
				actionText = @"Y ←";
				break;
			case LVICameraCommandType::YawRight:
				actionText = @"Y →";
				break;
			case LVICameraCommandType::PitchUp:
				actionText = @"P ↑";
				break;
			case LVICameraCommandType::PitchDown:
				actionText = @"P ↓";
				break;
			case LVICameraCommandType::ZoomIn:
				actionText = @"E +";
				break;
			case LVICameraCommandType::ZoomOut:
				actionText = @"Q −";
				break;
			case LVICameraCommandType::JoystickMove:
				actionText = lviJoystickHeightMode.load(
					std::memory_order_acquire
				) ? @"MOVE *" : @"MOVE";
				break;
			default:
				break;
		}
		[lviCameraControlPanel updateScene:scene
								 freeMode:freeMode
								pitchText:pitchText
								 zoomText:zoomText
							   actionText:actionText];

		bool joystickEnabled = configBoolDefault(
			@"CameraControl.Joystick.Enable",
			true
		);
		if (joystickEnabled && !lviCameraJoystickPanel) {
			lviCameraJoystickPanel = [[LVICameraJoystickPanel alloc]
				initWithFrame:CGRectMake(0, 0, 216, 236)];
		}
		[lviCameraJoystickPanel updateFreeMode:freeMode];
		lviCameraUIActiveScene.store(
			static_cast<int>(scene),
			std::memory_order_release
		);
		lviRefreshCameraOverlayLayoutOnMain();
	});
}

typedef Unity::CTransform* (*LVIComponentGetTransform_t)(
	void* self,
	void* methodInfo
);
typedef void (*LVITransformGetPositionInjected_t)(
	void* self,
	Unity::Vector3* value,
	void* methodInfo
);
typedef void (*LVITransformSetPositionInjected_t)(
	void* self,
	Unity::Vector3* value,
	void* methodInfo
);
typedef void (*LVITransformGetRotationInjected_t)(
	void* self,
	Unity::Quaternion* value,
	void* methodInfo
);
typedef void (*LVITransformSetRotationInjected_t)(
	void* self,
	Unity::Quaternion* value,
	void* methodInfo
);
typedef float (*LVICameraGetFloat_t)(void* self, void* methodInfo);
typedef void (*LVICameraSetFloat_t)(
	void* self,
	float value,
	void* methodInfo
);
typedef bool (*LVICameraGetBool_t)(void* self, void* methodInfo);

static LVIComponentGetTransform_t lviComponentGetTransform = nullptr;
static LVITransformGetPositionInjected_t lviTransformGetPosition = nullptr;
static LVITransformSetPositionInjected_t lviTransformSetPosition = nullptr;
static LVITransformGetRotationInjected_t lviTransformGetRotation = nullptr;
static LVITransformSetRotationInjected_t lviTransformSetRotation = nullptr;
static LVICameraGetFloat_t lviCameraGetFieldOfView = nullptr;
static LVICameraSetFloat_t lviCameraSetFieldOfView = nullptr;
static LVICameraGetFloat_t lviCameraGetOrthographicSize = nullptr;
static LVICameraSetFloat_t lviCameraSetOrthographicSize = nullptr;
static LVICameraGetBool_t lviCameraGetOrthographic = nullptr;
static bool lviActivityCameraAdapterReady = false;
static bool lviWithMeetsCameraAdapterReady = false;
static bool lviWithMeetsArchiveCameraAdapterReady = false;
static bool lviFesArchiveCameraAdapterReady = false;
static bool lviWithArchiveSelectorReady = false;
static bool lviWithMeetsArchiveSeekBarAdapterReady = false;
static std::atomic<bool> lviWithMeetsValidAfterRepairReady { false };

struct LVIWithMeetsAfterEntitlement {
	std::string archivesId;
	std::string liveId;
	bool hasExtra = false;
	bool hasExtraAdmission = false;
	int earnedStarCount = 0;
	int admissionThreshold = 0;
	bool derivedEligible = false;
	uint64_t catalogGeneration = 0;
};

static std::mutex lviWithMeetsAfterEvidenceMutex;
static std::unordered_map<std::string, LVIWithMeetsAfterEntitlement>
	lviAfterEntitlementByLiveId;
static std::unordered_map<std::string, std::string>
	lviAfterLiveIdByArchivesId;
static std::unordered_set<std::string> lviAmbiguousAfterLiveIds;
static std::unordered_set<std::string> lviAmbiguousAfterArchivesIds;
static uint64_t lviAfterCatalogGeneration = 0;
static bool lviPendingAfterRequestActive = false;
static LVIWithMeetsAfterEntitlement lviPendingAfterEntitlement;
static CFAbsoluteTime lviPendingAfterDeadline = 0;
static bool lviConfirmedAfterRequestActive = false;
static LVIWithMeetsAfterEntitlement lviConfirmedAfterEntitlement;
static std::string lviConfirmedAfterRequestId;
static CFAbsoluteTime lviConfirmedAfterRequestDeadline = 0;
static uint64_t lviConfirmedAfterRequestGeneration = 0;
static uint64_t lviAfterRequestGenerationCounter = 0;

struct LVIWithMeetsAfterPlayerAdmissionScope {
	bool active = false;
	LVIWithMeetsAfterEntitlement entitlement;
	uintptr_t detailResponseIdentity = 0;
	uint64_t catalogGeneration = 0;
	uint64_t scopeGeneration = 0;
	CFAbsoluteTime deadline = 0;
};

// The detail request is intentionally consumed before the content selector
// returns. Keep a separate, short-lived bridge for the later player-model
// construction boundary; otherwise a correct HasExtraAdmission value is lost
// when GiftPointModel is recreated from a different per-session data source.
static LVIWithMeetsAfterPlayerAdmissionScope
	lviWithMeetsAfterPlayerAdmissionScope;
static uint64_t lviWithMeetsAfterPlayerScopeGenerationCounter = 0;
static thread_local uint64_t
	lviWithMeetsAfterPlayerFactoryScopeGeneration = 0;

struct LVICameraRuntime {
	LVICameraScene scene = LVICameraScene::None;
	void *owner = nullptr;
	Unity::CCamera *camera = nullptr;
	Unity::CTransform *transform = nullptr;
	uint64_t generation = 0;
	bool freeMode = false;
	bool orthographic = false;
	Unity::Vector3 position {};
	Unity::Quaternion rotation {};
	float zoomValue = 60.0f;
	LVICameraCommandType lastCommand = LVICameraCommandType::None;
	Unity::Vector3 originalPosition {};
	Unity::Quaternion originalRotation {};
	float originalZoomValue = 60.0f;
};

static LVICameraRuntime lviCameraRuntime;
static void *lviWithDynamicCameraOwner = nullptr;
static void lviResetFesArchiveCameraAdapter();
static void *lviWithArchiveModelsOwner = nullptr;
static void *lviWithArchiveBlendCameraOwner = nullptr;
static void *lviWithArchiveOrientationModelsOwner = nullptr;
static bool lviWithArchiveIarcActive = false;
static std::atomic<void*> lviWithArchiveFullSeekModelsOwner { nullptr };
static std::atomic<void*>
	lviWithArchiveFullSeekPlayPositionModel { nullptr };
static std::atomic<void*>
	lviWithArchiveFullSeekControlModel { nullptr };
static std::atomic<bool> lviWithArchiveFullSeekActive { false };
using LVIWithArchiveControlAction = void (*)(void*, void*);
using LVIWithArchiveControlGetBool = bool (*)(void*, void*);
static LVIWithArchiveControlAction lviWithArchiveControlPlay = nullptr;
static LVIWithArchiveControlAction lviWithArchiveControlPause = nullptr;
static LVIWithArchiveControlGetBool
	lviWithArchiveControlGetIsLoading = nullptr;
static std::atomic<void*>
	lviWithArchivePlayPauseModelsOwner { nullptr };
static std::atomic<void*>
	lviWithArchivePlayPauseControlModel { nullptr };
static std::atomic<bool> lviWithArchivePlayPauseActive { false };
static std::atomic<bool>
	lviWithArchiveFalseEndSuppressionReported { false };
static std::atomic<Unity::il2cppClass*>
	lviWithArchiveReplayPredicateClosureClass { nullptr };
static bool lviPendingActivityPlayback = false;
static CFAbsoluteTime lviPendingActivityDeadline = 0;
static std::atomic<bool> lviActivityOrientationPending { false };
static std::atomic<bool> lviActivityPlaybackSessionActive { false };
static std::atomic<CFAbsoluteTime> lviActivityOrientationDeadline { 0 };
static std::atomic<CFAbsoluteTime> lviActivityRebindDeadline { 0 };
static std::atomic<bool> lviWithArchiveOrientationPending { false };
static std::atomic<bool> lviWithArchiveOrientationSessionActive { false };
static std::atomic<bool> lviWithArchiveIsHorizontal { false };
static std::atomic<CFAbsoluteTime> lviWithArchiveOrientationDeadline { 0 };
static std::atomic<CFAbsoluteTime> lviWithArchiveRebindDeadline { 0 };
static CFAbsoluteTime lviJoystickLastFrameTime = 0;
static CFAbsoluteTime lviJoystickLastPublishTime = 0;

static bool lviManagedObjectIsExactClass(
	IL2CPP::CClass *object,
	const char *expectedNamespace,
	const char *expectedName
);
static void* lviWithArchiveFullSeekPlayPositionModelFromModels(
	void *models
);
static void* lviWithArchiveFullSeekControlModelFromModels(void *models);
static void lviActivateWithArchivePlayPause(void *models);
static void lviClearWithArchivePlayPause(void *models = nullptr);

static float lviConfigFloat(NSString *key, float fallback) {
	id value = qualityConfig[key];
	return value && [value respondsToSelector:@selector(floatValue)]
		? [value floatValue]
		: fallback;
}

static bool lviActivityLandscapeRepairEnabled() {
	return configBoolDefault(
		@"ActivityRecord.LandscapeRepair.Enable",
		true
	);
}

static CFAbsoluteTime lviActivityRebindGraceSeconds() {
	float configured = lviConfigFloat(
		@"ActivityRecord.LandscapeRepair.RebindGraceSeconds",
		5.0f
	);
	return static_cast<CFAbsoluteTime>(
		MAX(1.0f, MIN(configured, 15.0f))
	);
}

static bool lviActivityOrientationPassthroughActive() {
	if (!lviActivityLandscapeRepairEnabled()) {
		return false;
	}
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	bool pending =
		lviActivityOrientationPending.load(std::memory_order_acquire) &&
		now <= lviActivityOrientationDeadline.load(
			std::memory_order_acquire
		);
	bool active = lviActivityPlaybackSessionActive.load(
		std::memory_order_acquire
	);
	bool rebinding =
		now <= lviActivityRebindDeadline.load(std::memory_order_acquire);
	return pending || active || rebinding;
}

static bool lviWithArchiveOrientationRepairEnabled() {
	return configBoolDefault(
		@"WithMeets.Archive.OrientationRepair.Enable",
		true
	);
}

static bool lviWithArchiveRenderImageCoverSuppressionEnabled() {
	return configBoolDefault(
		@"WithMeets.Archive.RenderImageCover.Suppress",
		false
	);
}

static bool lviWithArchivePlayPauseButtonEnabled() {
	return configBoolDefault(
		@"WithMeets.Archive.PlayPauseButton.Enable",
		false
	);
}

static bool lviWithArchiveLifecycleTrackingNeeded() {
	return lviWithArchiveOrientationRepairEnabled() ||
		lviWithArchiveRenderImageCoverSuppressionEnabled();
}

static bool lviWithArchiveIarcFullSeekEnabled() {
	return configBoolDefault(
		@"WithMeets.Archive.IarcFullSeek.Enable",
		false
	) && configBool(
		@"WithMeets.Archive.MotionCaptureReplay.Enable"
	);
}

static bool lviWithArchiveIarcReplayOverlaySuppressionEnabled() {
	return lviWithArchiveIarcFullSeekEnabled() &&
		configBoolDefault(
			@"WithMeets.Archive.IarcReplayOverlay.Suppress",
			true
		);
}

static void lviActivateWithArchiveIarcFullSeek(void *models) {
	// Validate a re-entry candidate completely before replacing the current
	// owner.  A duplicate or unrelated presenter must not erase a still-live
	// WM/IARC session.
	if (!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(models),
			"School.LiveMain",
			"LiveSystemModels"
		)) {
		return;
	}
	void *playPositionModel =
		lviWithArchiveFullSeekPlayPositionModelFromModels(models);
	void *controlModel =
		lviWithArchiveFullSeekControlModelFromModels(models);
	if (!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(
				playPositionModel
			),
			"School.LiveMain",
			"LiveConnectPlayPositionModel"
		) ||
		!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"School.LiveMain",
			"LiveConnectControlModel"
		)) {
		return;
	}
	lviWithArchiveFullSeekActive.store(false, std::memory_order_release);
	lviWithArchiveFullSeekModelsOwner.store(
		models,
		std::memory_order_release
	);
	lviWithArchiveFullSeekPlayPositionModel.store(
		playPositionModel,
		std::memory_order_release
	);
	lviWithArchiveFullSeekControlModel.store(
		controlModel,
		std::memory_order_release
	);
	lviWithArchiveFalseEndSuppressionReported.store(
		false,
		std::memory_order_release
	);
	lviWithArchiveFullSeekActive.store(true, std::memory_order_release);
}

static void lviClearWithArchiveIarcFullSeek(void *models = nullptr) {
	void *owner = lviWithArchiveFullSeekModelsOwner.load(
		std::memory_order_acquire
	);
	if (models && owner != models) {
		return;
	}
	lviWithArchiveFullSeekActive.store(false, std::memory_order_release);
	lviWithArchiveFalseEndSuppressionReported.store(
		false,
		std::memory_order_release
	);
	lviWithArchiveFullSeekControlModel.store(
		nullptr,
		std::memory_order_release
	);
	lviWithArchiveFullSeekPlayPositionModel.store(
		nullptr,
		std::memory_order_release
	);
	lviWithArchiveFullSeekModelsOwner.store(
		nullptr,
		std::memory_order_release
	);
}

static bool lviWithMeetsValidAfterRepairEnabled() {
#if LVI_WITH_AFTER_REPAIR
	return configBoolDefault(
		@"WithMeets.After.ValidAdmissionRepair.Enable",
		false
	);
#else
	// 0.7.0 installed an invalid ABI hook for the static
	// SchoolConnectArchiveListView.EnterToLiveScene method. Keep the whole
	// AFTER repair fail-closed at compile time in the recovery release,
	// including when an older user JSON still contains true.
	return false;
#endif
}

static CFAbsoluteTime lviWithArchiveRebindGraceSeconds() {
	float configured = lviConfigFloat(
		@"WithMeets.Archive.OrientationRepair.RebindGraceSeconds",
		5.0f
	);
	return static_cast<CFAbsoluteTime>(
		MAX(1.0f, MIN(configured, 15.0f))
	);
}

static bool lviWithArchiveLifecycleScopeActive() {
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	bool pending =
		lviWithArchiveOrientationPending.load(std::memory_order_acquire) &&
		now <= lviWithArchiveOrientationDeadline.load(
			std::memory_order_acquire
		);
	bool active = lviWithArchiveOrientationSessionActive.load(
		std::memory_order_acquire
	);
	bool rebinding =
		now <= lviWithArchiveRebindDeadline.load(
			std::memory_order_acquire
		);
	return pending || active || rebinding;
}

static bool lviWithArchiveOrientationPassthroughActive() {
	if (!lviWithArchiveOrientationRepairEnabled()) {
		return false;
	}
	return lviWithArchiveLifecycleScopeActive();
}

static bool lviWithArchiveRenderImageCoverSuppressionActive() {
	return lviWithArchiveRenderImageCoverSuppressionEnabled() &&
		lviWithArchiveLifecycleScopeActive();
}

static bool lviOrientationPassthroughActive() {
	return lviActivityOrientationPassthroughActive() ||
		lviWithArchiveOrientationPassthroughActive();
}

static IL2CPP::CClass* lviWithArchiveEnterResponse(void *selectorSelf) {
	if (!selectorSelf) {
		return nullptr;
	}
	IL2CPP::CClass *selector =
		reinterpret_cast<IL2CPP::CClass*>(selectorSelf);
	IL2CPP::CClass *cache =
		selector->GetMemberValue<IL2CPP::CClass*>("_enterResponseCache");
	return cache
		? cache->GetMemberValue<IL2CPP::CClass*>("Value")
		: nullptr;
}

static void lviClearWithMeetsAfterEvidence() {
	std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
	lviAfterEntitlementByLiveId.clear();
	lviAfterLiveIdByArchivesId.clear();
	lviAmbiguousAfterLiveIds.clear();
	lviAmbiguousAfterArchivesIds.clear();
	lviAfterCatalogGeneration = 0;
	lviPendingAfterRequestActive = false;
	lviPendingAfterEntitlement = {};
	lviPendingAfterDeadline = 0;
	lviConfirmedAfterRequestActive = false;
	lviConfirmedAfterEntitlement = {};
	lviConfirmedAfterRequestId.clear();
	lviConfirmedAfterRequestDeadline = 0;
	lviConfirmedAfterRequestGeneration = 0;
	lviWithMeetsAfterPlayerAdmissionScope = {};
}

static void lviClearPendingWithMeetsAfterRequest() {
	std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
	lviPendingAfterRequestActive = false;
	lviPendingAfterEntitlement = {};
	lviPendingAfterDeadline = 0;
	lviConfirmedAfterRequestActive = false;
	lviConfirmedAfterEntitlement = {};
	lviConfirmedAfterRequestId.clear();
	lviConfirmedAfterRequestDeadline = 0;
	lviConfirmedAfterRequestGeneration = 0;
	lviWithMeetsAfterPlayerAdmissionScope = {};
}

static void lviBeginWithMeetsAfterCatalogGeneration() {
	uint64_t generation = 0;
	{
		std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
		lviAfterEntitlementByLiveId.clear();
		lviAfterLiveIdByArchivesId.clear();
		lviAmbiguousAfterLiveIds.clear();
		lviAmbiguousAfterArchivesIds.clear();
		// A response object contains no archive identifier. Invalidate any
		// transaction when the authoritative catalog is replaced so a stale
		// selection can never be applied to a response from the new generation.
		lviPendingAfterRequestActive = false;
		lviPendingAfterEntitlement = {};
		lviPendingAfterDeadline = 0;
		lviConfirmedAfterRequestActive = false;
		lviConfirmedAfterEntitlement = {};
		lviConfirmedAfterRequestId.clear();
			lviConfirmedAfterRequestDeadline = 0;
			lviConfirmedAfterRequestGeneration = 0;
			lviWithMeetsAfterPlayerAdmissionScope = {};
			++lviAfterCatalogGeneration;
		if (lviAfterCatalogGeneration == 0) {
			lviAfterCatalogGeneration = 1;
		}
		generation = lviAfterCatalogGeneration;
	}
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-catalog-generation", @{
		@"generation": @(generation)
	});
#endif
}

static void lviClearWithMeetsAfterCatalogEvidence() {
	std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
	lviAfterEntitlementByLiveId.clear();
	lviAfterLiveIdByArchivesId.clear();
	lviAmbiguousAfterLiveIds.clear();
	lviAmbiguousAfterArchivesIds.clear();
	lviPendingAfterRequestActive = false;
	lviPendingAfterEntitlement = {};
	lviPendingAfterDeadline = 0;
	lviConfirmedAfterRequestActive = false;
	lviConfirmedAfterEntitlement = {};
	lviConfirmedAfterRequestId.clear();
	lviConfirmedAfterRequestDeadline = 0;
	lviConfirmedAfterRequestGeneration = 0;
	lviWithMeetsAfterPlayerAdmissionScope = {};
}

static void lviClearWithMeetsAfterPlayerAdmissionScope() {
	{
		std::lock_guard<std::mutex> lock(
			lviWithMeetsAfterEvidenceMutex
		);
		lviWithMeetsAfterPlayerAdmissionScope = {};
	}
	lviWithMeetsAfterPlayerFactoryScopeGeneration = 0;
}

static bool lviManagedClassIsExact(
	Unity::il2cppClass *managedClass,
	const char *expectedNamespace,
	const char *expectedName
) {
	if (!managedClass ||
		!managedClass->m_pNamespace ||
		!managedClass->m_pName ||
		!expectedNamespace ||
		!expectedName) {
		return false;
	}
	return strcmp(
			managedClass->m_pNamespace,
			expectedNamespace
		) == 0 &&
		strcmp(managedClass->m_pName, expectedName) == 0;
}

static bool lviManagedObjectIsExactClass(
	IL2CPP::CClass *object,
	const char *expectedNamespace,
	const char *expectedName
) {
	return object &&
		lviManagedClassIsExact(
			object->m_Object.m_pClass,
			expectedNamespace,
			expectedName
		);
}

static Unity::il2cppFieldInfo* lviExactInstanceField(
	IL2CPP::CClass *object,
	const char *fieldName
) {
	if (!object ||
		!object->m_Object.m_pClass ||
		!fieldName ||
		!IL2CPP::Functions.m_ClassGetFieldFromName) {
		return nullptr;
	}
	Unity::il2cppFieldInfo *field =
		reinterpret_cast<
			Unity::il2cppFieldInfo* (IL2CPP_CALLING_CONVENTION)(
				void*,
				const char*
			)
		>(IL2CPP::Functions.m_ClassGetFieldFromName)(
			object->m_Object.m_pClass,
			fieldName
		);
	// Instance fields must follow the two-pointer il2cppObject header.
	// Reject implausible offsets instead of ever touching klass/monitor or
	// an unbounded address if metadata and the native binary diverge.
	return field &&
		field->m_iOffset >= static_cast<int>(sizeof(Unity::il2cppObject)) &&
		field->m_iOffset <= 0x10000
		? field
		: nullptr;
}

template<typename T>
static bool lviReadExactInstanceField(
	IL2CPP::CClass *object,
	const char *fieldName,
	T& value
) {
	Unity::il2cppFieldInfo *field =
		lviExactInstanceField(object, fieldName);
	if (!field) {
		value = {};
		return false;
	}
	value = object->GetMemberValue<T>(field);
	return true;
}

static void* lviWithArchiveFullSeekPlayPositionModelFromModels(
	void *models
) {
	void *playPositionModel = nullptr;
	return lviReadExactInstanceField(
			reinterpret_cast<IL2CPP::CClass*>(models),
			"ConnectPlayPositionModel",
			playPositionModel
		)
		? playPositionModel
		: nullptr;
}

static void* lviWithArchiveFullSeekControlModelFromModels(void *models) {
	void *controlModel = nullptr;
	return lviReadExactInstanceField(
			reinterpret_cast<IL2CPP::CClass*>(models),
			"ConnectControlModel",
			controlModel
		)
		? controlModel
		: nullptr;
}

static bool lviReadWithArchivePlayPauseState(
	bool& playing,
	bool& ready
) {
	ready = false;
	if (!lviWithArchivePlayPauseActive.load(std::memory_order_acquire) ||
		!lviWithArchiveControlPlay ||
		!lviWithArchiveControlPause) {
		return false;
	}

	void *controlModel = lviWithArchivePlayPauseControlModel.load(
		std::memory_order_acquire
	);
	if (!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"School.LiveMain",
			"LiveConnectControlModel"
		)) {
		return false;
	}

	void *contentsController = nullptr;
	if (!lviReadExactInstanceField(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"_contentsController",
			contentsController
		) ||
		!contentsController) {
		return false;
	}

	bool isLoading = false;
	if (lviWithArchiveControlGetIsLoading) {
		isLoading = lviWithArchiveControlGetIsLoading(
			controlModel,
			nullptr
		);
	} else {
		lviReadExactInstanceField(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"<IsLoading>k__BackingField",
			isLoading
		);
	}
	if (isLoading) {
		return false;
	}

	// UniRx's BoolReactiveProperty stores its current value in the inherited
	// `value` field. Read it only through IL2CPP field metadata; if that field
	// cannot be resolved on a future binary, retain the last button state while
	// still allowing the exact validated controller to be paused/resumed.
	bool readPlaying = false;
	void *isPlayingProperty = nullptr;
	if (lviReadExactInstanceField(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"isPlayingProperty",
			isPlayingProperty
		) &&
		isPlayingProperty) {
		readPlaying = lviReadExactInstanceField(
			reinterpret_cast<IL2CPP::CClass*>(isPlayingProperty),
			"value",
			playing
		);
	}
	ready = true;
	return readPlaying;
}

static void lviActivateWithArchivePlayPause(void *models) {
	if (!lviWithArchivePlayPauseButtonEnabled() ||
		!lviWithArchiveControlPlay ||
		!lviWithArchiveControlPause ||
		!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(models),
			"School.LiveMain",
			"LiveSystemModels"
		)) {
		return;
	}
	void *controlModel =
		lviWithArchiveFullSeekControlModelFromModels(models);
	if (!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"School.LiveMain",
			"LiveConnectControlModel"
		)) {
		return;
	}

	lviWithArchivePlayPauseActive.store(
		false,
		std::memory_order_release
	);
	lviWithArchivePlayPauseModelsOwner.store(
		models,
		std::memory_order_release
	);
	lviWithArchivePlayPauseControlModel.store(
		controlModel,
		std::memory_order_release
	);
	lviWithArchivePlayPauseLastPlaying.store(
		true,
		std::memory_order_release
	);
	lviWithArchivePlayPauseActive.store(
		true,
		std::memory_order_release
	);
	lviWithArchivePlayPauseUIActive.store(
		true,
		std::memory_order_release
	);
	uint64_t refreshGeneration =
		lviWithArchivePlayPauseRefreshGeneration.fetch_add(
			1,
			std::memory_order_acq_rel
		) + 1;
	dispatch_async(dispatch_get_main_queue(), ^{
		lviRefreshWithArchivePlayPauseButtonOnMain();
	});
	lviScheduleWithArchivePlayPauseRefresh(refreshGeneration, 250);
}

static void lviClearWithArchivePlayPause(void *models) {
	void *owner = lviWithArchivePlayPauseModelsOwner.load(
		std::memory_order_acquire
	);
	if (models && owner != models) {
		return;
	}
	lviWithArchivePlayPauseRefreshGeneration.fetch_add(
		1,
		std::memory_order_acq_rel
	);
	lviWithArchivePlayPauseActive.store(
		false,
		std::memory_order_release
	);
	lviWithArchivePlayPauseUIActive.store(
		false,
		std::memory_order_release
	);
	lviWithArchivePlayPauseControlModel.store(
		nullptr,
		std::memory_order_release
	);
	lviWithArchivePlayPauseModelsOwner.store(
		nullptr,
		std::memory_order_release
	);
	lviWithArchivePlayPauseLastPlaying.store(
		true,
		std::memory_order_release
	);
	dispatch_async(dispatch_get_main_queue(), ^{
		if (lviWithArchivePlayPauseButton) {
			lviWithArchivePlayPauseButton.hidden = YES;
			lviWithArchivePlayPauseButton.userInteractionEnabled = NO;
			[lviWithArchivePlayPauseButton removeFromSuperview];
		}
	});
}

static void lviToggleWithArchivePlayPause() {
	if (!lviWithArchivePlayPauseButtonEnabled()) {
		return;
	}
	bool playing = lviWithArchivePlayPauseLastPlaying.load(
		std::memory_order_acquire
	);
	bool ready = false;
	lviReadWithArchivePlayPauseState(playing, ready);
	void *controlModel = lviWithArchivePlayPauseControlModel.load(
		std::memory_order_acquire
	);
	if (!ready ||
		!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"School.LiveMain",
			"LiveConnectControlModel"
		)) {
		lviRefreshWithArchivePlayPauseButtonOnMain();
		return;
	}

	if (playing) {
		lviWithArchiveControlPause(controlModel, nullptr);
	} else {
		lviWithArchiveControlPlay(controlModel, nullptr);
	}
	lviWithArchivePlayPauseLastPlaying.store(
		!playing,
		std::memory_order_release
	);
	lviRefreshWithArchivePlayPauseButtonOnMain();
	dispatch_after(
		dispatch_time(DISPATCH_TIME_NOW, 100 * NSEC_PER_MSEC),
		dispatch_get_main_queue(),
		^{
			lviRefreshWithArchivePlayPauseButtonOnMain();
		}
	);
}

template<typename T>
static bool lviWriteExactInstanceField(
	IL2CPP::CClass *object,
	const char *fieldName,
	T value
) {
	Unity::il2cppFieldInfo *field =
		lviExactInstanceField(object, fieldName);
	if (!field) {
		return false;
	}
	object->SetMemberValue<T>(field, value);
	return true;
}

static bool lviCopyManagedString(
	Unity::System_String *managedValue,
	std::string& copiedValue
) {
	copiedValue.clear();
	if (!managedValue) {
		return false;
	}
	int32_t length = managedValue->ToLength();
	if (length <= 0 || length > 512) {
		return false;
	}
	const uint16_t *characters = reinterpret_cast<const uint16_t*>(
		managedValue->ToWideChars()
	);
	if (!characters) {
		return false;
	}
	copiedValue.reserve(static_cast<size_t>(length));
	for (int32_t index = 0; index < length; ++index) {
		uint16_t character = characters[index];
		// Archive and live identifiers are API identifiers, not display
		// strings. Reject unexpected non-ASCII data instead of allocating an
		// NSString on a possibly non-main API serialization thread.
		if (character == 0 || character > 0x7f) {
			copiedValue.clear();
			return false;
		}
		copiedValue.push_back(static_cast<char>(character));
	}
	return !copiedValue.empty();
}

static bool lviCopyManagedStringMember(
	IL2CPP::CClass *object,
	const char *memberName,
	std::string& copiedValue
) {
	if (!object || !memberName) {
		copiedValue.clear();
		return false;
	}
	Unity::System_String *managedValue = nullptr;
	return lviReadExactInstanceField(
			object,
			memberName,
			managedValue
		) &&
		lviCopyManagedString(managedValue, copiedValue);
}

static IL2CPP::CClass* lviWithMeetsAfterEnterResponse(
	void *selectorSelf
) {
	IL2CPP::CClass *selector =
		reinterpret_cast<IL2CPP::CClass*>(selectorSelf);
	if (!lviManagedObjectIsExactClass(
			selector,
			"School.LiveMain",
			"WithArchiveContentTypeSelector"
		)) {
		return nullptr;
	}
	IL2CPP::CClass *cache = nullptr;
	if (!lviReadExactInstanceField(
			selector,
			"_enterResponseCache",
			cache
		) ||
		!lviManagedObjectIsExactClass(
			cache,
			"School.LiveMain",
			"WithArchiveEnterResponseCache"
		)) {
		return nullptr;
	}
	IL2CPP::CClass *response = nullptr;
	if (!lviReadExactInstanceField(cache, "Value", response) ||
		!lviManagedObjectIsExactClass(
			response,
			"Org.OpenAPITools.Model",
			"GetWithArchiveDataResponse"
		)) {
		return nullptr;
	}
	return response;
}

enum class LVIWithMeetsAfterRowResult : int {
	Invalid = 0,
	NoPositiveEvidence = 1,
	PositiveEvidence = 2,
};

static LVIWithMeetsAfterRowResult
lviWithMeetsAfterRowEvidence(
	IL2CPP::CClass *liveInfo,
	LVIWithMeetsAfterEntitlement& entitlement
) {
	entitlement = {};
	if (!lviManagedObjectIsExactClass(
			liveInfo,
			"Org.OpenAPITools.Model",
			"LiveInfo"
		)) {
		return LVIWithMeetsAfterRowResult::Invalid;
	}
	bool hasExtraAdmission = false;
	bool hasExtra = false;
	int liveType = 0;
	int earnedStarCount = 0;
	int admissionThreshold = 0;
	if (!lviReadExactInstanceField(
			liveInfo,
			"<HasExtraAdmission>k__BackingField",
			hasExtraAdmission
		) ||
		!lviReadExactInstanceField(
			liveInfo,
			"<HasExtra>k__BackingField",
			hasExtra
		) ||
		!lviReadExactInstanceField(
			liveInfo,
			"<LiveType>k__BackingField",
			liveType
		) ||
		!lviReadExactInstanceField(
			liveInfo,
			"<EarnedStarCount>k__BackingField",
			earnedStarCount
		) ||
		!lviReadExactInstanceField(
			liveInfo,
			"<GiftStarsThresholdForExtraAdmission>k__BackingField",
			admissionThreshold
		)) {
		return LVIWithMeetsAfterRowResult::Invalid;
	}
	// Org.OpenAPITools.Model.LiveTypeWithMeets is 2. Never use Fes,
	// With×STATION, or music-video rows as AFTER entitlement evidence.
	if (liveType != 2) {
		return LVIWithMeetsAfterRowResult::NoPositiveEvidence;
	}
	bool positiveEvidence =
		hasExtraAdmission ||
		(
			hasExtra &&
			admissionThreshold > 0 &&
			earnedStarCount >= admissionThreshold
		);
	if (!positiveEvidence) {
		return LVIWithMeetsAfterRowResult::NoPositiveEvidence;
	}
	if (!lviCopyManagedStringMember(
			liveInfo,
			"<ArchivesId>k__BackingField",
			entitlement.archivesId
		) ||
		!lviCopyManagedStringMember(
			liveInfo,
			"<LiveId>k__BackingField",
			entitlement.liveId
		)) {
		return LVIWithMeetsAfterRowResult::Invalid;
	}
	entitlement.hasExtra = hasExtra;
	entitlement.hasExtraAdmission = hasExtraAdmission;
	entitlement.earnedStarCount = earnedStarCount;
	entitlement.admissionThreshold = admissionThreshold;
	entitlement.derivedEligible =
		hasExtraAdmission ||
		(
			hasExtra &&
			admissionThreshold > 0 &&
			earnedStarCount >= admissionThreshold
		);
	return LVIWithMeetsAfterRowResult::PositiveEvidence;
}

static void lviRejectWithMeetsAfterEvidence(const char *reason) {
	// A malformed replacement page invalidates both the catalog and any
	// response transaction that can no longer be tied to that generation.
	lviClearWithMeetsAfterCatalogEvidence();
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-catalog-rejected", @{
		@"reason": reason
			? [NSString stringWithUTF8String:reason]
			: @"unknown-layout-error"
	});
#endif
	NSLog(
		@"[LinkuraVisualsIOS][WithAfter] Rejected archive evidence: %s",
		reason ? reason : "unknown layout error"
	);
}

static Unity::il2cppClass* lviWithMeetsLiveInfoArrayClass() {
	if (!IL2CPP::Functions.m_ArrayGetClass) {
		return nullptr;
	}
	Unity::il2cppClass *liveInfoClass =
		IL2CPP::Class::Find("Org.OpenAPITools.Model.LiveInfo");
	if (!liveInfoClass) {
		return nullptr;
	}
	return reinterpret_cast<
		Unity::il2cppClass* (IL2CPP_CALLING_CONVENTION)(
			Unity::il2cppClass*,
			uint32_t
		)
	>(IL2CPP::Functions.m_ArrayGetClass)(liveInfoClass, 1);
}

static bool lviReadWithMeetsAfterArchiveList(
	IL2CPP::CClass *response,
	IL2CPP::CClass *&archiveList,
	Unity::il2cppArray<IL2CPP::CClass*> *&items,
	int& count
) {
	archiveList = nullptr;
	items = nullptr;
	count = 0;
	if (!lviManagedObjectIsExactClass(
			response,
			"Org.OpenAPITools.Model",
			"GetArchiveListResponse"
		) ||
		!lviReadExactInstanceField(
			response,
			"<ArchiveList>k__BackingField",
			archiveList
		) ||
		!archiveList ||
		!lviManagedObjectIsExactClass(
			archiveList,
			"System.Collections.Generic",
			"List`1"
		) ||
		!lviReadExactInstanceField(archiveList, "_items", items) ||
		!lviReadExactInstanceField(archiveList, "_size", count) ||
		!items ||
		!items->m_pClass ||
		items->m_pBounds != nullptr ||
		items->m_pClass != lviWithMeetsLiveInfoArrayClass() ||
		count < 0 ||
		count > 10000 ||
		static_cast<uintptr_t>(count) > items->m_uMaxLength ||
		items->m_uMaxLength > 100000) {
		return false;
	}
	return true;
}

static bool lviWithMeetsAfterResponseHasAdmissionEvidence(
	IL2CPP::CClass *response,
	bool& hasExtra,
	bool& hasExtraAdmission
) {
	hasExtra = false;
	hasExtraAdmission = false;
	return lviManagedObjectIsExactClass(
			response,
			"Org.OpenAPITools.Model",
			"GetWithArchiveDataResponse"
		) &&
		lviReadExactInstanceField(
			response,
			"<HasExtra>k__BackingField",
			hasExtra
		) &&
		lviReadExactInstanceField(
			response,
			"<HasExtraAdmission>k__BackingField",
			hasExtraAdmission
		);
}

static Unity::il2cppClass* lviWithMeetsArchiveChapterArrayClass() {
	if (!IL2CPP::Functions.m_ArrayGetClass) {
		return nullptr;
	}
	Unity::il2cppClass *chapterClass =
		IL2CPP::Class::Find(
			"Org.OpenAPITools.Model.ArchiveWithliveChapter"
		);
	if (!chapterClass) {
		return nullptr;
	}
	return reinterpret_cast<
		Unity::il2cppClass* (IL2CPP_CALLING_CONVENTION)(
			Unity::il2cppClass*,
			uint32_t
		)
	>(IL2CPP::Functions.m_ArrayGetClass)(chapterClass, 1);
}

static bool lviWithMeetsAfterResponseHasExtraChapter(
	IL2CPP::CClass *response
) {
	if (!lviManagedObjectIsExactClass(
			response,
			"Org.OpenAPITools.Model",
			"GetWithArchiveDataResponse"
		)) {
		return false;
	}
	IL2CPP::CClass *chapters = nullptr;
	Unity::il2cppArray<IL2CPP::CClass*> *items = nullptr;
	int count = 0;
	if (!lviReadExactInstanceField(
			response,
			"<Chapters>k__BackingField",
			chapters
		) ||
		!lviManagedObjectIsExactClass(
			chapters,
			"System.Collections.Generic",
			"List`1"
		) ||
		!lviReadExactInstanceField(chapters, "_items", items) ||
		!lviReadExactInstanceField(chapters, "_size", count) ||
		!items ||
		!items->m_pClass ||
		items->m_pBounds != nullptr ||
		items->m_pClass != lviWithMeetsArchiveChapterArrayClass() ||
		count <= 0 ||
		count > 1000 ||
		static_cast<uintptr_t>(count) > items->m_uMaxLength ||
		items->m_uMaxLength > 10000) {
		return false;
	}
	for (int index = 0; index < count; ++index) {
		IL2CPP::CClass *chapter =
			items->At(static_cast<unsigned int>(index));
		if (!lviManagedObjectIsExactClass(
				chapter,
				"Org.OpenAPITools.Model",
				"ArchiveWithliveChapter"
			)) {
			return false;
		}
		bool isExtra = false;
		if (!lviReadExactInstanceField(
				chapter,
				"<IsExtra>k__BackingField",
				isExtra
			)) {
			return false;
		}
		if (isExtra) {
			return true;
		}
	}
	return false;
}

static Unity::il2cppClass* lviInt32ArrayClass() {
	if (!IL2CPP::Functions.m_ArrayGetClass) {
		return nullptr;
	}
	Unity::il2cppClass *int32Class =
		IL2CPP::Class::Find("System.Int32");
	if (!int32Class) {
		return nullptr;
	}
	return reinterpret_cast<
		Unity::il2cppClass* (IL2CPP_CALLING_CONVENTION)(
			Unity::il2cppClass*,
			uint32_t
		)
	>(IL2CPP::Functions.m_ArrayGetClass)(int32Class, 1);
}

static bool lviWithMeetsAfterResponseHasExtendedDuration(
	IL2CPP::CClass *response
) {
	if (!lviManagedObjectIsExactClass(
			response,
			"Org.OpenAPITools.Model",
			"GetWithArchiveDataResponse"
		)) {
		return false;
	}
	int totalWithoutExtra = 0;
	int totalIncludingExtra = 0;
	if (!lviReadExactInstanceField(
			response,
			"<TotalPlayTimeSecondWithoutExtra>k__BackingField",
			totalWithoutExtra
		) ||
		!lviReadExactInstanceField(
			response,
			"<TotalPlayTimeSecondIncludingExtra>k__BackingField",
			totalIncludingExtra
		)) {
		return false;
	}
	return totalWithoutExtra > 0 &&
		totalIncludingExtra > totalWithoutExtra;
}

static bool lviArmWithMeetsAfterPlayerAdmissionScope(
	const LVIWithMeetsAfterEntitlement& entitlement,
	IL2CPP::CClass *detailResponse
) {
	bool armed = false;
	uint64_t scopeGeneration = 0;
	{
		std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
		if (
			entitlement.derivedEligible &&
			entitlement.hasExtra &&
			entitlement.hasExtraAdmission &&
			entitlement.admissionThreshold > 0 &&
			entitlement.earnedStarCount >= entitlement.admissionThreshold &&
			entitlement.catalogGeneration != 0 &&
			entitlement.catalogGeneration == lviAfterCatalogGeneration &&
			lviManagedObjectIsExactClass(
				detailResponse,
				"Org.OpenAPITools.Model",
				"GetWithArchiveDataResponse"
			) &&
			!entitlement.archivesId.empty() &&
			!entitlement.liveId.empty() &&
			lviAmbiguousAfterLiveIds.count(entitlement.liveId) == 0 &&
			lviAmbiguousAfterArchivesIds.count(entitlement.archivesId) == 0
		) {
			++lviWithMeetsAfterPlayerScopeGenerationCounter;
			if (lviWithMeetsAfterPlayerScopeGenerationCounter == 0) {
				lviWithMeetsAfterPlayerScopeGenerationCounter = 1;
			}
			scopeGeneration =
				lviWithMeetsAfterPlayerScopeGenerationCounter;
			lviWithMeetsAfterPlayerAdmissionScope.active = true;
			lviWithMeetsAfterPlayerAdmissionScope.entitlement =
				entitlement;
			lviWithMeetsAfterPlayerAdmissionScope.detailResponseIdentity =
				reinterpret_cast<uintptr_t>(detailResponse);
			lviWithMeetsAfterPlayerAdmissionScope.catalogGeneration =
				entitlement.catalogGeneration;
			lviWithMeetsAfterPlayerAdmissionScope.scopeGeneration =
				scopeGeneration;
			// GiftPointModel is normally created immediately after selection.
			// The bounded grace period covers asset/scene loading without
			// leaving an admission decision available to a later archive.
			lviWithMeetsAfterPlayerAdmissionScope.deadline =
				CFAbsoluteTimeGetCurrent() + 120.0;
			armed = true;
		} else {
			lviWithMeetsAfterPlayerAdmissionScope = {};
		}
	}
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-player-scope", @{
		@"operation": @"arm",
		@"armed": @(armed),
		@"scopeGeneration": @(scopeGeneration),
		@"archiveIdToken":
			lviAfterDiagnosticIdentifier(entitlement.archivesId),
		@"detailResponseIdentity": @(
			static_cast<unsigned long long>(
				reinterpret_cast<uintptr_t>(detailResponse)
			)
		),
		@"catalogGeneration": @(entitlement.catalogGeneration),
		@"earnedStarCount": @(entitlement.earnedStarCount),
		@"admissionThreshold": @(entitlement.admissionThreshold)
	});
#endif
	return armed;
}

struct LVIWithMeetsAfterPlayerAdmissionDecision {
	bool matched = false;
	bool shouldRepair = false;
	bool stockAdmission = false;
	bool modelHasExtra = false;
	int modelAdmissionThreshold = 0;
	uint64_t scopeGeneration = 0;
	LVIWithMeetsAfterEntitlement entitlement;
	const char *reason = "no-active-scope";
};

struct LVIWithMeetsAfterPlayerFactoryDecision {
	bool matched = false;
	uint64_t scopeGeneration = 0;
	uintptr_t detailResponseIdentity = 0;
	const char *reason = "factory-not-matched";
};

static LVIWithMeetsAfterPlayerFactoryDecision
lviMatchWithMeetsAfterPlayerFactoryScope(void *factorySelf) {
	LVIWithMeetsAfterPlayerFactoryDecision decision;
	if (!lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(factorySelf),
			"School.LiveMain",
			"WithConnectModelsFactory"
		)) {
		decision.reason = "wrong-factory-class";
		return decision;
	}
	IL2CPP::CClass *factory =
		reinterpret_cast<IL2CPP::CClass*>(factorySelf);
	IL2CPP::CClass *cache = nullptr;
	IL2CPP::CClass *detailResponse = nullptr;
	if (!lviReadExactInstanceField(
			factory,
			"_enterResponseCache",
			cache
		) ||
		!lviManagedObjectIsExactClass(
			cache,
			"School.LiveMain",
			"WithArchiveEnterResponseCache"
		) ||
		!lviReadExactInstanceField(cache, "Value", detailResponse) ||
		!lviManagedObjectIsExactClass(
			detailResponse,
			"Org.OpenAPITools.Model",
			"GetWithArchiveDataResponse"
		)) {
		decision.reason = "factory-detail-response-invalid";
		return decision;
	}
	decision.detailResponseIdentity =
		reinterpret_cast<uintptr_t>(detailResponse);
	std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
	LVIWithMeetsAfterPlayerAdmissionScope& scope =
		lviWithMeetsAfterPlayerAdmissionScope;
	if (!scope.active) {
		decision.reason = "no-active-player-scope";
		return decision;
	}
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	if (scope.deadline <= 0 || now > scope.deadline) {
		decision.reason = "player-scope-expired";
		scope = {};
		return decision;
	}
	if (
		scope.catalogGeneration == 0 ||
		scope.catalogGeneration != lviAfterCatalogGeneration ||
		scope.entitlement.catalogGeneration != scope.catalogGeneration
	) {
		decision.reason = "player-scope-catalog-changed";
		scope = {};
		return decision;
	}
	if (
		scope.detailResponseIdentity == 0 ||
		scope.detailResponseIdentity != decision.detailResponseIdentity
	) {
		decision.reason = "factory-response-mismatch";
		return decision;
	}
	decision.matched = true;
	decision.scopeGeneration = scope.scopeGeneration;
	decision.reason = "exact-factory-response-match";
	return decision;
}

static bool lviFinishWithMeetsAfterPlayerFactoryScope(
	uint64_t scopeGeneration
) {
	if (scopeGeneration == 0) {
		return false;
	}
	bool clearedUnusedScope = false;
	{
		std::lock_guard<std::mutex> lock(
			lviWithMeetsAfterEvidenceMutex
		);
		if (
			lviWithMeetsAfterPlayerAdmissionScope.active &&
			lviWithMeetsAfterPlayerAdmissionScope.scopeGeneration ==
				scopeGeneration
		) {
			lviWithMeetsAfterPlayerAdmissionScope = {};
			clearedUnusedScope = true;
		}
	}
	return clearedUnusedScope;
}

static LVIWithMeetsAfterPlayerAdmissionDecision
lviConsumeWithMeetsAfterPlayerAdmissionScope(
	int modelAdmissionThreshold,
	bool stockAdmission,
	bool modelHasExtra,
	uint64_t factoryScopeGeneration
) {
	LVIWithMeetsAfterPlayerAdmissionDecision decision;
	decision.stockAdmission = stockAdmission;
	decision.modelHasExtra = modelHasExtra;
	decision.modelAdmissionThreshold = modelAdmissionThreshold;
	std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
	LVIWithMeetsAfterPlayerAdmissionScope& scope =
		lviWithMeetsAfterPlayerAdmissionScope;
	if (!scope.active) {
		return decision;
	}
	if (
		factoryScopeGeneration == 0 ||
		factoryScopeGeneration !=
			lviWithMeetsAfterPlayerFactoryScopeGeneration ||
		factoryScopeGeneration != scope.scopeGeneration
	) {
		decision.reason = "outside-exact-factory-scope";
		return decision;
	}
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	if (scope.deadline <= 0 || now > scope.deadline) {
		decision.reason = "scope-expired";
		scope = {};
		return decision;
	}
	if (
		scope.catalogGeneration == 0 ||
		scope.catalogGeneration != lviAfterCatalogGeneration ||
		scope.entitlement.catalogGeneration != scope.catalogGeneration
	) {
		decision.reason = "catalog-generation-changed";
		scope = {};
		return decision;
	}
	if (
		!scope.entitlement.derivedEligible ||
		!scope.entitlement.hasExtra ||
		!scope.entitlement.hasExtraAdmission ||
		scope.entitlement.admissionThreshold <= 0 ||
		scope.entitlement.earnedStarCount <
			scope.entitlement.admissionThreshold ||
		scope.detailResponseIdentity == 0 ||
		scope.entitlement.archivesId.empty() ||
		scope.entitlement.liveId.empty()
	) {
		decision.reason = "scope-entitlement-invalid";
		scope = {};
		return decision;
	}
	// This model type is specific to WM gift-point progression. Require its
	// own AFTER metadata as a second boundary, but do not overwrite points,
	// reward segments, star counts, or thresholds.
	if (
		!modelHasExtra ||
		modelAdmissionThreshold <= 0 ||
		modelAdmissionThreshold != scope.entitlement.admissionThreshold
	) {
		decision.reason = "model-not-after-capable";
		return decision;
	}
	decision.matched = true;
	decision.shouldRepair = !stockAdmission;
	decision.scopeGeneration = scope.scopeGeneration;
	decision.entitlement = scope.entitlement;
	decision.reason = stockAdmission
		? "stock-already-admitted"
		: "repair-admission-argument";
	scope = {};
	return decision;
}

static bool lviCacheWithMeetsAfterEvidence(
	const LVIWithMeetsAfterEntitlement& observedEntitlement
) {
	std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
	LVIWithMeetsAfterEntitlement entitlement = observedEntitlement;
	entitlement.catalogGeneration = lviAfterCatalogGeneration;
	if (entitlement.catalogGeneration == 0 ||
		lviAmbiguousAfterLiveIds.count(entitlement.liveId) != 0 ||
		lviAmbiguousAfterArchivesIds.count(entitlement.archivesId) != 0) {
		return false;
	}
	auto reverse =
		lviAfterLiveIdByArchivesId.find(entitlement.archivesId);
	if (reverse != lviAfterLiveIdByArchivesId.end() &&
		reverse->second != entitlement.liveId) {
		lviAfterEntitlementByLiveId.erase(reverse->second);
		lviAmbiguousAfterLiveIds.insert(reverse->second);
		lviAmbiguousAfterLiveIds.insert(entitlement.liveId);
		lviAfterLiveIdByArchivesId.erase(reverse);
		lviAmbiguousAfterArchivesIds.insert(entitlement.archivesId);
		return false;
	}
	auto existing =
		lviAfterEntitlementByLiveId.find(entitlement.liveId);
	if (existing == lviAfterEntitlementByLiveId.end()) {
		lviAfterEntitlementByLiveId.emplace(
			entitlement.liveId,
			entitlement
		);
		lviAfterLiveIdByArchivesId.emplace(
			entitlement.archivesId,
			entitlement.liveId
		);
		return true;
	}
	const LVIWithMeetsAfterEntitlement& prior = existing->second;
	if (prior.archivesId == entitlement.archivesId &&
		prior.hasExtra == entitlement.hasExtra &&
		prior.hasExtraAdmission == entitlement.hasExtraAdmission &&
		prior.earnedStarCount == entitlement.earnedStarCount &&
		prior.admissionThreshold == entitlement.admissionThreshold &&
		prior.derivedEligible == entitlement.derivedEligible &&
		prior.catalogGeneration == entitlement.catalogGeneration) {
		return true;
	}
	lviAfterLiveIdByArchivesId.erase(prior.archivesId);
	lviAmbiguousAfterArchivesIds.insert(prior.archivesId);
	lviAmbiguousAfterArchivesIds.insert(entitlement.archivesId);
	lviAfterEntitlementByLiveId.erase(existing);
	lviAmbiguousAfterLiveIds.insert(entitlement.liveId);
	return false;
}

static void lviIngestWithMeetsAfterEvidence(
	void *archiveResponse
) {
	bool enabled = lviWithMeetsValidAfterRepairEnabled();
	bool ready = lviWithMeetsValidAfterRepairReady.load(
		std::memory_order_acquire
	);
	if (!enabled || !ready) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-catalog-ingest-skipped", @{
			@"enabled": @(enabled),
			@"ready": @(ready),
			@"responseAvailable": @(archiveResponse != nullptr)
		});
#endif
		return;
	}
	if (!archiveResponse) {
		lviRejectWithMeetsAfterEvidence("null archive response");
		return;
	}
	IL2CPP::CClass *response =
		reinterpret_cast<IL2CPP::CClass*>(archiveResponse);
	IL2CPP::CClass *archiveList = nullptr;
	Unity::il2cppArray<IL2CPP::CClass*> *items = nullptr;
	int count = 0;
	if (!lviReadWithMeetsAfterArchiveList(
			response,
			archiveList,
			items,
			count
		)) {
		lviRejectWithMeetsAfterEvidence("invalid archive list layout");
		return;
	}
	int accepted = 0;
	int ambiguous = 0;
	for (int index = 0; index < count; ++index) {
		IL2CPP::CClass *liveInfo =
			items->At(static_cast<unsigned int>(index));
		LVIWithMeetsAfterEntitlement entitlement;
		LVIWithMeetsAfterRowResult result =
			lviWithMeetsAfterRowEvidence(
				liveInfo,
				entitlement
			);
		if (result == LVIWithMeetsAfterRowResult::Invalid) {
			lviRejectWithMeetsAfterEvidence(
				"invalid LiveInfo row or entitlement field"
			);
			return;
		}
		if (result != LVIWithMeetsAfterRowResult::PositiveEvidence) {
			continue;
		}
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-catalog-positive-row", @{
			@"archiveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.archivesId),
			@"liveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.liveId),
			@"hasExtra": @(entitlement.hasExtra),
			@"hasExtraAdmission": @(entitlement.hasExtraAdmission),
			@"earnedStarCount": @(entitlement.earnedStarCount),
			@"admissionThreshold": @(entitlement.admissionThreshold),
			@"derivedEligible": @(entitlement.derivedEligible)
		});
#endif
		if (lviCacheWithMeetsAfterEvidence(entitlement)) {
			++accepted;
		} else {
			++ambiguous;
		}
	}
#if LVI_WM_DIAGNOSTIC
	uint64_t generation = 0;
	size_t cachedCount = 0;
	{
		std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
		generation = lviAfterCatalogGeneration;
		cachedCount = lviAfterEntitlementByLiveId.size();
	}
	lviWriteAfterDiagnostic(@"after-catalog-ingested", @{
		@"rowCount": @(count),
		@"acceptedOnPage": @(accepted),
		@"ambiguousOnPage": @(ambiguous),
		@"cachedEligibleCount": @(cachedCount),
		@"generation": @(generation)
	});
#endif
	NSLog(
		@"[LinkuraVisualsIOS][WithAfter] Cached %d positive archive row(s); "
		 "%d ambiguous mapping(s) were rejected.",
		accepted,
		ambiguous
	);
}

static bool lviResolvePositiveWithMeetsAfterEntitlement(
	IL2CPP::CClass *archiveItemModel,
	LVIWithMeetsAfterEntitlement& entitlement
) {
	entitlement = {};
	if (!lviManagedObjectIsExactClass(
			archiveItemModel,
			"Tecotec",
			"LiveArchiveItemModel"
		) ||
		!lviWithMeetsValidAfterRepairEnabled() ||
		!lviWithMeetsValidAfterRepairReady.load(std::memory_order_acquire)) {
		return false;
	}
	std::string liveId;
	if (!lviCopyManagedStringMember(
			archiveItemModel,
			"<LiveId>k__BackingField",
			liveId
		)) {
		return false;
	}
	std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
	if (lviAmbiguousAfterLiveIds.count(liveId) != 0) {
		return false;
	}
	auto mapped = lviAfterEntitlementByLiveId.find(liveId);
	if (mapped == lviAfterEntitlementByLiveId.end() ||
		mapped->second.liveId != liveId ||
		mapped->second.archivesId.empty() ||
		mapped->second.catalogGeneration == 0 ||
		mapped->second.catalogGeneration != lviAfterCatalogGeneration ||
		!mapped->second.derivedEligible ||
		lviAmbiguousAfterArchivesIds.count(
			mapped->second.archivesId
		) != 0) {
		return false;
	}
	auto reverse =
		lviAfterLiveIdByArchivesId.find(mapped->second.archivesId);
	if (reverse == lviAfterLiveIdByArchivesId.end() ||
		reverse->second != liveId) {
		return false;
	}
	entitlement = mapped->second;
	return true;
}

static void lviConfirmWithMeetsAfterRequest(
	Unity::System_String *requestedIdentifier
) {
	bool enabled = lviWithMeetsValidAfterRepairEnabled();
	bool ready = lviWithMeetsValidAfterRepairReady.load(
		std::memory_order_acquire
	);
	if (!requestedIdentifier || !enabled || !ready) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-request-confirm", @{
			@"confirmed": @false,
			@"reason": !requestedIdentifier
				? @"missing-request-id"
				: (!enabled ? @"disabled" : @"pipeline-not-ready"),
			@"enabled": @(enabled),
			@"ready": @(ready)
		});
#endif
		return;
	}
	std::string requested;
	if (!lviCopyManagedString(requestedIdentifier, requested)) {
		lviClearPendingWithMeetsAfterRequest();
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-request-confirm", @{
			@"confirmed": @false,
			@"reason": @"invalid-request-id"
		});
#endif
		return;
	}
	bool confirmed = false;
	const char *reason = "unknown";
	uint64_t catalogGeneration = 0;
	uint64_t requestGeneration = 0;
	size_t cachedEligibleCount = 0;
	LVIWithMeetsAfterEntitlement matchedEntitlement;
	{
		std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
		CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
		// The request constructor is the deterministic boundary between the
		// selected archive row and its detail response. The constructor
		// parameter is ArchivesId, so resolve it through the exact reverse map
		// rather than incorrectly treating it as LiveId.
		lviPendingAfterRequestActive = false;
		lviPendingAfterEntitlement = {};
		lviPendingAfterDeadline = 0;
		lviConfirmedAfterRequestActive = false;
		lviConfirmedAfterEntitlement = {};
		lviConfirmedAfterRequestId.clear();
		lviConfirmedAfterRequestDeadline = 0;
		lviConfirmedAfterRequestGeneration = 0;
		// A newly constructed detail request supersedes any player-model
		// bridge left by the previously selected archive.
		lviWithMeetsAfterPlayerAdmissionScope = {};
		catalogGeneration = lviAfterCatalogGeneration;
		cachedEligibleCount = lviAfterEntitlementByLiveId.size();
		if (lviAfterCatalogGeneration == 0) {
			reason = "catalog-not-captured";
		} else if (
			lviAmbiguousAfterArchivesIds.count(requested) != 0
		) {
			reason = "archive-id-ambiguous";
		} else {
			auto reverse = lviAfterLiveIdByArchivesId.find(requested);
			if (reverse == lviAfterLiveIdByArchivesId.end() ||
				reverse->second.empty()) {
				reason = "archive-id-not-cached";
			} else if (
				lviAmbiguousAfterLiveIds.count(reverse->second) != 0
			) {
				reason = "live-id-ambiguous";
			} else {
				auto mapped =
					lviAfterEntitlementByLiveId.find(reverse->second);
				if (mapped == lviAfterEntitlementByLiveId.end() ||
					mapped->second.liveId != reverse->second ||
					mapped->second.archivesId != requested ||
					mapped->second.archivesId.empty() ||
					!mapped->second.hasExtra ||
					!mapped->second.derivedEligible ||
					mapped->second.catalogGeneration == 0 ||
					mapped->second.catalogGeneration !=
						lviAfterCatalogGeneration ||
					lviAmbiguousAfterArchivesIds.count(
						mapped->second.archivesId
					) != 0 ||
					reverse->second != mapped->second.liveId) {
					reason = "cached-entitlement-invalid";
				} else {
					lviConfirmedAfterRequestActive = true;
					lviConfirmedAfterEntitlement = mapped->second;
					lviConfirmedAfterRequestId = requested;
					lviConfirmedAfterRequestDeadline = now + 30.0;
					lviConfirmedAfterRequestGeneration =
						++lviAfterRequestGenerationCounter;
					confirmed = true;
					reason = "confirmed";
					requestGeneration =
						lviConfirmedAfterRequestGeneration;
					matchedEntitlement = mapped->second;
				}
			}
		}
	}
#if LVI_WM_DIAGNOSTIC
	NSMutableDictionary *diagnostic = [@{
		@"confirmed": @(confirmed),
		@"reason": [NSString stringWithUTF8String:reason],
		@"archiveIdToken": lviAfterDiagnosticIdentifier(requested),
		@"catalogGeneration": @(catalogGeneration),
		@"requestGeneration": @(requestGeneration),
		@"cachedEligibleCount": @(cachedEligibleCount)
	} mutableCopy];
	if (confirmed) {
		diagnostic[@"liveIdToken"] =
			lviAfterDiagnosticIdentifier(matchedEntitlement.liveId);
		diagnostic[@"hasExtra"] = @(matchedEntitlement.hasExtra);
		diagnostic[@"hasExtraAdmission"] =
			@(matchedEntitlement.hasExtraAdmission);
		diagnostic[@"earnedStarCount"] =
			@(matchedEntitlement.earnedStarCount);
		diagnostic[@"admissionThreshold"] =
			@(matchedEntitlement.admissionThreshold);
	}
	lviWriteAfterDiagnostic(@"after-request-confirm", diagnostic);
#endif
	if (confirmed) {
		NSLog(
			@"[LinkuraVisualsIOS][WithAfter] Confirmed exact catalog-row "
			 "request generation %llu.",
			static_cast<unsigned long long>(requestGeneration)
		);
	}
}

static bool lviConsumeConfirmedWithMeetsAfterRequest(
	LVIWithMeetsAfterEntitlement& entitlement
) {
	entitlement = {};
	bool consumed = false;
	const char *reason = "unknown";
	bool active = false;
	LVIWithMeetsAfterEntitlement confirmed;
	std::string requestId;
	CFAbsoluteTime deadline = 0;
	uint64_t generation = 0;
	uint64_t currentCatalogGeneration = 0;
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	{
		std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
		active = lviConfirmedAfterRequestActive;
		confirmed = lviConfirmedAfterEntitlement;
		requestId = lviConfirmedAfterRequestId;
		deadline = lviConfirmedAfterRequestDeadline;
		generation = lviConfirmedAfterRequestGeneration;
		currentCatalogGeneration = lviAfterCatalogGeneration;
		lviConfirmedAfterRequestActive = false;
		lviConfirmedAfterEntitlement = {};
		lviConfirmedAfterRequestId.clear();
		lviConfirmedAfterRequestDeadline = 0;
		lviConfirmedAfterRequestGeneration = 0;
		if (!active) {
			reason = "no-confirmed-request";
		} else if (
			confirmed.liveId.empty() ||
			confirmed.archivesId.empty()
		) {
			reason = "confirmed-identifiers-missing";
		} else if (!confirmed.derivedEligible) {
			reason = "confirmed-entitlement-ineligible";
		} else if (confirmed.catalogGeneration == 0) {
			reason = "confirmed-catalog-generation-missing";
		} else if (
			confirmed.catalogGeneration != lviAfterCatalogGeneration
		) {
			reason = "catalog-generation-changed";
		} else if (requestId != confirmed.archivesId) {
			reason = "confirmed-request-id-mismatch";
		} else if (generation == 0) {
			reason = "request-generation-missing";
		} else if (deadline <= 0) {
			reason = "request-deadline-missing";
		} else if (CFAbsoluteTimeGetCurrent() > deadline) {
			reason = "request-expired";
		} else {
			entitlement = confirmed;
			consumed = true;
			reason = "consumed";
		}
	}
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-request-consume", @{
		@"consumed": @(consumed),
		@"reason": [NSString stringWithUTF8String:reason],
		@"requestGeneration": @(generation),
		@"catalogGeneration": @(currentCatalogGeneration),
		@"confirmedCatalogGeneration": @(confirmed.catalogGeneration),
		@"archiveIdToken": lviAfterDiagnosticIdentifier(requestId),
		@"deadlineSecondsRemaining": @(deadline > 0
			? static_cast<double>(deadline - now)
			: 0.0)
	});
#endif
	return consumed;
}

static void lviRepairLegitimateWithMeetsAfter(void *selectorSelf) {
	bool enabled = lviWithMeetsValidAfterRepairEnabled();
	bool ready = lviWithMeetsValidAfterRepairReady.load(
		std::memory_order_acquire
	);
	if (!enabled || !ready) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": !enabled ? @"disabled" : @"pipeline-not-ready",
			@"enabled": @(enabled),
			@"ready": @(ready)
		});
#endif
		return;
	}
	// Consume the request transaction before inspecting the response. It is
	// deliberately one-shot, including when the stock response is already
	// correct or later validation fails, so it cannot leak to another item.
	LVIWithMeetsAfterEntitlement entitlement;
	if (!lviConsumeConfirmedWithMeetsAfterRequest(entitlement)) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": @"no-matching-request"
		});
#endif
		return;
	}
	if (!entitlement.hasExtra || !entitlement.derivedEligible) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": @"catalog-entitlement-ineligible",
			@"archiveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.archivesId),
			@"hasExtra": @(entitlement.hasExtra),
			@"derivedEligible": @(entitlement.derivedEligible),
			@"earnedStarCount": @(entitlement.earnedStarCount),
			@"admissionThreshold": @(entitlement.admissionThreshold)
		});
#endif
		return;
	}
	IL2CPP::CClass *response =
		lviWithMeetsAfterEnterResponse(selectorSelf);
	if (!response) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": @"detail-response-unavailable",
			@"archiveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.archivesId)
		});
#endif
		return;
	}
	bool responseHasExtra = false;
	bool responseHasAdmission = false;
	if (!lviWithMeetsAfterResponseHasAdmissionEvidence(
			response,
			responseHasExtra,
			responseHasAdmission
		)) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": @"detail-admission-fields-invalid",
			@"archiveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.archivesId)
		});
#endif
		return;
	}
	// The archive-list response is the entitlement source displayed by the
	// four stars in the list. The detail response uses a separate per-session
	// point counter, so it must not be treated as proof of list ownership.
	// Still require this exact detail response to contain a real AFTER chapter
	// and a longer total duration before correcting its false-negative flag.
#if LVI_WM_DIAGNOSTIC
	bool extendedDuration =
		lviWithMeetsAfterResponseHasExtendedDuration(response);
	bool hasExtraChapter =
		lviWithMeetsAfterResponseHasExtraChapter(response);
#endif
	if (!responseHasExtra
#if LVI_WM_DIAGNOSTIC
		|| !extendedDuration
		|| !hasExtraChapter
#else
		|| !lviWithMeetsAfterResponseHasExtendedDuration(response)
		|| !lviWithMeetsAfterResponseHasExtraChapter(response)
#endif
	) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": @"detail-safety-gate-failed",
			@"archiveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.archivesId),
			@"catalogHasExtra": @(entitlement.hasExtra),
			@"catalogHasExtraAdmission":
				@(entitlement.hasExtraAdmission),
			@"catalogEarnedStarCount":
				@(entitlement.earnedStarCount),
			@"catalogAdmissionThreshold":
				@(entitlement.admissionThreshold),
			@"detailHasExtra": @(responseHasExtra),
			@"detailHasExtraAdmission": @(responseHasAdmission),
			@"detailHasExtendedDuration": @(extendedDuration),
			@"detailHasExtraChapter": @(hasExtraChapter)
		});
#endif
		return;
	}
	if (responseHasAdmission) {
		// The server response is already correct. Preserve it and carry the
		// same exact, validated decision across the later GiftPointModel
		// construction boundary.
		bool playerScopeArmed =
			lviArmWithMeetsAfterPlayerAdmissionScope(
				entitlement,
				response
			);
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": @"already-admitted",
			@"archiveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.archivesId),
			@"detailHasExtra": @(responseHasExtra),
			@"detailHasExtraAdmission": @true,
			@"detailHasExtendedDuration": @(extendedDuration),
			@"detailHasExtraChapter": @(hasExtraChapter),
			@"playerScopeArmed": @(playerScopeArmed)
		});
#endif
		return;
	}
	// This exact detail response is scoped by the one-shot request transaction
	// to the same ArchivesId whose authoritative list row proved admission.
	if (!lviWriteExactInstanceField<bool>(
			response,
			"<HasExtraAdmission>k__BackingField",
			true
		) ||
		!lviReadExactInstanceField(
			response,
			"<HasExtraAdmission>k__BackingField",
			responseHasAdmission
		) ||
		!responseHasAdmission) {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-repair", @{
			@"outcome": @"admission-write-failed",
			@"archiveIdToken":
				lviAfterDiagnosticIdentifier(entitlement.archivesId),
			@"readbackAdmission": @(responseHasAdmission)
		});
#endif
		return;
	}
	bool playerScopeArmed =
		lviArmWithMeetsAfterPlayerAdmissionScope(
			entitlement,
			response
		);
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-repair", @{
		@"outcome": @"repaired",
		@"archiveIdToken":
			lviAfterDiagnosticIdentifier(entitlement.archivesId),
		@"catalogEarnedStarCount": @(entitlement.earnedStarCount),
		@"catalogAdmissionThreshold": @(entitlement.admissionThreshold),
		@"detailHasExtra": @(responseHasExtra),
		@"detailHasExtendedDuration": @(extendedDuration),
		@"detailHasExtraChapter": @(hasExtraChapter),
		@"readbackAdmission": @(responseHasAdmission),
		@"playerScopeArmed": @(playerScopeArmed)
	});
#endif
	NSLog(
		@"[LinkuraVisualsIOS][WithAfter] Corrected a false-negative "
		 "admission using exact catalog, request, and chapter evidence."
	);
}

static void (*original_SchoolConnectArchiveListViewModel_CreateArchiveList)(
	void *self,
	void *archiveResponse,
	void *thumbnailRepository,
	void *methodInfo
) = nullptr;

static void hooked_SchoolConnectArchiveListViewModel_CreateArchiveList(
	void *self,
	void *archiveResponse,
	void *thumbnailRepository,
	void *methodInfo
) {
	if (!original_SchoolConnectArchiveListViewModel_CreateArchiveList) {
		lviClearWithMeetsAfterEvidence();
		return;
	}
	original_SchoolConnectArchiveListViewModel_CreateArchiveList(
		self,
		archiveResponse,
		thumbnailRepository,
		methodInfo
	);
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-list-hook", @{
		@"operation": @"create",
		@"responseAvailable": @(archiveResponse != nullptr),
		@"repositoryAvailable": @(thumbnailRepository != nullptr)
	});
#endif
	lviBeginWithMeetsAfterCatalogGeneration();
	lviIngestWithMeetsAfterEvidence(archiveResponse);
}

static void (*original_SchoolConnectArchiveListViewModel_AddToArchiveList)(
	void *self,
	void *archiveResponse,
	void *thumbnailRepository,
	void *methodInfo
) = nullptr;

static void hooked_SchoolConnectArchiveListViewModel_AddToArchiveList(
	void *self,
	void *archiveResponse,
	void *thumbnailRepository,
	void *methodInfo
) {
	if (!original_SchoolConnectArchiveListViewModel_AddToArchiveList) {
		lviClearWithMeetsAfterEvidence();
		return;
	}
	original_SchoolConnectArchiveListViewModel_AddToArchiveList(
		self,
		archiveResponse,
		thumbnailRepository,
		methodInfo
	);
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-list-hook", @{
		@"operation": @"add",
		@"responseAvailable": @(archiveResponse != nullptr),
		@"repositoryAvailable": @(thumbnailRepository != nullptr)
	});
#endif
	lviIngestWithMeetsAfterEvidence(archiveResponse);
}

static Unity::System_String*
(*original_GetWithArchiveDataRequest_get_ArchivesId)(
	void *self,
	void *methodInfo
) = nullptr;

static void (*original_GetWithArchiveDataRequest_ctor)(
	void *self,
	Unity::System_String *archivesId,
	void *methodInfo
) = nullptr;

static void hooked_GetWithArchiveDataRequest_ctor(
	void *self,
	Unity::System_String *archivesId,
	void *methodInfo
) {
	if (!original_GetWithArchiveDataRequest_ctor) {
		lviClearPendingWithMeetsAfterRequest();
		return;
	}
	original_GetWithArchiveDataRequest_ctor(
		self,
		archivesId,
		methodInfo
	);
	// ApiRepository constructs this request directly for every archive
	// detail call. This is a deterministic confirmation point; the property
	// getter below remains only a harmless fallback for runtime variants.
	lviConfirmWithMeetsAfterRequest(archivesId);
}

static Unity::System_String*
hooked_GetWithArchiveDataRequest_get_ArchivesId(
	void *self,
	void *methodInfo
) {
	if (!original_GetWithArchiveDataRequest_get_ArchivesId) {
		lviClearPendingWithMeetsAfterRequest();
		return nullptr;
	}
	Unity::System_String *archivesId =
		original_GetWithArchiveDataRequest_get_ArchivesId(
			self,
			methodInfo
		);
	lviConfirmWithMeetsAfterRequest(archivesId);
	return archivesId;
}

static IL2CPP::CClass*
(*original_WithConnectModelsFactory_CreateOwnGiftPointModel)(
	void *self,
	void *methodInfo
) = nullptr;

static IL2CPP::CClass*
hooked_WithConnectModelsFactory_CreateOwnGiftPointModel(
	void *self,
	void *methodInfo
) {
	if (!original_WithConnectModelsFactory_CreateOwnGiftPointModel) {
		lviClearWithMeetsAfterPlayerAdmissionScope();
		return nullptr;
	}
	LVIWithMeetsAfterPlayerFactoryDecision factoryDecision =
		lviMatchWithMeetsAfterPlayerFactoryScope(self);
	uint64_t priorFactoryScopeGeneration =
		lviWithMeetsAfterPlayerFactoryScopeGeneration;
	lviWithMeetsAfterPlayerFactoryScopeGeneration =
		factoryDecision.matched
			? factoryDecision.scopeGeneration
			: 0;
	IL2CPP::CClass *result =
		original_WithConnectModelsFactory_CreateOwnGiftPointModel(
			self,
			methodInfo
		);
	lviWithMeetsAfterPlayerFactoryScopeGeneration =
		priorFactoryScopeGeneration;
	bool clearedUnusedScope =
		lviFinishWithMeetsAfterPlayerFactoryScope(
			factoryDecision.matched
				? factoryDecision.scopeGeneration
				: 0
		);
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-player-factory", @{
		@"matched": @(factoryDecision.matched),
		@"reason":
			[NSString stringWithUTF8String:factoryDecision.reason],
		@"scopeGeneration": @(factoryDecision.scopeGeneration),
		@"detailResponseIdentity": @(
			static_cast<unsigned long long>(
				factoryDecision.detailResponseIdentity
			)
		),
		@"resultAvailable": @(result != nullptr),
		@"clearedUnusedScope": @(clearedUnusedScope)
	});
#endif
	return result;
}

static void (*original_GiftPointModel_ctor)(
	void *self,
	int32_t currentGiftPoint,
	void *giftStarRewardSegments,
	int32_t extraAdmissionThreshold,
	bool hasExtraAdmissionWhenEnter,
	bool hasExtra,
	int32_t schoolEventType,
	void *methodInfo
) = nullptr;

static void hooked_GiftPointModel_ctor(
	void *self,
	int32_t currentGiftPoint,
	void *giftStarRewardSegments,
	int32_t extraAdmissionThreshold,
	bool hasExtraAdmissionWhenEnter,
	bool hasExtra,
	int32_t schoolEventType,
	void *methodInfo
) {
	if (!original_GiftPointModel_ctor) {
		lviClearPendingWithMeetsAfterRequest();
		return;
	}
	LVIWithMeetsAfterPlayerAdmissionDecision decision =
		lviConsumeWithMeetsAfterPlayerAdmissionScope(
			extraAdmissionThreshold,
			hasExtraAdmissionWhenEnter,
			hasExtra,
			lviWithMeetsAfterPlayerFactoryScopeGeneration
		);
	bool effectiveAdmission =
		hasExtraAdmissionWhenEnter ||
		(decision.matched && decision.shouldRepair);
	// Preserve every stock value—including points, reward segments, threshold,
	// AFTER availability, and event type. Only repair the constructor's
	// admission snapshot when the exact catalog/detail transaction proved it.
	original_GiftPointModel_ctor(
		self,
		currentGiftPoint,
		giftStarRewardSegments,
		extraAdmissionThreshold,
		effectiveAdmission,
		hasExtra,
		schoolEventType,
		methodInfo
	);
#if LVI_WM_DIAGNOSTIC
	lviWriteAfterDiagnostic(@"after-player-model", @{
		@"matched": @(decision.matched),
		@"repairApplied": @(
			decision.matched && decision.shouldRepair
		),
		@"reason": [NSString stringWithUTF8String:decision.reason],
		@"stockAdmission": @(hasExtraAdmissionWhenEnter),
		@"effectiveAdmission": @(effectiveAdmission),
		@"modelHasExtra": @(hasExtra),
		@"modelAdmissionThreshold": @(extraAdmissionThreshold),
		@"scopeGeneration": @(decision.scopeGeneration),
		@"archiveIdToken":
			lviAfterDiagnosticIdentifier(
				decision.entitlement.archivesId
			)
	});
#endif
	if (effectiveAdmission != hasExtraAdmissionWhenEnter) {
		NSLog(
			@"[LinkuraVisualsIOS][WithAfter] Restored the validated "
			 "admission snapshot at player-model construction."
		);
	}
}

#if LVI_WM_DIAGNOSTIC
static void (*original_LiveConnectChapterModel_SetExtraAdmission)(
	void *self,
	bool hasExtraAdmission,
	void *methodInfo
) = nullptr;

static void hooked_LiveConnectChapterModel_SetExtraAdmission(
	void *self,
	bool hasExtraAdmission,
	void *methodInfo
) {
	bool selfExactClass = lviManagedObjectIsExactClass(
		reinterpret_cast<IL2CPP::CClass*>(self),
		"School.LiveMain",
		"LiveConnectChapterModel"
	);
	bool playerScopeActive = false;
	bool playerScopeEntitlementPresent = false;
	uint64_t playerScopeGeneration = 0;
	uint64_t playerScopeCatalogGeneration = 0;
	std::string playerScopeArchiveId;
	bool confirmedRequestActive = false;
	bool confirmedEntitlementPresent = false;
	uint64_t confirmedRequestGeneration = 0;
	uint64_t confirmedCatalogGeneration = 0;
	std::string confirmedArchiveId;
	bool sameEntitlement = false;
	{
		std::lock_guard<std::mutex> lock(
			lviWithMeetsAfterEvidenceMutex
		);
		const LVIWithMeetsAfterPlayerAdmissionScope& playerScope =
			lviWithMeetsAfterPlayerAdmissionScope;
		playerScopeActive = playerScope.active;
		playerScopeGeneration = playerScope.scopeGeneration;
		playerScopeCatalogGeneration = playerScope.catalogGeneration;
		playerScopeArchiveId =
			playerScope.entitlement.archivesId;
		playerScopeEntitlementPresent =
			playerScope.active &&
			playerScope.entitlement.derivedEligible &&
			!playerScope.entitlement.archivesId.empty() &&
			!playerScope.entitlement.liveId.empty();

		confirmedRequestActive = lviConfirmedAfterRequestActive;
		confirmedRequestGeneration =
			lviConfirmedAfterRequestGeneration;
		confirmedCatalogGeneration =
			lviConfirmedAfterEntitlement.catalogGeneration;
		confirmedArchiveId =
			lviConfirmedAfterEntitlement.archivesId;
		confirmedEntitlementPresent =
			lviConfirmedAfterRequestActive &&
			lviConfirmedAfterEntitlement.derivedEligible &&
			!lviConfirmedAfterEntitlement.archivesId.empty() &&
			!lviConfirmedAfterEntitlement.liveId.empty();
		sameEntitlement =
			playerScopeEntitlementPresent &&
			confirmedEntitlementPresent &&
			playerScope.entitlement.archivesId ==
				lviConfirmedAfterEntitlement.archivesId &&
			playerScope.entitlement.liveId ==
				lviConfirmedAfterEntitlement.liveId;
	}

	bool originalInvoked =
		original_LiveConnectChapterModel_SetExtraAdmission != nullptr;
	if (originalInvoked) {
		// Diagnostic-only observation point: preserve the stock argument
		// exactly. This hook must not grant or revoke admission.
		original_LiveConnectChapterModel_SetExtraAdmission(
			self,
			hasExtraAdmission,
			methodInfo
		);
	}
	lviWriteAfterDiagnostic(@"after-player-chapter-admission", @{
		@"stockAdmissionArgument": @(hasExtraAdmission),
		@"argumentForwardedUnchanged": @(originalInvoked),
		@"originalInvoked": @(originalInvoked),
		@"selfAvailable": @(self != nullptr),
		@"selfExactClass": @(selfExactClass),
		@"playerFactoryScopeGeneration": @(
			lviWithMeetsAfterPlayerFactoryScopeGeneration
		),
		@"playerScopeActive": @(playerScopeActive),
		@"playerScopeEntitlementPresent":
			@(playerScopeEntitlementPresent),
		@"playerScopeGeneration": @(playerScopeGeneration),
		@"playerScopeCatalogGeneration":
			@(playerScopeCatalogGeneration),
		@"playerScopeArchiveIdToken":
			lviAfterDiagnosticIdentifier(playerScopeArchiveId),
		@"confirmedRequestActive": @(confirmedRequestActive),
		@"confirmedEntitlementPresent":
			@(confirmedEntitlementPresent),
		@"confirmedRequestGeneration":
			@(confirmedRequestGeneration),
		@"confirmedCatalogGeneration":
			@(confirmedCatalogGeneration),
		@"confirmedArchiveIdToken":
			lviAfterDiagnosticIdentifier(confirmedArchiveId),
		@"sameEntitlement": @(sameEntitlement)
	});
}
#endif

static int32_t (*original_LiveArchiveItemModel_GetAfterType)(
	void *self,
	bool hasExtraLive,
	bool hasExtraAdmission,
	void *methodInfo
) = nullptr;

static int32_t hooked_LiveArchiveItemModel_GetAfterType(
	void *self,
	bool hasExtraLive,
	bool hasExtraAdmission,
	void *methodInfo
) {
	if (!original_LiveArchiveItemModel_GetAfterType) {
		lviClearPendingWithMeetsAfterRequest();
		return 0;
	}
	LVIWithMeetsAfterEntitlement entitlement;
	bool repairAdmission =
		!hasExtraAdmission &&
		hasExtraLive &&
		lviResolvePositiveWithMeetsAfterEntitlement(
			reinterpret_cast<IL2CPP::CClass*>(self),
			entitlement
		);
	return original_LiveArchiveItemModel_GetAfterType(
		self,
		hasExtraLive,
		hasExtraAdmission || repairAdmission,
		methodInfo
	);
}

static void (*original_SchoolConnectArchiveListView_EnterToLiveScene)(
	void *archiveItemModel,
	void *methodInfo
) = nullptr;

static void hooked_SchoolConnectArchiveListView_EnterToLiveScene(
	void *archiveItemModel,
	void *methodInfo
) {
	if (!original_SchoolConnectArchiveListView_EnterToLiveScene) {
		lviClearPendingWithMeetsAfterRequest();
		return;
	}
	lviClearPendingWithMeetsAfterRequest();
	LVIWithMeetsAfterEntitlement entitlement;
	if (lviResolvePositiveWithMeetsAfterEntitlement(
			reinterpret_cast<IL2CPP::CClass*>(archiveItemModel),
			entitlement
		)) {
		std::lock_guard<std::mutex> lock(lviWithMeetsAfterEvidenceMutex);
		lviPendingAfterRequestActive = true;
		lviPendingAfterEntitlement = entitlement;
		lviPendingAfterDeadline = CFAbsoluteTimeGetCurrent() + 30.0;
	}
	original_SchoolConnectArchiveListView_EnterToLiveScene(
		archiveItemModel,
		methodInfo
	);
}

static void lviOpenWithArchiveOrientationScope(void *selectorSelf) {
	if (!lviWithArchiveLifecycleTrackingNeeded()) {
		return;
	}
	IL2CPP::CClass *response =
		lviWithArchiveEnterResponse(selectorSelf);
	if (!response) {
		return;
	}

	// IsHorizontal comes from the authoritative With×MEETS archive enter
	// response. Read it before the stock content selector can choose either
	// the HLS player or the ALST/IARC player.
	bool isHorizontal = response->GetMemberValue<bool>("IsHorizontal");
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	lviWithArchiveIsHorizontal.store(
		isHorizontal,
		std::memory_order_release
	);
	lviWithArchiveOrientationPending.store(
		true,
		std::memory_order_release
	);
	lviWithArchiveOrientationSessionActive.store(
		false,
		std::memory_order_release
	);
	lviWithArchiveOrientationDeadline.store(
		now + 30.0,
		std::memory_order_release
	);
	lviWithArchiveRebindDeadline.store(0, std::memory_order_release);
	lviWithArchiveOrientationModelsOwner = nullptr;
	NSLog(
		@"[LinkuraVisualsIOS][WithArchiveOrientation] Scope opened "
		 "(horizontal=%d).",
		isHorizontal
	);
}

static void lviCancelWithArchivePendingLifecycleScope() {
	// The selector can return without entering either WM archive player (for
	// example after a cancelled/failed request). In that case no
	// LiveSystemModels owner will arrive to close the pending cover/orientation
	// scope, so close only the still-pending, ownerless scope immediately.
	if (lviWithArchiveOrientationModelsOwner ||
		lviWithArchiveOrientationSessionActive.load(
			std::memory_order_acquire
		)) {
		return;
	}
	lviWithArchiveOrientationPending.store(
		false,
		std::memory_order_release
	);
	lviWithArchiveOrientationDeadline.store(0, std::memory_order_release);
	lviWithArchiveRebindDeadline.store(0, std::memory_order_release);
	NSLog(
		@"[LinkuraVisualsIOS][WithArchiveOrientation] Pending scope "
		 "cancelled before player entry."
	);
}

static void lviActivateWithArchiveOrientationSession(
	void *models,
	const char *source
) {
	if (!lviWithArchiveLifecycleTrackingNeeded() || !models) {
		return;
	}
	lviWithArchiveOrientationModelsOwner = models;
	lviWithArchiveOrientationPending.store(
		false,
		std::memory_order_release
	);
	lviWithArchiveOrientationDeadline.store(0, std::memory_order_release);
	lviWithArchiveRebindDeadline.store(0, std::memory_order_release);
	lviWithArchiveOrientationSessionActive.store(
		true,
		std::memory_order_release
	);
	NSLog(
		@"[LinkuraVisualsIOS][WithArchiveOrientation] Session active via %s "
		 "(horizontal=%d).",
		source ?: "unknown",
		lviWithArchiveIsHorizontal.load(std::memory_order_acquire)
	);
}

static bool lviBeginWithArchiveOrientationRelease(void *models) {
	if (!lviWithArchiveLifecycleTrackingNeeded() ||
		!models ||
		models != lviWithArchiveOrientationModelsOwner) {
		return false;
	}
	lviWithArchiveOrientationModelsOwner = nullptr;
	lviWithArchiveOrientationPending.store(
		false,
		std::memory_order_release
	);
	lviWithArchiveOrientationDeadline.store(0, std::memory_order_release);
	lviWithArchiveOrientationSessionActive.store(
		false,
		std::memory_order_release
	);
	// Keep stock orientation calls inside Dispose available. The deadline is
	// cleared immediately after Dispose unless a replacement WM archive model
	// was registered re-entrantly, so it cannot leak into home or Fes.
	lviWithArchiveRebindDeadline.store(
		CFAbsoluteTimeGetCurrent() +
			lviWithArchiveRebindGraceSeconds(),
		std::memory_order_release
	);
	return true;
}

static void lviFinishWithArchiveOrientationRelease() {
	bool replacementRegistered =
		lviWithArchiveOrientationModelsOwner != nullptr;
	lviWithArchiveRebindDeadline.store(0, std::memory_order_release);
	lviWithArchiveOrientationPending.store(
		false,
		std::memory_order_release
	);
	lviWithArchiveOrientationDeadline.store(0, std::memory_order_release);
	lviWithArchiveOrientationSessionActive.store(
		replacementRegistered,
		std::memory_order_release
	);
	if (!replacementRegistered) {
		NSLog(
			@"[LinkuraVisualsIOS][WithArchiveOrientation] Scope closed."
		);
	}
}

static bool lviCameraSceneEnabled(LVICameraScene scene) {
	if (scene == LVICameraScene::ActivityRecord) {
		return configBool(@"ActivityRecord.CameraControl.Enable");
	}
	if (scene == LVICameraScene::WithMeets) {
		return configBool(@"WithMeets.CameraControl.Enable");
	}
	if (scene == LVICameraScene::FesArchive) {
		return configBool(@"FesArchive.CameraControl.Enable");
	}
	return false;
}

static bool lviCameraBaseFunctionsReady() {
	return lviComponentGetTransform &&
		lviTransformGetPosition &&
		lviTransformSetPosition &&
		lviTransformGetRotation &&
		lviTransformSetRotation &&
		lviCameraGetFieldOfView &&
		lviCameraSetFieldOfView;
}

static bool lviCameraOrthographicFunctionsReady() {
	return
		lviCameraGetOrthographicSize &&
		lviCameraSetOrthographicSize &&
		lviCameraGetOrthographic;
}

static bool lviReadCurrentCameraPose(LVICameraRuntime& runtime) {
	if (!runtime.camera || !lviCameraBaseFunctionsReady()) {
		return false;
	}
	Unity::CTransform *transform =
		lviComponentGetTransform(runtime.camera, nullptr);
	if (!transform) {
		return false;
	}
	runtime.transform = transform;
	lviTransformGetPosition(transform, &runtime.position, nullptr);
	lviTransformGetRotation(transform, &runtime.rotation, nullptr);
	runtime.orthographic =
		lviCameraOrthographicFunctionsReady() &&
		lviCameraGetOrthographic(runtime.camera, nullptr);
	runtime.zoomValue = runtime.orthographic
		? lviCameraGetOrthographicSize(runtime.camera, nullptr)
		: lviCameraGetFieldOfView(runtime.camera, nullptr);
	return std::isfinite(runtime.zoomValue);
}

static void lviApplyCameraPose(const LVICameraRuntime& runtime) {
	if (!runtime.camera || !runtime.transform ||
		!lviCameraBaseFunctionsReady()) {
		return;
	}
	Unity::Vector3 position = runtime.position;
	Unity::Quaternion rotation = runtime.rotation;
	lviTransformSetPosition(runtime.transform, &position, nullptr);
	lviTransformSetRotation(runtime.transform, &rotation, nullptr);
	if (runtime.orthographic && lviCameraOrthographicFunctionsReady()) {
		lviCameraSetOrthographicSize(
			runtime.camera,
			runtime.zoomValue,
			nullptr
		);
	} else {
		lviCameraSetFieldOfView(
			runtime.camera,
			runtime.zoomValue,
			nullptr
		);
	}
}

static void lviPublishCurrentCameraState() {
	Unity::Vector3 euler =
		Unity::Quaternion::ToEuler(lviCameraRuntime.rotation);
	float pitchDegrees =
		euler.X * static_cast<float>(180.0 / M_PI);
	publishLVICameraPanel(
		lviCameraRuntime.scene,
		lviCameraRuntime.freeMode,
		lviCameraRuntime.orthographic,
		lviCameraRuntime.zoomValue,
		pitchDegrees,
		lviCameraRuntime.lastCommand
	);
}

static void lviClearCameraTarget(
	LVICameraScene expectedScene,
	void *expectedOwner
) {
	if (lviCameraRuntime.scene != expectedScene ||
		(expectedOwner && lviCameraRuntime.owner != expectedOwner)) {
		return;
	}
	uint64_t nextGeneration = lviCameraRuntime.generation + 1;
	lviCameraRuntime = LVICameraRuntime {};
	lviCameraRuntime.generation = nextGeneration;
	lviPublishedCameraGeneration.store(
		nextGeneration,
		std::memory_order_release
	);
	lviResetJoystickInput();
	lviResetHeldCameraInput();
	lviJoystickHeightMode.store(false, std::memory_order_release);
	lviJoystickLastFrameTime = 0;
	lviJoystickLastPublishTime = 0;
	publishLVICameraPanel(
		LVICameraScene::None,
		false,
		false,
		0.0f,
		0.0f,
		LVICameraCommandType::None
	);
}

static bool lviRegisterCameraTarget(
	LVICameraScene scene,
	void *owner,
	Unity::CCamera *camera
) {
	if (!lviCameraSceneEnabled(scene) || !camera ||
		!lviCameraBaseFunctionsReady()) {
		return false;
	}
	if (lviCameraRuntime.scene == scene &&
		lviCameraRuntime.owner == owner &&
		lviCameraRuntime.camera == camera) {
		return true;
	}

	uint64_t nextGeneration = lviCameraRuntime.generation + 1;
	LVICameraRuntime next {};
	next.scene = scene;
	next.owner = owner;
	next.camera = camera;
	next.generation = nextGeneration;
	if (!lviReadCurrentCameraPose(next)) {
		NSLog(@"[LinkuraVisualsIOS][Camera] Failed to read target camera.");
		return false;
	}
	next.originalPosition = next.position;
	next.originalRotation = next.rotation;
	next.originalZoomValue = next.zoomValue;
	lviCameraRuntime = next;
	lviPublishedCameraGeneration.store(
		nextGeneration,
		std::memory_order_release
	);
	lviResetJoystickInput();
	lviResetHeldCameraInput();
	lviJoystickHeightMode.store(false, std::memory_order_release);
	lviJoystickLastFrameTime = 0;
	lviJoystickLastPublishTime = 0;
	NSLog(
		@"[LinkuraVisualsIOS][Camera] Registered %@ camera.",
		scene == LVICameraScene::ActivityRecord
			? @"Activity Record"
			: (scene == LVICameraScene::WithMeets
				? @"With×MEETS"
				: @"Fes Archive")
	);
	lviPublishCurrentCameraState();
	return true;
}

static void lviResetWithArchiveCameraAdapter() {
	// The active camera can be published by either DynamicCamera or
	// AlphaBlendCamera depending on when the archive scene finishes
	// initializing.  Clear the With×MEETS runtime without requiring an owner
	// match so neither UIWindow-level overlay can survive after the archive
	// camera is disposed.  This is the earliest reliable IARC exit boundary;
	// LiveSystemModels.Dispose remains a final fallback for non-camera paths.
	lviClearWithArchivePlayPause();
	lviClearCameraTarget(LVICameraScene::WithMeets, nullptr);
	// lviClearCameraTarget intentionally ignores a mismatched/empty runtime.
	// Hide the overlay unconditionally at the archive lifetime boundary as a
	// final guard against a stale UIKit panel.
	publishLVICameraPanel(
		LVICameraScene::None,
		false,
		false,
		0.0f,
		0.0f,
		LVICameraCommandType::None
	);
	lviWithDynamicCameraOwner = nullptr;
	lviWithArchiveModelsOwner = nullptr;
	lviWithArchiveBlendCameraOwner = nullptr;
	lviWithArchiveIarcActive = false;
}

struct LVIWithArchiveContentSelection {
	int32_t enterResult;
	int32_t contentType;
};

static_assert(
	sizeof(LVIWithArchiveContentSelection) == sizeof(uint64_t),
	"With archive selector result must stay register-sized."
);

static LVIWithArchiveContentSelection
(*original_WithArchiveContentTypeSelector_Execute)(
	void *self,
	void *methodInfo
) = nullptr;

static bool lviIsMotionCaptureArchiveUrl(
	Unity::System_String *archiveUrl
) {
	if (!archiveUrl || archiveUrl->ToLength() <= 0) {
		return false;
	}

	NSString *value = archiveUrl->ToNSString();
	if (value.length == 0) {
		return false;
	}

	NSUInteger separator = [value rangeOfCharacterFromSet:
		[NSCharacterSet characterSetWithCharactersInString:@"?#"]
	].location;
	NSString *path = separator == NSNotFound
		? value
		: [value substringToIndex:separator];
	return [[path lowercaseString] hasSuffix:@".md"];
}

static NSString* lviCanonicalArchiveNSString(NSString *value) {
	if (value.length == 0) {
		return nil;
	}

	NSURLComponents *components =
		[NSURLComponents componentsWithString:value];
	if (!components) {
		return value;
	}
	components.query = nil;
	components.fragment = nil;
	return components.string ?: value;
}

static NSString* lviCanonicalArchiveURL(
	Unity::System_String *url
) {
	if (!url || url->ToLength() <= 0) {
		return nil;
	}

	return lviCanonicalArchiveNSString(url->ToNSString());
}

static bool lviIsMotionCaptureArchiveNSString(NSString *url) {
	if (url.length == 0) {
		return false;
	}
	NSUInteger separator = [url rangeOfCharacterFromSet:
		[NSCharacterSet characterSetWithCharactersInString:@"?#"]
	].location;
	NSString *path = separator == NSNotFound
		? url
		: [url substringToIndex:separator];
	return [[path lowercaseString] hasSuffix:@".md"];
}

/*
 * The iOS local API currently returns an HLS-only response for some
 * With×MEETS archives even though the Android local database contains the
 * matching ALST/IARC motion archive.  Those paths contain independent UUID
 * and content-hash components, so they cannot be safely derived from the HLS
 * date alone.  Keep a narrowly verified built-in repair and allow future
 * mappings to be supplied through the existing JSON without changing code.
 */
static NSString* lviMappedMotionArchiveURL(
	Unity::System_String *videoUrl,
	NSString **mappingSource
) {
	NSString *canonicalVideoURL = lviCanonicalArchiveURL(videoUrl);
	if (canonicalVideoURL.length == 0) {
		return nil;
	}

	NSString *mappedURL = nil;
	id configured =
		qualityConfig[@"WithMeets.Archive.MotionCaptureReplay.UrlMap"];
	if ([configured isKindOfClass:[NSDictionary class]]) {
		id candidate = ((NSDictionary *)configured)[canonicalVideoURL];
		if ([candidate isKindOfClass:[NSString class]]) {
			mappedURL = (NSString *)candidate;
			if (mappingSource) {
				*mappingSource = @"config";
			}
		} else if ([candidate isKindOfClass:[NSDictionary class]]) {
			NSDictionary *candidateMap = (NSDictionary *)candidate;
			// Keep backward compatibility with the Android local database
			// vocabulary while still accepting the iOS response name.
			NSArray<NSString*> *keys = @[
				@"ArchiveUrl",
				@"archive_url",
				@"external_fix_link",
				@"external_link"
			];
			for (NSString *key in keys) {
				id value = candidateMap[key];
				if ([value isKindOfClass:[NSString class]] &&
					lviIsMotionCaptureArchiveNSString(value)) {
					mappedURL = (NSString *)value;
					if (mappingSource) {
						*mappingSource = @"config-object";
					}
					break;
				}
			}
		}
	}

	if (!mappedURL) {
		for (unsigned long index = 0;
			index < kLVIWithArchiveCatalogCount;
			index++) {
			const LVIWithArchiveCatalogEntry& entry =
				kLVIWithArchiveCatalog[index];
			NSString *hlsURL =
				[NSString stringWithUTF8String:entry.hlsUrl];
			if (![canonicalVideoURL isEqualToString:hlsURL]) {
				continue;
			}
			mappedURL = [NSString stringWithUTF8String:entry.archiveUrl];
			if (mappingSource) {
				*mappingSource = @"built-in-catalog";
			}
			break;
		}
	}

	return lviIsMotionCaptureArchiveNSString(mappedURL)
		? mappedURL
		: nil;
}

#if LVI_WM_DIAGNOSTIC
static dispatch_queue_t lviWMDiagnosticQueue() {
	static dispatch_queue_t queue;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		queue = dispatch_queue_create(
			"jp.linkuravisuals.wm-diagnostic",
			DISPATCH_QUEUE_SERIAL
		);
	});
	return queue;
}

static NSString* lviWMDiagnosticPath() {
	return [getDylibDirectoryPath() stringByAppendingPathComponent:
		@"LinkuraVisualsIOS-WM-Diagnostic.jsonl"
	];
}

static void lviWriteWMDiagnostic(
	NSDictionary *entry,
	bool resetFile
) {
	NSDictionary *snapshot = [entry copy];
	dispatch_async(lviWMDiagnosticQueue(), ^{
		NSMutableDictionary *record = [snapshot mutableCopy];
		record[@"timestamp"] = @(
			[[NSDate date] timeIntervalSince1970]
		);
		NSError *error = nil;
		NSData *json = [NSJSONSerialization dataWithJSONObject:record
			options:0
			error:&error];
		if (!json || error) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] Diagnostic JSON error: %@",
				error
			);
			return;
		}
		NSMutableData *line = [json mutableCopy];
		[line appendData:[@"\n" dataUsingEncoding:NSUTF8StringEncoding]];
		NSString *path = lviWMDiagnosticPath();
		if (resetFile) {
			if (![line writeToFile:path options:NSDataWritingAtomic
				error:&error]) {
				NSLog(
					@"[LinkuraVisualsIOS][WithArchive] Diagnostic reset "
					 "failed: %@",
					error
				);
			}
			return;
		}
		NSFileHandle *handle = [NSFileHandle
			fileHandleForWritingAtPath:path];
		if (!handle) {
			if (![line writeToFile:path options:NSDataWritingAtomic
				error:&error]) {
				NSLog(
					@"[LinkuraVisualsIOS][WithArchive] Diagnostic write "
					 "failed: %@",
					error
				);
			}
			return;
		}
		@try {
			[handle seekToEndOfFile];
			[handle writeData:line];
			[handle closeFile];
		} @catch (NSException *exception) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] Diagnostic append "
				 "failed: %@",
				exception
			);
		}
	});
}

static NSString* lviDiagnosticURL(Unity::System_String *url) {
	if (!url || url->ToLength() <= 0) {
		return @"<empty>";
	}
	NSString *value = url->ToNSString();
	NSURLComponents *components =
		[NSURLComponents componentsWithString:value];
	if (!components) {
		return value.length > 300
			? [[value substringToIndex:300] stringByAppendingString:@"…"]
			: value;
	}
	components.query = nil;
	components.fragment = nil;
	components.user = nil;
	components.password = nil;
	NSString *sanitized = components.string ?: value;
	return sanitized.length > 300
		? [[sanitized substringToIndex:300] stringByAppendingString:@"…"]
		: sanitized;
}
#endif

static void lviClearManagedList(IL2CPP::CClass *list) {
	if (!list) {
		return;
	}
	void *clear = list->GetMethodPointer("Clear", 0);
	if (clear) {
		list->CallMethodSafe<void>(clear);
	}
}

/*
 * A With×MEETS archive response can contain both ArchiveUrl (ALST/IARC) and
 * VideoUrl (HLS/USM).  The stock iOS selector always prefers VideoUrl, so
 * even an archive that has valid motion-capture data enters the fixed 2D
 * player.  Android localify selects motion replay by removing VideoUrl.
 *
 * Keep the stock selector and loader intact: only responses whose ArchiveUrl
 * is an actual .md motion archive are changed.  HLS-only archives retain the
 * original route.  Clearing the two video-timeline lists mirrors the Android
 * motion-replay adapter and avoids carrying fixed-video metadata into IARC.
 */
static bool lviPrepareWithMeetsMotionArchive(void *selectorSelf) {
	if (!configBool(@"WithMeets.Archive.MotionCaptureReplay.Enable") ||
		!selectorSelf) {
#if LVI_WM_DIAGNOSTIC
		lviWriteWMDiagnostic(@{
			@"stage": @"selector-precondition",
			@"motionReplayEnabled": @(
				configBool(@"WithMeets.Archive.MotionCaptureReplay.Enable")
			),
			@"selectorAvailable": @(selectorSelf != nullptr)
		});
#endif
		return false;
	}

	IL2CPP::CClass *response =
		lviWithArchiveEnterResponse(selectorSelf);
	if (!response) {
		NSLog(
			@"[LinkuraVisualsIOS][WithArchive] Enter response is unavailable; "
			 "keeping the stock archive route."
		);
#if LVI_WM_DIAGNOSTIC
		lviWriteWMDiagnostic(@{
			@"stage": @"selector-input",
			@"responseAvailable": @false,
			@"decision": @"stock"
		});
#endif
		return false;
	}

	Unity::System_String *archiveUrl =
		response->GetMemberValue<Unity::System_String*>("ArchiveUrl");
	Unity::System_String *videoUrl =
		response->GetMemberValue<Unity::System_String*>("VideoUrl");
#if LVI_WM_DIAGNOSTIC
	lviWriteWMDiagnostic(@{
		@"stage": @"selector-input",
		@"responseAvailable": @true,
		@"archiveUrl": lviDiagnosticURL(archiveUrl),
		@"videoUrl": lviDiagnosticURL(videoUrl),
		@"archiveIsMd": @(lviIsMotionCaptureArchiveUrl(archiveUrl)),
		@"videoPresent": @(
			videoUrl && videoUrl->ToLength() > 0
		)
	});
#endif
	bool repairedArchiveURL = false;
	NSString *mappingSource = nil;
	if (!lviIsMotionCaptureArchiveUrl(archiveUrl)) {
		NSString *mappedURL =
			lviMappedMotionArchiveURL(videoUrl, &mappingSource);
		if (mappedURL) {
			Unity::System_String *managedMappedURL =
				IL2CPP::String::New([mappedURL UTF8String]);
			if (managedMappedURL) {
				response->SetMemberValue<Unity::System_String*>(
					"ArchiveUrl",
					managedMappedURL
				);
				Unity::System_String *storedArchiveURL =
					response->GetMemberValue<Unity::System_String*>(
						"ArchiveUrl"
					);
				if (lviIsMotionCaptureArchiveUrl(storedArchiveURL)) {
					archiveUrl = storedArchiveURL;
					repairedArchiveURL = true;
					NSLog(
						@"[LinkuraVisualsIOS][WithArchive] Repaired "
						 "missing ALST/IARC URL from %@ mapping.",
						mappingSource
					);
#if LVI_WM_DIAGNOSTIC
					lviWriteWMDiagnostic(@{
						@"stage": @"archive-url-repair",
						@"repaired": @true,
						@"source": mappingSource ?: @"unknown",
						@"archiveUrl": lviDiagnosticURL(archiveUrl)
					});
#endif
				} else {
					NSLog(
						@"[LinkuraVisualsIOS][WithArchive] ArchiveUrl "
						 "repair did not persist; keeping the stock route."
					);
				}
			}
		}
	}
	if (!lviIsMotionCaptureArchiveUrl(archiveUrl)) {
		NSLog(
			@"[LinkuraVisualsIOS][WithArchive] No compatible .md motion "
			 "archive; keeping HLS/USM playback."
		);
#if LVI_WM_DIAGNOSTIC
		lviWriteWMDiagnostic(@{
			@"stage": @"prepare-result",
			@"prepared": @false,
			@"decision": @"stock-fixed-video"
		});
#endif
		return false;
	}

	if (videoUrl && videoUrl->ToLength() > 0) {
		response->SetMemberValue<Unity::System_String*>("VideoUrl", nullptr);
	}
	lviClearManagedList(
		response->GetMemberValue<IL2CPP::CClass*>("Timelines")
	);
	lviClearManagedList(
		response->GetMemberValue<IL2CPP::CClass*>("GiftPtRankings")
	);
	NSLog(
		@"[LinkuraVisualsIOS][WithArchive] Selected ALST/IARC motion replay."
	);
#if LVI_WM_DIAGNOSTIC
	lviWriteWMDiagnostic(@{
		@"stage": @"prepare-result",
		@"prepared": @true,
		@"decision": @"alst-iarc",
		@"archiveUrlRepaired": @(repairedArchiveURL),
		@"videoUrlAfter": @"<null>"
	});
#endif
	return true;
}

static LVIWithArchiveContentSelection
hooked_WithArchiveContentTypeSelector_Execute(
	void *self,
	void *methodInfo
) {
	if (!original_WithArchiveContentTypeSelector_Execute) {
		lviClearPendingWithMeetsAfterRequest();
		return {};
	}
	lviRepairLegitimateWithMeetsAfter(self);
	lviOpenWithArchiveOrientationScope(self);
	bool prepared = lviPrepareWithMeetsMotionArchive(self);
	LVIWithArchiveContentSelection result =
		original_WithArchiveContentTypeSelector_Execute(self, methodInfo);
	bool entersArchivePlayer =
		result.enterResult == 2 &&
		(result.contentType == 4 || result.contentType == 5);
	if (!entersArchivePlayer) {
		lviCancelWithArchivePendingLifecycleScope();
	}
	if (prepared) {
		NSLog(
			@"[LinkuraVisualsIOS][WithArchive] Selector result=%d, "
			 "contentType=%d.",
			result.enterResult,
			result.contentType
		);
	}
#if LVI_WM_DIAGNOSTIC
	lviWriteWMDiagnostic(@{
		@"stage": @"selector-result",
		@"prepared": @(prepared),
		@"enterResult": @(result.enterResult),
		@"contentType": @(result.contentType)
	});
#endif
	return result;
}

static void (*original_CoverImageCommandReceiver_Awake)(
	void *self,
	void *methodInfo
) = nullptr;

static void hooked_CoverImageCommandReceiver_Awake(
	void *self,
	void *methodInfo
) {
	/*
	 * Android's removeRenderImageCover option prevents the receiver from
	 * subscribing while a With×MEETS cover is being prepared. Keep that
	 * behavior inside the exact WM archive lifecycle; Core.dll's receiver is
	 * shared and must remain stock in Activity Record, Fes, and home scenes.
	 */
	if (lviWithArchiveRenderImageCoverSuppressionActive()) {
		NSLog(
			@"[LinkuraVisualsIOS][WithArchiveCover] Skipped cover "
			 "receiver initialization."
		);
		return;
	}
	if (original_CoverImageCommandReceiver_Awake) {
		original_CoverImageCommandReceiver_Awake(self, methodInfo);
	}
}

static void (*original_AppsCoverScreen_SetActiveCoverImage)(
	void *self,
	bool active,
	void *methodInfo
) = nullptr;

static void hooked_AppsCoverScreen_SetActiveCoverImage(
	void *self,
	bool active,
	void *methodInfo
) {
	/*
	 * Preserve the stock screen object and all playback/timeline state. Only
	 * replace a request to show the MRS cover with false while the same WM
	 * archive lifecycle is active. A false request remains false.
	 */
	bool suppress = lviWithArchiveRenderImageCoverSuppressionActive();
	if (suppress && active) {
		NSLog(
			@"[LinkuraVisualsIOS][WithArchiveCover] Suppressed render "
			 "image cover."
		);
	}
	if (original_AppsCoverScreen_SetActiveCoverImage) {
		original_AppsCoverScreen_SetActiveCoverImage(
			self,
			active && !suppress,
			methodInfo
		);
	}
}

static float lviClamp(float value, float minimum, float maximum) {
	return MIN(MAX(value, minimum), maximum);
}

static void lviCameraHorizontalAxes(
	const Unity::Quaternion& rotation,
	Unity::Vector3& right,
	Unity::Vector3& forward
) {
	Unity::Vector3 euler = Unity::Quaternion::ToEuler(rotation);
	Unity::Quaternion yawRotation = Unity::Quaternion::FromEuler(
		Unity::Vector3(0.0f, euler.Y, 0.0f)
	);
	right = yawRotation * Unity::Vector3::Right();
	forward = yawRotation * Unity::Vector3::Forward();
}

static void lviProcessCameraCommands() {
	std::deque<LVICameraCommand> commands;
	{
		std::lock_guard<std::mutex> guard(lviCameraCommandMutex);
		commands.swap(lviCameraCommands);
	}
	if (commands.empty() ||
		lviCameraRuntime.scene == LVICameraScene::None) {
		return;
	}

	float movementStep =
		MAX(0.001f, lviConfigFloat(@"CameraControl.MoveStep", 0.15f));
	float rotationStepDegrees =
		MAX(0.1f, lviConfigFloat(@"CameraControl.RotateStepDegrees", 3.0f));
	float rotationStep = rotationStepDegrees * static_cast<float>(M_PI / 180.0);
	float zoomStep = lviCameraRuntime.orthographic
		? lviConfigFloat(@"CameraControl.OrthographicZoomStep", 0.5f)
		: lviConfigFloat(@"CameraControl.PerspectiveZoomStep", 2.0f);
	zoomStep = MAX(0.01f, zoomStep);
	float zoomMinimum = lviCameraRuntime.orthographic
		? lviConfigFloat(@"CameraControl.OrthographicZoomMinimum", 0.5f)
		: lviConfigFloat(@"CameraControl.PerspectiveZoomMinimum", 10.0f);
	zoomMinimum = MAX(0.01f, zoomMinimum);
	float zoomMaximum =
		lviCameraRuntime.orthographic
		? lviConfigFloat(@"CameraControl.OrthographicZoomMaximum", 30.0f)
		: lviConfigFloat(@"CameraControl.PerspectiveZoomMaximum", 100.0f);
	zoomMaximum = MAX(zoomMinimum, zoomMaximum);

	bool stateChanged = false;
	for (const LVICameraCommand& command : commands) {
		if (command.generation != lviCameraRuntime.generation) {
			continue;
		}
		if (command.type == LVICameraCommandType::ToggleMode) {
			if (!lviCameraRuntime.freeMode) {
				if (!lviReadCurrentCameraPose(lviCameraRuntime)) {
					continue;
				}
				lviCameraRuntime.originalPosition = lviCameraRuntime.position;
				lviCameraRuntime.originalRotation = lviCameraRuntime.rotation;
				lviCameraRuntime.originalZoomValue = lviCameraRuntime.zoomValue;
				lviCameraRuntime.freeMode = true;
			} else {
				lviCameraRuntime.freeMode = false;
				lviResetJoystickInput();
				lviResetHeldCameraInput();
				lviJoystickLastFrameTime = 0;
			}
			lviCameraRuntime.lastCommand = command.type;
			stateChanged = true;
			continue;
		}
		if (!lviCameraRuntime.freeMode) {
			continue;
		}

		switch (command.type) {
			case LVICameraCommandType::Reset:
				lviCameraRuntime.position =
					lviCameraRuntime.originalPosition;
				lviCameraRuntime.rotation =
					lviCameraRuntime.originalRotation;
				lviCameraRuntime.zoomValue =
					lviCameraRuntime.originalZoomValue;
				break;
			case LVICameraCommandType::Forward:
			case LVICameraCommandType::Backward:
			case LVICameraCommandType::Left:
			case LVICameraCommandType::Right: {
				Unity::Vector3 horizontalRight;
				Unity::Vector3 horizontalForward;
				lviCameraHorizontalAxes(
					lviCameraRuntime.rotation,
					horizontalRight,
					horizontalForward
				);
				Unity::Vector3 direction;
				if (command.type == LVICameraCommandType::Forward) {
					direction = horizontalForward;
				} else if (
					command.type == LVICameraCommandType::Backward
				) {
					direction = -horizontalForward;
				} else if (command.type == LVICameraCommandType::Left) {
					direction = -horizontalRight;
				} else {
					direction = horizontalRight;
				}
				lviCameraRuntime.position += direction * movementStep;
				break;
			}
			case LVICameraCommandType::Up:
				lviCameraRuntime.position +=
					Unity::Vector3::Up() * movementStep;
				break;
			case LVICameraCommandType::Down:
				lviCameraRuntime.position +=
					Unity::Vector3::Down() * movementStep;
				break;
			case LVICameraCommandType::YawLeft:
			case LVICameraCommandType::YawRight:
			case LVICameraCommandType::PitchUp:
			case LVICameraCommandType::PitchDown: {
				Unity::Vector3 euler =
					Unity::Quaternion::ToEuler(lviCameraRuntime.rotation);
				if (command.type == LVICameraCommandType::YawLeft) {
					euler.Y -= rotationStep;
				} else if (command.type == LVICameraCommandType::YawRight) {
					euler.Y += rotationStep;
				} else if (command.type == LVICameraCommandType::PitchUp) {
					euler.X -= rotationStep;
				} else {
					euler.X += rotationStep;
				}
				float pitchLimit = 89.0f *
					static_cast<float>(M_PI / 180.0);
				euler.X = lviClamp(euler.X, -pitchLimit, pitchLimit);
				lviCameraRuntime.rotation =
					Unity::Quaternion::FromEuler(euler);
				break;
			}
			case LVICameraCommandType::ZoomIn:
				lviCameraRuntime.zoomValue =
					lviClamp(
						lviCameraRuntime.zoomValue - zoomStep,
						zoomMinimum,
						zoomMaximum
					);
				break;
			case LVICameraCommandType::ZoomOut:
				lviCameraRuntime.zoomValue =
					lviClamp(
						lviCameraRuntime.zoomValue + zoomStep,
						zoomMinimum,
						zoomMaximum
					);
				break;
			default:
				break;
		}
		lviCameraRuntime.lastCommand = command.type;
		stateChanged = true;
	}

	if (stateChanged) {
		lviPublishCurrentCameraState();
	}
}

static bool lviProcessCameraContinuousInput() {
	if (lviCameraRuntime.scene == LVICameraScene::None ||
		!lviCameraRuntime.freeMode) {
		lviJoystickLastFrameTime = 0;
		return false;
	}

	float horizontal =
		lviJoystickHorizontal.load(std::memory_order_acquire);
	float vertical =
		lviJoystickVertical.load(std::memory_order_acquire);
	float yawDirection =
		lviHeldYawDirection.load(std::memory_order_acquire);
	float pitchDirection =
		lviHeldPitchDirection.load(std::memory_order_acquire);
	float zoomDirection =
		lviHeldZoomDirection.load(std::memory_order_acquire);
	bool hasMovement =
		fabs(horizontal) >= 0.001f || fabs(vertical) >= 0.001f;
	bool hasYaw = fabs(yawDirection) >= 0.001f;
	bool hasPitch = fabs(pitchDirection) >= 0.001f;
	bool hasZoom = fabs(zoomDirection) >= 0.001f;
	if (!hasMovement && !hasYaw && !hasPitch && !hasZoom) {
		lviJoystickLastFrameTime = 0;
		return false;
	}

	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	if (lviJoystickLastFrameTime <= 0) {
		lviJoystickLastFrameTime = now;
		return false;
	}
	float deltaTime = static_cast<float>(
		now - lviJoystickLastFrameTime
	);
	lviJoystickLastFrameTime = now;
	deltaTime = lviClamp(deltaTime, 0.0f, 0.10f);
	if (deltaTime <= 0.0f) {
		return false;
	}

	if (hasMovement) {
		float movementSpeed = MAX(
			0.01f,
			lviConfigFloat(@"CameraControl.Joystick.MoveSpeed", 0.8f)
		) * static_cast<float>(lviJoystickSensitivityMultiplier());
		Unity::Vector3 horizontalRight;
		Unity::Vector3 horizontalForward;
		lviCameraHorizontalAxes(
			lviCameraRuntime.rotation,
			horizontalRight,
			horizontalForward
		);
		Unity::Vector3 movement = horizontalRight * horizontal;
		if (lviJoystickHeightMode.load(std::memory_order_acquire)) {
			movement += Unity::Vector3::Up() * vertical;
		} else {
			movement += horizontalForward * vertical;
		}
		lviCameraRuntime.position +=
			movement * movementSpeed * deltaTime;
		lviCameraRuntime.lastCommand =
			LVICameraCommandType::JoystickMove;
	}

	if (hasYaw) {
		float yawSpeedDegrees = MAX(
			0.1f,
			lviConfigFloat(
				@"CameraControl.HoldYawDegreesPerSecond",
				60.0f
			)
		);
		float yawDelta = yawDirection * yawSpeedDegrees *
			static_cast<float>(M_PI / 180.0) * deltaTime;
		Unity::Vector3 euler =
			Unity::Quaternion::ToEuler(lviCameraRuntime.rotation);
		euler.Y += yawDelta;
		lviCameraRuntime.rotation =
			Unity::Quaternion::FromEuler(euler);
		lviCameraRuntime.lastCommand = yawDirection < 0.0f
			? LVICameraCommandType::YawLeft
			: LVICameraCommandType::YawRight;
	}

	if (hasPitch) {
		float pitchSpeedDegrees = MAX(
			0.1f,
			lviConfigFloat(
				@"CameraControl.HoldPitchDegreesPerSecond",
				60.0f
			)
		);
		float pitchDelta = pitchDirection * pitchSpeedDegrees *
			static_cast<float>(M_PI / 180.0) * deltaTime;
		Unity::Vector3 euler =
			Unity::Quaternion::ToEuler(lviCameraRuntime.rotation);
		euler.X += pitchDelta;
		float pitchLimit = 89.0f *
			static_cast<float>(M_PI / 180.0);
		euler.X = lviClamp(euler.X, -pitchLimit, pitchLimit);
		lviCameraRuntime.rotation =
			Unity::Quaternion::FromEuler(euler);
		lviCameraRuntime.lastCommand = pitchDirection < 0.0f
			? LVICameraCommandType::PitchUp
			: LVICameraCommandType::PitchDown;
	}

	if (hasZoom) {
		float zoomSpeed = lviCameraRuntime.orthographic
			? lviConfigFloat(
				@"CameraControl.HoldOrthographicZoomPerSecond",
				10.0f
			)
			: lviConfigFloat(
				@"CameraControl.HoldPerspectiveZoomPerSecond",
				50.0f
			);
		zoomSpeed = MAX(0.01f, zoomSpeed);
		float zoomMinimum = lviCameraRuntime.orthographic
			? lviConfigFloat(
				@"CameraControl.OrthographicZoomMinimum",
				0.5f
			)
			: lviConfigFloat(
				@"CameraControl.PerspectiveZoomMinimum",
				10.0f
			);
		zoomMinimum = MAX(0.01f, zoomMinimum);
		float zoomMaximum = lviCameraRuntime.orthographic
			? lviConfigFloat(
				@"CameraControl.OrthographicZoomMaximum",
				30.0f
			)
			: lviConfigFloat(
				@"CameraControl.PerspectiveZoomMaximum",
				100.0f
			);
		zoomMaximum = MAX(zoomMinimum, zoomMaximum);
		lviCameraRuntime.zoomValue = lviClamp(
			lviCameraRuntime.zoomValue +
				zoomDirection * zoomSpeed * deltaTime,
			zoomMinimum,
			zoomMaximum
		);
		lviCameraRuntime.lastCommand = zoomDirection < 0.0f
			? LVICameraCommandType::ZoomIn
			: LVICameraCommandType::ZoomOut;
	}

	if (now - lviJoystickLastPublishTime >= 0.10) {
		lviJoystickLastPublishTime = now;
		lviPublishCurrentCameraState();
	}
	return true;
}

struct LVIScriptableRenderContext {
	void *pointer;
};

static void (*original_RenderPipeline_BeginCameraRendering)(
	LVIScriptableRenderContext context,
	Unity::CCamera *camera,
	void *methodInfo
) = nullptr;

static void hooked_RenderPipeline_BeginCameraRendering(
	LVIScriptableRenderContext context,
	Unity::CCamera *camera,
	void *methodInfo
) {
	original_RenderPipeline_BeginCameraRendering(context, camera, methodInfo);
	if (!camera ||
		camera != lviCameraRuntime.camera ||
		lviCameraRuntime.scene == LVICameraScene::None) {
		return;
	}
	lviProcessCameraCommands();
	lviProcessCameraContinuousInput();
	if (lviCameraRuntime.freeMode) {
		lviApplyCameraPose(lviCameraRuntime);
	}
}

static void (*original_ActivityPlaybackCallback)(
	void *self,
	bool isContinuous,
	bool isPortrait,
	int skipLine,
	void *methodInfo
) = nullptr;

static void hooked_ActivityPlaybackCallback(
	void *self,
	bool isContinuous,
	bool isPortrait,
	int skipLine,
	void *methodInfo
) {
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	if (lviActivityLandscapeRepairEnabled()) {
		// The iPad-wide NoOrientation hook intentionally suppresses stock
		// rotation requests.  Activity Record, however, sizes its model space
		// and render target from the selected orientation.  Keep the stock
		// orientation path available from before the playback callback until
		// the model space has been set up.
		lviActivityOrientationPending.store(
			true,
			std::memory_order_release
		);
		lviActivityPlaybackSessionActive.store(
			false,
			std::memory_order_release
		);
		lviActivityOrientationDeadline.store(
			now + 30.0,
			std::memory_order_release
		);
		lviActivityRebindDeadline.store(0, std::memory_order_release);
		NSLog(
			@"[LinkuraVisualsIOS][ActivityLandscape] Playback orientation "
			 "scope opened (portrait=%d).",
			isPortrait
		);
	}
	if (lviActivityCameraAdapterReady) {
		lviPendingActivityPlayback = true;
		lviPendingActivityDeadline = now + 30.0;
	}
	original_ActivityPlaybackCallback(
		self,
		isContinuous,
		isPortrait,
		skipLine,
		methodInfo
	);
}

static void (*original_StoryModelSpaceManager_Setup)(
	void *self,
	bool skipReturn,
	int skipLine,
	float timeSec,
	bool seekBar,
	void *methodInfo
) = nullptr;

static void hooked_StoryModelSpaceManager_Setup(
	void *self,
	bool skipReturn,
	int skipLine,
	float timeSec,
	bool seekBar,
	void *methodInfo
) {
	original_StoryModelSpaceManager_Setup(
		self,
		skipReturn,
		skipLine,
		timeSec,
		seekBar,
		methodInfo
	);
	CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
	bool cameraPending =
		lviPendingActivityPlayback &&
		now <= lviPendingActivityDeadline;
	bool orientationPending =
		lviActivityOrientationPending.load(std::memory_order_acquire) &&
		now <= lviActivityOrientationDeadline.load(
			std::memory_order_acquire
		);
	bool sessionActive = lviActivityPlaybackSessionActive.load(
		std::memory_order_acquire
	);
	bool rotationRebind =
		lviActivityLandscapeRepairEnabled() &&
		now <= lviActivityRebindDeadline.load(std::memory_order_acquire);
	bool activitySetup =
		lviActivityLandscapeRepairEnabled() &&
		(orientationPending || sessionActive || rotationRebind);
	if (activitySetup) {
		lviActivityOrientationPending.store(
			false,
			std::memory_order_release
		);
		lviActivityOrientationDeadline.store(0, std::memory_order_release);
		lviActivityRebindDeadline.store(0, std::memory_order_release);
		lviActivityPlaybackSessionActive.store(
			true,
			std::memory_order_release
		);
		if (rotationRebind) {
			NSLog(
				@"[LinkuraVisualsIOS][ActivityLandscape] Rebinding the "
				 "rotated Activity Record model space."
			);
		}
	}
	bool shouldRegister =
		cameraPending || activitySetup;
	lviPendingActivityPlayback = false;
	lviPendingActivityDeadline = 0;
	if (!shouldRegister ||
		!configBool(@"ActivityRecord.CameraControl.Enable") ||
		!self) {
		return;
	}
	void *modelSpace = *reinterpret_cast<void **>(
		reinterpret_cast<uintptr_t>(self) + 0x20
	);
	Unity::CCamera *storyCamera = modelSpace
		? *reinterpret_cast<Unity::CCamera **>(
			reinterpret_cast<uintptr_t>(modelSpace) + 0x20
		)
		: nullptr;
	lviRegisterCameraTarget(
		LVICameraScene::ActivityRecord,
		self,
		storyCamera
	);
}

static void (*original_StoryModelSpaceManager_Release)(
	void *self,
	void *methodInfo
) = nullptr;

static void hooked_StoryModelSpaceManager_Release(
	void *self,
	void *methodInfo
) {
	bool activityScopeWasActive =
		lviActivityOrientationPassthroughActive() ||
		(lviCameraRuntime.scene == LVICameraScene::ActivityRecord &&
		 lviCameraRuntime.owner == self);
	lviClearCameraTarget(LVICameraScene::ActivityRecord, self);
	// Keep the activity flag set while the stock release path restores the
	// portrait/landscape state.  Clearing it before the original call would
	// make the global NoOrientation hook swallow that final request.
	original_StoryModelSpaceManager_Release(self, methodInfo);
	if (!activityScopeWasActive ||
		!lviActivityLandscapeRepairEnabled()) {
		return;
	}

	bool replacementCameraAlreadyRegistered =
		lviCameraRuntime.scene == LVICameraScene::ActivityRecord &&
		lviCameraRuntime.owner &&
		lviCameraRuntime.owner != self;
	lviActivityOrientationPending.store(false, std::memory_order_release);
	lviActivityOrientationDeadline.store(0, std::memory_order_release);
	lviActivityPlaybackSessionActive.store(
		replacementCameraAlreadyRegistered,
		std::memory_order_release
	);
	lviActivityRebindDeadline.store(
		replacementCameraAlreadyRegistered
			? 0
			: CFAbsoluteTimeGetCurrent() +
				lviActivityRebindGraceSeconds(),
		std::memory_order_release
	);
}
#if LVI_WM_DIAGNOSTIC
static void lviRecordWMClockSeekLimit(
	float requestedRate,
	float effectiveRate,
	bool repaired
);
static void lviRecordWMClockPlayableLengthRate(
	void *playPositionModel,
	float requestedRate,
	float effectiveRate,
	bool repaired,
	NSString *source
);
#endif

static void (*original_ArchiveSeekBarView_SetSeekLimit)(
	void *self,
	float rate,
	void *methodInfo
) = nullptr;

static void hooked_ArchiveSeekBarView_SetSeekLimit(
	void *self,
	float requestedRate,
	void *methodInfo
) {
	float effectiveRate = requestedRate;
	bool repaired =
		lviWithArchiveFullSeekActive.load(std::memory_order_acquire) &&
		std::isfinite(requestedRate) &&
		requestedRate > 0.0f &&
		requestedRate < 1.0f;
	if (repaired) {
		effectiveRate = 1.0f;
	}
	original_ArchiveSeekBarView_SetSeekLimit(
		self,
		effectiveRate,
		methodInfo
	);
#if LVI_WM_DIAGNOSTIC
	lviRecordWMClockSeekLimit(
		requestedRate,
		effectiveRate,
		repaired
	);
#endif
}

static void (*original_LiveConnectPlayPositionModel_SetPlayableLengthRate)(
	void *self,
	float rate,
	void *methodInfo
) = nullptr;

static bool lviWithArchiveIarcFullSeekMatchesPlayPositionModel(
	void *playPositionModel
) {
	return
		lviWithArchiveFullSeekActive.load(std::memory_order_acquire) &&
		playPositionModel &&
		playPositionModel ==
			lviWithArchiveFullSeekPlayPositionModel.load(
				std::memory_order_acquire
			) &&
		lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(playPositionModel),
			"School.LiveMain",
			"LiveConnectPlayPositionModel"
		);
}

static void hooked_LiveConnectPlayPositionModel_SetPlayableLengthRate(
	void *self,
	float requestedRate,
	void *methodInfo
) {
	float effectiveRate = requestedRate;
	bool repaired =
		lviWithArchiveIarcFullSeekMatchesPlayPositionModel(self) &&
		std::isfinite(requestedRate) &&
		requestedRate > 0.0f &&
		requestedRate < 1.0f;
	if (repaired) {
		effectiveRate = 1.0f;
	}
	original_LiveConnectPlayPositionModel_SetPlayableLengthRate(
		self,
		effectiveRate,
		methodInfo
	);
#if LVI_WM_DIAGNOSTIC
	lviRecordWMClockPlayableLengthRate(
		self,
		requestedRate,
		effectiveRate,
		repaired,
		@"setter"
	);
#endif
}

static bool (*original_LiveConnectPlayPositionModel_IsPlayToEnd)(
	void *self,
	void *isPlayToEndDelegate,
	void *methodInfo
) = nullptr;

static bool lviWithArchiveIarcIsPrematurePlayToEnd(
	void *playPositionModel,
	float& contentsLength,
	float& seekTime,
	float& playableLengthRate
) {
	contentsLength = -1.0f;
	seekTime = -1.0f;
	playableLengthRate = -1.0f;
	if (!lviWithArchiveIarcFullSeekMatchesPlayPositionModel(
			playPositionModel
		)) {
		return false;
	}

	// Verified against the 5.0.1 arm64 IsPlayToEnd implementation:
	// LiveConnectPlayPositionModel stores ReactiveProperty<float> references
	// at +0x10/+0x18/+0x20, and each property's current float value follows
	// the two-pointer Il2CppObject header at +0x10.
	uintptr_t model = reinterpret_cast<uintptr_t>(playPositionModel);
	void *contentsProperty =
		*reinterpret_cast<void **>(model + 0x10);
	void *playableRateProperty =
		*reinterpret_cast<void **>(model + 0x18);
	void *seekTimeProperty =
		*reinterpret_cast<void **>(model + 0x20);
	if (!contentsProperty || !playableRateProperty || !seekTimeProperty) {
		return false;
	}
	constexpr uintptr_t valueOffset = sizeof(Unity::il2cppObject);
	contentsLength = *reinterpret_cast<float *>(
		reinterpret_cast<uintptr_t>(contentsProperty) + valueOffset
	);
	playableLengthRate = *reinterpret_cast<float *>(
		reinterpret_cast<uintptr_t>(playableRateProperty) + valueOffset
	);
	seekTime = *reinterpret_cast<float *>(
		reinterpret_cast<uintptr_t>(seekTimeProperty) + valueOffset
	);
	if (!std::isfinite(contentsLength) ||
		!std::isfinite(playableLengthRate) ||
		!std::isfinite(seekTime) ||
		contentsLength <= 0.0f ||
		seekTime < 0.0f ||
		playableLengthRate <= 0.0f) {
		return false;
	}
	// Suppress only an end state that occurs before the real archive length.
	// Do not require a fractional playable-length rate here: the full-seek
	// repair intentionally normalizes that rate to 1.0 before this predicate
	// can run.  The genuine archive end keeps the stock REPLAY behavior.
	return seekTime + 0.5f < contentsLength;
}

static bool hooked_LiveConnectPlayPositionModel_IsPlayToEnd(
	void *self,
	void *isPlayToEndDelegate,
	void *methodInfo
) {
	// IsPlayToEnd short-circuits to true when SeekTime reaches
	// floor(ContentsLength * PlayableLengthRate).  At the fixed-video/IARC
	// hand-off this happens before ArchiveReplayButtonPresenter's fallback
	// delegate is evaluated, so changing only that delegate cannot suppress
	// the false 29-minute end state.
	bool stockValue =
		original_LiveConnectPlayPositionModel_IsPlayToEnd(
			self,
			isPlayToEndDelegate,
			methodInfo
		);
	float contentsLength = -1.0f;
	float seekTime = -1.0f;
	float playableLengthRate = -1.0f;
	bool suppress =
		stockValue &&
		lviWithArchiveIarcReplayOverlaySuppressionEnabled() &&
		lviWithArchiveIarcIsPrematurePlayToEnd(
			self,
			contentsLength,
			seekTime,
			playableLengthRate
		);
#if LVI_WM_DIAGNOSTIC
	bool exactActiveModel =
		lviWithArchiveIarcFullSeekMatchesPlayPositionModel(self);
	if (stockValue && exactActiveModel &&
		!lviWithArchiveFalseEndSuppressionReported.exchange(
			true,
			std::memory_order_acq_rel
			)) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-false-end-suppression",
			@"pipelineVersion": @4,
			@"stockIsPlayToEnd": @true,
			@"effectiveIsPlayToEnd": @(!suppress),
			@"exactActivePlayPositionModel": @true,
			@"contentsLengthSeconds": @(contentsLength),
			@"seekTimeSeconds": @(seekTime),
			@"playableLengthRate": @(playableLengthRate),
			@"suppressed": @(suppress)
		});
	}
#endif
	// The exact active WM/IARC model is the only changed scope.  Returning
	// false here prevents the same false end event from reaching the stock
	// REPLAY/dimming presenter and LiveConnectAutoStopPresenter.
	return suppress ? false : stockValue;
}

static bool lviForceWithArchiveIarcFullPlayableLength(void *models) {
	if (!models ||
		models != lviWithArchiveFullSeekModelsOwner.load(
			std::memory_order_acquire
		) ||
		!original_LiveConnectPlayPositionModel_SetPlayableLengthRate) {
		return false;
	}
	void *playPositionModel =
		lviWithArchiveFullSeekPlayPositionModel.load(
			std::memory_order_acquire
		);
	if (!lviWithArchiveIarcFullSeekMatchesPlayPositionModel(
			playPositionModel
		)) {
		return false;
	}
	// ArchiveExtraAdmissionDispatchPresenter can set the model's playable
	// length before VideoArchiveSeekBarPresenter is initialized. Re-apply the
	// full rate through the stock model API at this exact WM/IARC boundary so
	// PlayedToEndStatusChanged, ArchiveReplayButtonPresenter and
	// LiveConnectAutoStopPresenter all share the real archive end.
	original_LiveConnectPlayPositionModel_SetPlayableLengthRate(
		playPositionModel,
		1.0f,
		nullptr
	);
#if LVI_WM_DIAGNOSTIC
	lviRecordWMClockPlayableLengthRate(
		playPositionModel,
		1.0f,
		1.0f,
		true,
		@"seekbar-initialize-force"
	);
#endif
	return true;
}

static bool (*original_ArchiveReplayButtonPresenter_ReplayPredicate)(
	void *self,
	void *methodInfo
) = nullptr;

static bool lviWithArchiveReplayPredicateMatches(void *closureSelf) {
	if (!lviWithArchiveIarcReplayOverlaySuppressionEnabled() ||
		!lviWithArchiveFullSeekActive.load(
			std::memory_order_acquire
		) ||
		!closureSelf) {
		return false;
	}
	Unity::il2cppClass *expectedClosureClass =
		lviWithArchiveReplayPredicateClosureClass.load(
			std::memory_order_acquire
		);
	auto *closure =
		reinterpret_cast<IL2CPP::CClass*>(closureSelf);
	if (!expectedClosureClass ||
		closure->m_Object.m_pClass != expectedClosureClass) {
		return false;
	}
	void *controlModel = nullptr;
	if (!lviReadExactInstanceField(
			closure,
			"connectControlModel",
			controlModel
		)) {
		return false;
	}
	void *activeControlModel =
		lviWithArchiveFullSeekControlModel.load(
			std::memory_order_acquire
		);
	return controlModel &&
		controlModel == activeControlModel &&
		lviManagedObjectIsExactClass(
			reinterpret_cast<IL2CPP::CClass*>(controlModel),
			"School.LiveMain",
			"LiveConnectControlModel"
		);
}

static bool hooked_ArchiveReplayButtonPresenter_ReplayPredicate(
	void *self,
	void *methodInfo
) {
	bool stockValue =
		original_ArchiveReplayButtonPresenter_ReplayPredicate(
			self,
			methodInfo
		);
	bool suppress =
		stockValue &&
		lviWithArchiveReplayPredicateMatches(self);
#if LVI_WM_DIAGNOSTIC
	if (stockValue) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-replay-predicate",
			@"pipelineVersion": @3,
			@"stockShowReplay": @true,
			@"effectiveShowReplay": @(!suppress),
			@"suppressed": @(suppress)
		});
	}
#endif
	// This is the stock predicate that gates the root containing both the
	// central REPLAY control and its dimming/raycast overlay. Change only a
	// stock true result for the exact active WM/IARC control model. Playback
	// time, seeking, pause state and every GameObject remain untouched.
	return suppress ? false : stockValue;
}

#if LVI_WM_DIAGNOSTIC
/*
 * With×MEETS/IARC clock diagnostic
 *
 * The stock VideoArchiveSeekBarPresenter is retained for an IARC archive by
 * temporarily exposing ArchiveHls during its synchronous content-type check.
 * The 2026-03-28 archive can nevertheless keep two different clocks alive:
 * the fixed-video clock ends near 29 minutes while the IARC archive continues
 * to 50 minutes.  These hooks are deliberately read-only.  They record which
 * clock reaches End/REPLAY and the exact value emitted when a seek gesture is
 * released, without changing admission, chapter, duration, seek, or replay
 * state.
 */
struct LVIWMClockDiagnosticState {
	void *models = nullptr;
	void *controlModel = nullptr;
	void *playPositionModel = nullptr;
	void *contentsController = nullptr;
	float contentsLength = -1.0f;
	float controllerContentsLength = -1.0f;
	float playableLengthRate = -1.0f;
	float seekLimit = -1.0f;
	float lastModelSeekTime = -1.0f;
	float lastLoggedModelSeekTime = -1.0f;
	float lastControlPlayingPosition = -1.0f;
	float lastLoggedControlPlayingPosition = -1.0f;
	float lastControllerPlayingPosition = -1.0f;
	float lastLoggedControllerPlayingPosition = -1.0f;
	float lastSeekCallbackValue = -1.0f;
	bool hasControlEndState = false;
	bool controlEndState = false;
	bool hasControllerEndState = false;
	bool controllerEndState = false;
	bool hasReplayPredicate = false;
	bool replayPredicate = false;
};

static std::mutex lviWMClockDiagnosticMutex;
static LVIWMClockDiagnosticState lviWMClockDiagnosticState;

static NSString* lviWMClockPointerToken(void *pointer) {
	if (!pointer) {
		return @"<null>";
	}
	uintptr_t value = reinterpret_cast<uintptr_t>(pointer);
	uint64_t hash = 1469598103934665603ULL;
	for (size_t index = 0; index < sizeof(value); ++index) {
		hash ^= static_cast<uint64_t>(
			(value >> (index * 8)) & static_cast<uintptr_t>(0xff)
		);
		hash *= 1099511628211ULL;
	}
	hash ^= 0x574d434c4f434b32ULL;
	hash *= 1099511628211ULL;
	return [NSString stringWithFormat:
		@"%016llx",
		static_cast<unsigned long long>(hash)
	];
}

static NSString* lviWMClockManagedClassName(void *object) {
	if (!object) {
		return @"<null>";
	}
	Unity::il2cppClass *managedClass =
		reinterpret_cast<Unity::il2cppObject*>(object)->m_pClass;
	if (!managedClass || !managedClass->m_pName) {
		return @"<unavailable>";
	}
	NSString *name =
		[NSString stringWithUTF8String:managedClass->m_pName]
			?: @"<invalid>";
	if (!managedClass->m_pNamespace ||
		managedClass->m_pNamespace[0] == '\0') {
		return name;
	}
	NSString *nameSpace =
		[NSString stringWithUTF8String:managedClass->m_pNamespace]
			?: @"<invalid>";
	return [NSString stringWithFormat:@"%@.%@", nameSpace, name];
}

static bool lviWMClockNearBoundary(float seconds) {
	return std::fabs(seconds - 1740.0f) <= 5.0f ||
		std::fabs(seconds - 2280.0f) <= 5.0f ||
		std::fabs(seconds - 2330.0f) <= 5.0f ||
		std::fabs(seconds - 3000.0f) <= 5.0f;
}

static void lviRegisterWMClockDiagnosticSession(
	void *models,
	NSString *source
) {
	if (!models) {
		return;
	}
	void *controlModel = *reinterpret_cast<void **>(
		reinterpret_cast<uintptr_t>(models) + 0x218
	);
	void *playPositionModel = *reinterpret_cast<void **>(
		reinterpret_cast<uintptr_t>(models) + 0x210
	);
	bool newSession = false;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		newSession = lviWMClockDiagnosticState.models != models;
		if (newSession) {
			lviWMClockDiagnosticState = {};
			lviWMClockDiagnosticState.models = models;
		}
		if (controlModel) {
			lviWMClockDiagnosticState.controlModel = controlModel;
		}
		if (playPositionModel) {
			lviWMClockDiagnosticState.playPositionModel =
				playPositionModel;
		}
	}
	lviWriteWMDiagnostic(@{
		@"stage": @"wm-clock-session",
		@"pipelineVersion": @2,
		@"source": source ?: @"<unknown>",
		@"newSession": @(newSession),
		@"modelsToken": lviWMClockPointerToken(models),
		@"controlModelToken": lviWMClockPointerToken(controlModel),
		@"playPositionModelToken":
			lviWMClockPointerToken(playPositionModel),
		@"modelsClass": lviWMClockManagedClassName(models),
		@"controlModelClass":
			lviWMClockManagedClassName(controlModel),
		@"playPositionModelClass":
			lviWMClockManagedClassName(playPositionModel)
	});
}

static bool lviWMClockSessionIsActive() {
	std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
	return lviWMClockDiagnosticState.models != nullptr;
}

static bool lviWMClockMatchesModels(void *models) {
	std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
	return models &&
		lviWMClockDiagnosticState.models == models;
}

static bool lviWMClockMatchesControlModel(void *model) {
	std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
	return model &&
		lviWMClockDiagnosticState.controlModel == model;
}

static bool lviWMClockMatchesPlayPositionModel(void *model) {
	std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
	return model &&
		lviWMClockDiagnosticState.playPositionModel == model;
}

static bool lviWMClockMatchesContentsController(void *controller) {
	std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
	return controller &&
		lviWMClockDiagnosticState.contentsController == controller;
}

static NSDictionary* lviWMClockValueContext(float callbackValue) {
	float contentsLength = -1.0f;
	float playableLengthRate = -1.0f;
	float seekLimit = -1.0f;
	float modelSeek = -1.0f;
	float controlPosition = -1.0f;
	float controllerPosition = -1.0f;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		contentsLength = lviWMClockDiagnosticState.contentsLength;
		playableLengthRate =
			lviWMClockDiagnosticState.playableLengthRate;
		seekLimit = lviWMClockDiagnosticState.seekLimit;
		modelSeek = lviWMClockDiagnosticState.lastModelSeekTime;
		controlPosition =
			lviWMClockDiagnosticState.lastControlPlayingPosition;
		controllerPosition =
			lviWMClockDiagnosticState.lastControllerPlayingPosition;
	}
	float callbackRate =
		contentsLength > 0.0f
			? callbackValue / contentsLength
			: -1.0f;
	return @{
		@"callbackValueSeconds": @(callbackValue),
		@"callbackRateFromKnownLength": @(callbackRate),
		@"knownContentsLengthSeconds": @(contentsLength),
		@"knownPlayableLengthRate": @(playableLengthRate),
		@"knownSeekLimitRate": @(seekLimit),
		@"lastModelSeekTimeSeconds": @(modelSeek),
		@"lastControlPlayingPositionSeconds": @(controlPosition),
		@"lastControllerPlayingPositionSeconds": @(controllerPosition)
	};
}

static void lviEndWMClockDiagnosticSession(void *models) {
	NSString *modelsToken = nil;
	NSString *controllerToken = nil;
	bool ended = false;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		if (models &&
			lviWMClockDiagnosticState.models == models) {
			modelsToken = lviWMClockPointerToken(
				lviWMClockDiagnosticState.models
			);
			controllerToken = lviWMClockPointerToken(
				lviWMClockDiagnosticState.contentsController
			);
			lviWMClockDiagnosticState = {};
			ended = true;
		}
	}
	if (ended) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-session-end",
			@"pipelineVersion": @2,
			@"modelsToken": modelsToken ?: @"<null>",
			@"controllerToken": controllerToken ?: @"<null>"
		});
	}
}

static void (*original_LiveConnectPlayPositionModel_SetContentsLength)(
	void *self,
	float seconds,
	void *methodInfo
) = nullptr;

static void hooked_LiveConnectPlayPositionModel_SetContentsLength(
	void *self,
	float seconds,
	void *methodInfo
) {
	original_LiveConnectPlayPositionModel_SetContentsLength(
		self,
		seconds,
		methodInfo
	);
	if (!lviWMClockMatchesPlayPositionModel(self)) {
		return;
	}
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		lviWMClockDiagnosticState.contentsLength = seconds;
	}
	lviWriteWMDiagnostic(@{
		@"stage": @"wm-clock-content-length",
		@"pipelineVersion": @2,
		@"seconds": @(seconds)
	});
}

static void lviRecordWMClockPlayableLengthRate(
	void *playPositionModel,
	float requestedRate,
	float effectiveRate,
	bool repaired,
	NSString *source
) {
	if (!lviWMClockMatchesPlayPositionModel(playPositionModel)) {
		return;
	}
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		lviWMClockDiagnosticState.playableLengthRate = effectiveRate;
	}
	lviWriteWMDiagnostic(@{
		@"stage": @"wm-clock-playable-rate",
		@"pipelineVersion": @2,
		@"source": source ?: @"<unknown>",
		@"requestedRate": @(requestedRate),
		@"effectiveRate": @(effectiveRate),
		@"repaired": @(repaired)
	});
}

static void (*original_LiveConnectPlayPositionModel_OnNextSeekTime)(
	void *self,
	float seconds,
	void *methodInfo
) = nullptr;

static void hooked_LiveConnectPlayPositionModel_OnNextSeekTime(
	void *self,
	float seconds,
	void *methodInfo
) {
	original_LiveConnectPlayPositionModel_OnNextSeekTime(
		self,
		seconds,
		methodInfo
	);
	if (!lviWMClockMatchesPlayPositionModel(self)) {
		return;
	}
	float previous = -1.0f;
	bool shouldLog = false;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		previous = lviWMClockDiagnosticState.lastModelSeekTime;
		lviWMClockDiagnosticState.lastModelSeekTime = seconds;
		shouldLog =
			lviWMClockDiagnosticState.lastLoggedModelSeekTime < 0.0f ||
			std::fabs(
				seconds -
				lviWMClockDiagnosticState.lastLoggedModelSeekTime
			) >= 30.0f ||
			(seconds < 2.0f && previous > 30.0f) ||
			lviWMClockNearBoundary(seconds);
		if (shouldLog) {
			lviWMClockDiagnosticState.lastLoggedModelSeekTime =
				seconds;
		}
	}
	if (shouldLog) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-model-seek-time",
			@"pipelineVersion": @2,
			@"seconds": @(seconds),
			@"previousSeconds": @(previous),
			@"resetToStart": @(seconds < 2.0f && previous > 30.0f)
		});
	}
}

static void lviRecordWMClockSeekLimit(
	float requestedRate,
	float effectiveRate,
	bool repaired
) {
	if (!lviWMClockSessionIsActive()) {
		return;
	}
	bool changed = false;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		changed =
			lviWMClockDiagnosticState.seekLimit < 0.0f ||
			std::fabs(
				lviWMClockDiagnosticState.seekLimit -
					effectiveRate
			) >
				0.0001f;
		lviWMClockDiagnosticState.seekLimit = effectiveRate;
	}
	if (changed) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-seek-limit",
			@"pipelineVersion": @2,
			@"rate": @(effectiveRate),
			@"requestedRate": @(requestedRate),
			@"effectiveRate": @(effectiveRate),
			@"repaired": @(repaired)
		});
	}
}

static void (*original_LiveConnectControlModel_SetContentsController)(
	void *self,
	void *controller,
	void *methodInfo
) = nullptr;

static void hooked_LiveConnectControlModel_SetContentsController(
	void *self,
	void *controller,
	void *methodInfo
) {
	original_LiveConnectControlModel_SetContentsController(
		self,
		controller,
		methodInfo
	);
	if (!lviWMClockMatchesControlModel(self)) {
		return;
	}
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		lviWMClockDiagnosticState.contentsController = controller;
	}
	lviWriteWMDiagnostic(@{
		@"stage": @"wm-clock-controller",
		@"pipelineVersion": @2,
		@"controllerToken": lviWMClockPointerToken(controller),
		@"controllerClass": lviWMClockManagedClassName(controller)
	});
}

static float (*original_LiveConnectControlModel_GetPlayingPosition)(
	void *self,
	void *methodInfo
) = nullptr;

static float hooked_LiveConnectControlModel_GetPlayingPosition(
	void *self,
	void *methodInfo
) {
	float seconds =
		original_LiveConnectControlModel_GetPlayingPosition(
			self,
			methodInfo
		);
	if (!lviWMClockMatchesControlModel(self)) {
		return seconds;
	}
	float previous = -1.0f;
	bool shouldLog = false;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		previous =
			lviWMClockDiagnosticState.lastControlPlayingPosition;
		lviWMClockDiagnosticState.lastControlPlayingPosition =
			seconds;
		shouldLog =
			lviWMClockDiagnosticState
				.lastLoggedControlPlayingPosition < 0.0f ||
			std::fabs(
				seconds -
				lviWMClockDiagnosticState
					.lastLoggedControlPlayingPosition
			) >= 30.0f ||
			(seconds < 2.0f && previous > 30.0f) ||
			lviWMClockNearBoundary(seconds);
		if (shouldLog) {
			lviWMClockDiagnosticState
				.lastLoggedControlPlayingPosition = seconds;
		}
	}
	if (shouldLog) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-control-position",
			@"pipelineVersion": @2,
			@"seconds": @(seconds),
			@"previousSeconds": @(previous),
			@"resetToStart": @(seconds < 2.0f && previous > 30.0f)
		});
	}
	return seconds;
}

static bool (*original_LiveConnectControlModel_get_IsPlayToEnd)(
	void *self,
	void *methodInfo
) = nullptr;

static bool hooked_LiveConnectControlModel_get_IsPlayToEnd(
	void *self,
	void *methodInfo
) {
	bool value = original_LiveConnectControlModel_get_IsPlayToEnd(
		self,
		methodInfo
	);
	if (!lviWMClockMatchesControlModel(self)) {
		return value;
	}
	bool changed = false;
	float controlPosition = -1.0f;
	float modelSeek = -1.0f;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		changed =
			!lviWMClockDiagnosticState.hasControlEndState ||
			lviWMClockDiagnosticState.controlEndState != value;
		lviWMClockDiagnosticState.hasControlEndState = true;
		lviWMClockDiagnosticState.controlEndState = value;
		controlPosition =
			lviWMClockDiagnosticState.lastControlPlayingPosition;
		modelSeek = lviWMClockDiagnosticState.lastModelSeekTime;
	}
	if (changed) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-control-end-state",
			@"pipelineVersion": @2,
			@"isPlayToEnd": @(value),
			@"lastControlPlayingPositionSeconds": @(controlPosition),
			@"lastModelSeekTimeSeconds": @(modelSeek)
		});
	}
	return value;
}

static float (*original_RealtimeRenderingArchiveController_get_ContentsLength)(
	void *self,
	void *methodInfo
) = nullptr;

static float hooked_RealtimeRenderingArchiveController_get_ContentsLength(
	void *self,
	void *methodInfo
) {
	float seconds =
		original_RealtimeRenderingArchiveController_get_ContentsLength(
			self,
			methodInfo
		);
	if (lviWMClockMatchesContentsController(self)) {
		bool changed = false;
		{
			std::lock_guard<std::mutex> lock(
				lviWMClockDiagnosticMutex
			);
			changed =
				lviWMClockDiagnosticState
					.controllerContentsLength < 0.0f ||
				std::fabs(
					lviWMClockDiagnosticState
						.controllerContentsLength -
					seconds
				) > 0.0001f;
			lviWMClockDiagnosticState.controllerContentsLength =
				seconds;
		}
		if (changed) {
			lviWriteWMDiagnostic(@{
				@"stage": @"wm-clock-controller-length",
				@"pipelineVersion": @2,
				@"seconds": @(seconds)
			});
		}
	}
	return seconds;
}

static float
(*original_RealtimeRenderingArchiveController_get_PlayingPosition)(
	void *self,
	void *methodInfo
) = nullptr;

static float
hooked_RealtimeRenderingArchiveController_get_PlayingPosition(
	void *self,
	void *methodInfo
) {
	float seconds =
		original_RealtimeRenderingArchiveController_get_PlayingPosition(
			self,
			methodInfo
		);
	if (!lviWMClockMatchesContentsController(self)) {
		return seconds;
	}
	float previous = -1.0f;
	bool shouldLog = false;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		previous =
			lviWMClockDiagnosticState.lastControllerPlayingPosition;
		lviWMClockDiagnosticState.lastControllerPlayingPosition =
			seconds;
		shouldLog =
			lviWMClockDiagnosticState
				.lastLoggedControllerPlayingPosition < 0.0f ||
			std::fabs(
				seconds -
				lviWMClockDiagnosticState
					.lastLoggedControllerPlayingPosition
			) >= 30.0f ||
			(seconds < 2.0f && previous > 30.0f) ||
			lviWMClockNearBoundary(seconds);
		if (shouldLog) {
			lviWMClockDiagnosticState
				.lastLoggedControllerPlayingPosition = seconds;
		}
	}
	if (shouldLog) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-controller-position",
			@"pipelineVersion": @2,
			@"seconds": @(seconds),
			@"previousSeconds": @(previous),
			@"resetToStart": @(seconds < 2.0f && previous > 30.0f)
		});
	}
	return seconds;
}

static bool (*original_RealtimeRenderingArchiveController_get_IsPlayToEnd)(
	void *self,
	void *methodInfo
) = nullptr;

static bool hooked_RealtimeRenderingArchiveController_get_IsPlayToEnd(
	void *self,
	void *methodInfo
) {
	bool value =
		original_RealtimeRenderingArchiveController_get_IsPlayToEnd(
			self,
			methodInfo
		);
	if (!lviWMClockMatchesContentsController(self)) {
		return value;
	}
	bool changed = false;
	float controllerPosition = -1.0f;
	{
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		changed =
			!lviWMClockDiagnosticState.hasControllerEndState ||
			lviWMClockDiagnosticState.controllerEndState != value;
		lviWMClockDiagnosticState.hasControllerEndState = true;
		lviWMClockDiagnosticState.controllerEndState = value;
		controllerPosition =
			lviWMClockDiagnosticState.lastControllerPlayingPosition;
	}
	if (changed) {
		lviWriteWMDiagnostic(@{
			@"stage": @"wm-clock-controller-end-state",
			@"pipelineVersion": @2,
			@"isPlayToEnd": @(value),
			@"lastControllerPlayingPositionSeconds":
				@(controllerPosition)
		});
	}
	return value;
}

typedef void (*LVIWMSeekCallback_t)(
	void *self,
	float playTimeSeconds,
	void *methodInfo
);

static LVIWMSeekCallback_t
	original_VideoArchiveSeekBarPresenter_SeekBegin = nullptr;
static LVIWMSeekCallback_t
	original_VideoArchiveSeekBarPresenter_Seeking = nullptr;
static LVIWMSeekCallback_t
	original_VideoArchiveSeekBarPresenter_SeekEnd = nullptr;

static bool lviWMClockSeekCallbackMatches(void *closureSelf) {
	void *models = closureSelf
		? *reinterpret_cast<void **>(
			reinterpret_cast<uintptr_t>(closureSelf) + 0x18
		)
		: nullptr;
	return lviWMClockMatchesModels(models);
}

static void lviWriteWMClockSeekCallback(
	NSString *stage,
	float playTimeSeconds
) {
	NSMutableDictionary *entry =
		[lviWMClockValueContext(playTimeSeconds) mutableCopy];
	entry[@"stage"] = stage;
	entry[@"pipelineVersion"] = @2;
	lviWriteWMDiagnostic(entry);
}

static void hooked_VideoArchiveSeekBarPresenter_SeekBegin(
	void *self,
	float playTimeSeconds,
	void *methodInfo
) {
	if (lviWMClockSeekCallbackMatches(self)) {
		lviWriteWMClockSeekCallback(
			@"wm-clock-seek-begin",
			playTimeSeconds
		);
	}
	original_VideoArchiveSeekBarPresenter_SeekBegin(
		self,
		playTimeSeconds,
		methodInfo
	);
}

static void hooked_VideoArchiveSeekBarPresenter_Seeking(
	void *self,
	float playTimeSeconds,
	void *methodInfo
) {
	bool shouldLog = false;
	if (lviWMClockSeekCallbackMatches(self)) {
		std::lock_guard<std::mutex> lock(lviWMClockDiagnosticMutex);
		shouldLog =
			lviWMClockDiagnosticState.lastSeekCallbackValue < 0.0f ||
			std::fabs(
				playTimeSeconds -
				lviWMClockDiagnosticState.lastSeekCallbackValue
			) >= 30.0f ||
			lviWMClockNearBoundary(playTimeSeconds);
		if (shouldLog) {
			lviWMClockDiagnosticState.lastSeekCallbackValue =
				playTimeSeconds;
		}
	}
	if (shouldLog) {
		lviWriteWMClockSeekCallback(
			@"wm-clock-seek-drag",
			playTimeSeconds
		);
	}
	original_VideoArchiveSeekBarPresenter_Seeking(
		self,
		playTimeSeconds,
		methodInfo
	);
}

static void hooked_VideoArchiveSeekBarPresenter_SeekEnd(
	void *self,
	float playTimeSeconds,
	void *methodInfo
) {
	if (lviWMClockSeekCallbackMatches(self)) {
		lviWriteWMClockSeekCallback(
			@"wm-clock-seek-release",
			playTimeSeconds
		);
	}
	original_VideoArchiveSeekBarPresenter_SeekEnd(
		self,
		playTimeSeconds,
		methodInfo
	);
}

#endif

static void (*original_LiveConnectMrsPlayerPresenter_Initialize)(
	void *self,
	void *models,
	void *methodInfo
) = nullptr;

static void hooked_LiveConnectMrsPlayerPresenter_Initialize(
	void *self,
	void *models,
	void *methodInfo
) {
	lviResetWithArchiveCameraAdapter();
	void *sceneModel = models
		? *reinterpret_cast<void **>(
			reinterpret_cast<uintptr_t>(models) + 0x20
		)
		: nullptr;
	void *enterModel = models
		? *reinterpret_cast<void **>(
			reinterpret_cast<uintptr_t>(models) + 0x28
		)
		: nullptr;
	int sceneType = sceneModel
		? *reinterpret_cast<int *>(
			reinterpret_cast<uintptr_t>(sceneModel) + 0x20
		)
		: -1;
	int contentType = enterModel
		? *reinterpret_cast<int *>(
			reinterpret_cast<uintptr_t>(enterModel) + 0x20
		)
		: -1;
	// This initializer can be shared by several archive scenes. Only scene
	// type 2 is With×MEETS, so Fes and other live scenes never acquire the WM
	// orientation scope.
	if (sceneType == 2) {
		lviActivateWithArchiveOrientationSession(models, "iarc");
	}
#if LVI_WM_DIAGNOSTIC
	if (sceneType == 2 && contentType == 5) {
		lviRegisterWMClockDiagnosticSession(
			models,
			@"mrs-player-initialize"
		);
	}
#endif
	if (lviWithMeetsArchiveCameraAdapterReady &&
		configBool(@"WithMeets.CameraControl.Enable") &&
		sceneType == 2 &&
		contentType == 5) {
		if (lviWithDynamicCameraOwner) {
			lviClearCameraTarget(
				LVICameraScene::WithMeets,
				lviWithDynamicCameraOwner
			);
			lviWithDynamicCameraOwner = nullptr;
		}
		lviWithArchiveModelsOwner = models;
		lviWithArchiveIarcActive = true;
	}
	original_LiveConnectMrsPlayerPresenter_Initialize(
		self,
		models,
		methodInfo
	);
}

static void (*original_VideoArchiveSeekBarPresenter_Initialize)(
	void *self,
	void *models,
	void *methodInfo
) = nullptr;

static void hooked_VideoArchiveSeekBarPresenter_Initialize(
	void *self,
	void *models,
	void *methodInfo
) {
	/*
	 * The stock seek-bar presenter accepts ArchiveHls (4), but destroys its
	 * own GameObject when the same archive is routed through StreamingIarc
	 * (5).  The rest of Initialize only binds the common play-position model,
	 * so expose type 4 during this synchronous entrance check and restore the
	 * real type immediately afterwards.
	 *
	 * Scope this to either the With×MEETS archive IARC route or the
	 * FesLiveConnect archive realtime-rendering route. No playback/controller
	 * state or entitlement value is changed.
	 */
	void *sceneModel = models
		? *reinterpret_cast<void **>(
			reinterpret_cast<uintptr_t>(models) + 0x20
		)
		: nullptr;
	void *enterModel = models
		? *reinterpret_cast<void **>(
			reinterpret_cast<uintptr_t>(models) + 0x28
		)
		: nullptr;
	int sceneType = sceneModel
		? *reinterpret_cast<int *>(
			reinterpret_cast<uintptr_t>(sceneModel) + 0x20
		)
		: -1;
	int *contentType = enterModel
		? reinterpret_cast<int *>(
			reinterpret_cast<uintptr_t>(enterModel) + 0x20
		)
		: nullptr;
	bool exposeWithArchiveSeekBar =
		configBool(@"WithMeets.Archive.MotionCaptureReplay.Enable") &&
		sceneType == 2 &&
		contentType &&
		*contentType == 5;
	bool exposeFesArchiveSeekBar =
		configBool(@"FesArchive.SeekBar.Enable") &&
		sceneType == 5 &&
		contentType &&
		*contentType == 5;
	bool exposeStockSeekBar =
		exposeWithArchiveSeekBar || exposeFesArchiveSeekBar;
	bool enableIarcFullSeek =
		exposeWithArchiveSeekBar &&
		lviWithArchiveIarcFullSeekEnabled();
	bool enablePlayPause =
		lviWithArchivePlayPauseButtonEnabled() &&
		sceneType == 2 &&
		contentType &&
		(*contentType == 4 || *contentType == 5);
	int originalContentType = contentType ? *contentType : -1;
	// Set this before the original initializer: ArchiveSeekBarView.SetSeekLimit
	// is called synchronously while the presenter is being initialized.
	if (enableIarcFullSeek) {
		lviActivateWithArchiveIarcFullSeek(models);
	}
	// Do not clear the active owner from the non-IARC branch.  The same model
	// collection may be re-initialized after its content type has temporarily
	// been exposed as the stock video type.  Exact-owner Dispose performs the
	// lifecycle clear.
	// The seek-bar presenter is initialized for ordinary HLS archives and for
	// IARC archives whose stock seek bar is retained by this tweak. Restrict
	// orientation ownership to With×MEETS (scene type 2).
	if (sceneType == 2) {
		lviActivateWithArchiveOrientationSession(
			models,
			"video-or-seekbar"
		);
	}
#if LVI_WM_DIAGNOSTIC
	if (exposeWithArchiveSeekBar) {
		lviRegisterWMClockDiagnosticSession(
			models,
			@"seekbar-initialize"
		);
	}
#endif
	if (enableIarcFullSeek &&
		!lviForceWithArchiveIarcFullPlayableLength(models)) {
		NSLog(
			@"[LinkuraVisualsIOS][WithArchive] Full playable-length "
			 "model repair is unavailable; stock end state remains."
		);
	}
	if (exposeStockSeekBar) {
		*contentType = 4;
	}
	original_VideoArchiveSeekBarPresenter_Initialize(
		self,
		models,
		methodInfo
	);
	if (exposeStockSeekBar) {
		*contentType = originalContentType;
		if (exposeFesArchiveSeekBar) {
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Enabled the stock "
				 "realtime-rendering archive seek bar."
			);
		} else {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] Enabled the stock "
				 "IARC archive seek bar."
			);
		}
	}
	// Bind only after stock initialization has attached its contents
	// controller. The button invokes the existing Play/Pause methods and never
	// invokes a restart-from-zero path, changes the seek position, or touches
	// end-state / REPLAY logic.
	if (enablePlayPause) {
		lviActivateWithArchivePlayPause(models);
	}
}

static void (*original_AlphaBlendCamera_UpdateCameras)(
	void *self,
	Unity::CCamera *newMainCamera,
	Unity::CCamera *newSubCamera,
	bool allowCameraEnabled,
	void *methodInfo
) = nullptr;

static void hooked_AlphaBlendCamera_UpdateCameras(
	void *self,
	Unity::CCamera *newMainCamera,
	Unity::CCamera *newSubCamera,
	bool allowCameraEnabled,
	void *methodInfo
) {
	original_AlphaBlendCamera_UpdateCameras(
		self,
		newMainCamera,
		newSubCamera,
		allowCameraEnabled,
		methodInfo
	);
	if (!lviWithMeetsArchiveCameraAdapterReady ||
		!lviWithArchiveIarcActive ||
		!self) {
		return;
	}

	if (lviWithArchiveBlendCameraOwner &&
		lviWithArchiveBlendCameraOwner != self) {
		lviClearCameraTarget(
			LVICameraScene::WithMeets,
			lviWithArchiveBlendCameraOwner
		);
	}
	lviWithArchiveBlendCameraOwner = self;
	if (!newMainCamera) {
		lviClearCameraTarget(LVICameraScene::WithMeets, self);
		return;
	}
	bool registered = lviRegisterCameraTarget(
		LVICameraScene::WithMeets,
		self,
		newMainCamera
	);
	if (!registered) {
		lviClearCameraTarget(LVICameraScene::WithMeets, self);
	}
}

static void (*original_AlphaBlendCamera_Dispose)(
	void *self,
	void *methodInfo
) = nullptr;

static void hooked_AlphaBlendCamera_Dispose(
	void *self,
	void *methodInfo
) {
	// AlphaBlendCamera owns the final IARC render camera.  Its Dispose is the
	// precise archive-camera lifetime boundary; LiveSystemModels.Dispose is not
	// guaranteed to run before the app navigates back to the archive list.
	if (self && self == lviWithArchiveBlendCameraOwner) {
		lviResetWithArchiveCameraAdapter();
	}
	original_AlphaBlendCamera_Dispose(self, methodInfo);
}

static void (*original_LiveSystemModels_Dispose)(
	void *self,
	void *methodInfo
) = nullptr;

static void hooked_LiveSystemModels_Dispose(
	void *self,
	void *methodInfo
) {
	// A validated AFTER admission bridge is intentionally single-scene and
	// single-model. Never let a pending player scope survive navigation away
	// from the exact archive player that created it.
	lviClearWithMeetsAfterPlayerAdmissionScope();
	bool releaseOrientation =
		lviBeginWithArchiveOrientationRelease(self);
	lviClearWithArchiveIarcFullSeek(self);
	// Disposal is the final scene boundary. Clear unconditionally here: a
	// duplicate presenter can replace the stored models pointer during archive
	// setup, and an owner mismatch must never leave this UIWindow-level button
	// visible over the archive list after navigation.
	lviClearWithArchivePlayPause();
	if (self && self == lviWithArchiveModelsOwner) {
		lviResetWithArchiveCameraAdapter();
	}
	if (lviFesArchiveCameraAdapterReady) {
		lviResetFesArchiveCameraAdapter();
	}
#if LVI_WM_DIAGNOSTIC
	lviEndWMClockDiagnosticSession(self);
#endif
	original_LiveSystemModels_Dispose(self, methodInfo);
	if (releaseOrientation) {
		lviFinishWithArchiveOrientationRelease();
	}
}

struct LVIFesCameraSlot {
	void *source = nullptr;
	Unity::CCamera *camera = nullptr;
};

static LVIFesCameraSlot lviFesCameraSlots[5];
static std::unordered_map<void*, LiveCameraType>
	lviFesFixedCameraTypeByOwner;
static void *lviFesCameraSwitcherOwner = nullptr;
static LiveCameraType lviFesSelectedCameraType = Undefined;
static bool lviFesCameraSessionActive = false;

static bool lviFesCameraTypeIsValid(LiveCameraType cameraType) {
	return cameraType >= Dynamic && cameraType <= SchoolIdle;
}

static void lviPublishSelectedFesCamera() {
	if (!lviFesArchiveCameraAdapterReady ||
		!lviFesCameraSessionActive ||
		!lviFesCameraSwitcherOwner ||
		!lviFesCameraTypeIsValid(lviFesSelectedCameraType)) {
		return;
	}
	const LVIFesCameraSlot& slot =
		lviFesCameraSlots[static_cast<int>(lviFesSelectedCameraType)];
	if (!slot.camera) {
		return;
	}
	if (!lviRegisterCameraTarget(
			LVICameraScene::FesArchive,
			lviFesCameraSwitcherOwner,
			slot.camera
		)) {
		lviClearCameraTarget(
			LVICameraScene::FesArchive,
			lviFesCameraSwitcherOwner
		);
	}
}

static void lviCacheFesCamera(
	LiveCameraType cameraType,
	void *source,
	Unity::CCamera *camera
) {
	if (!lviFesCameraTypeIsValid(cameraType) || !source || !camera) {
		return;
	}
	lviFesCameraSlots[static_cast<int>(cameraType)] = { source, camera };
	if (lviFesCameraSessionActive &&
		cameraType == lviFesSelectedCameraType) {
		lviPublishSelectedFesCamera();
	}
}

static void lviResetFesArchiveCameraAdapter() {
	lviClearCameraTarget(LVICameraScene::FesArchive, nullptr);
	for (LVIFesCameraSlot& slot : lviFesCameraSlots) {
		slot = LVIFesCameraSlot {};
	}
	lviFesFixedCameraTypeByOwner.clear();
	lviFesCameraSwitcherOwner = nullptr;
	lviFesSelectedCameraType = Undefined;
	lviFesCameraSessionActive = false;
}

static Unity::CCamera* (*original_FesLiveFixedCamera_GetCamera)(
	void *self,
	void *methodInfo
) = nullptr;

static Unity::CCamera* hooked_FesLiveFixedCamera_GetCamera(
	void *self,
	void *methodInfo
) {
	Unity::CCamera *camera =
		original_FesLiveFixedCamera_GetCamera(self, methodInfo);
	auto cameraType = lviFesFixedCameraTypeByOwner.find(self);
	if (cameraType != lviFesFixedCameraTypeByOwner.end()) {
		lviCacheFesCamera(cameraType->second, self, camera);
	}
	return camera;
}

static Unity::CCamera* (*original_IdolTargetingCamera_GetCamera)(
	void *self,
	void *methodInfo
) = nullptr;

static Unity::CCamera* hooked_IdolTargetingCamera_GetCamera(
	void *self,
	void *methodInfo
) {
	Unity::CCamera *camera =
		original_IdolTargetingCamera_GetCamera(self, methodInfo);
	lviCacheFesCamera(SchoolIdle, self, camera);
	return camera;
}

static void (*original_FesLiveCameraSwitcher_SwitchCamera)(
	void *self,
	LiveCameraType cameraType,
	void *methodInfo
) = nullptr;

static void hooked_FesLiveCameraSwitcher_SwitchCamera(
	void *self,
	LiveCameraType cameraType,
	void *methodInfo
) {
	if (lviFesArchiveCameraAdapterReady &&
		configBool(@"FesArchive.CameraControl.Enable") &&
		self &&
		lviFesCameraTypeIsValid(cameraType)) {
		if (lviFesCameraSwitcherOwner &&
			lviFesCameraSwitcherOwner != self) {
			lviResetFesArchiveCameraAdapter();
		}
		lviClearCameraTarget(LVICameraScene::FesArchive, nullptr);
		lviFesCameraSwitcherOwner = self;
		lviFesSelectedCameraType = cameraType;
		lviFesCameraSessionActive = true;
	}
	original_FesLiveCameraSwitcher_SwitchCamera(
		self,
		cameraType,
		methodInfo
	);
	lviPublishSelectedFesCamera();
}

static void (*original_FesLiveCameraSwitcher_Dispose)(
	void *self,
	void *methodInfo
) = nullptr;

static void hooked_FesLiveCameraSwitcher_Dispose(
	void *self,
	void *methodInfo
) {
	if (self && self == lviFesCameraSwitcherOwner) {
		lviResetFesArchiveCameraAdapter();
	}
	original_FesLiveCameraSwitcher_Dispose(self, methodInfo);
}

static Unity::CCamera* (*original_DynamicCamera_GetCamera)(
	void *self,
	void *methodInfo
) = nullptr;

static Unity::CCamera* hooked_DynamicCamera_GetCamera(
	void *self,
	void *methodInfo
) {
	Unity::CCamera *camera =
		original_DynamicCamera_GetCamera(self, methodInfo);
	if (lviFesCameraSessionActive &&
		lviFesSelectedCameraType == Dynamic) {
		lviCacheFesCamera(Dynamic, self, camera);
	}
	if (!lviWithArchiveIarcActive &&
		lviWithMeetsCameraAdapterReady &&
		self &&
		self == lviWithDynamicCameraOwner) {
		bool registered = lviRegisterCameraTarget(
			LVICameraScene::WithMeets,
			self,
			camera
		);
		if (!registered) {
			lviClearCameraTarget(LVICameraScene::WithMeets, self);
		}
	}
	return camera;
}

static void (*original_DynamicCamera_Dispose)(
	void *self,
	void *methodInfo
) = nullptr;

static void hooked_DynamicCamera_Dispose(
	void *self,
	void *methodInfo
) {
	if (self &&
		lviFesCameraSlots[static_cast<int>(Dynamic)].source == self) {
		lviFesCameraSlots[static_cast<int>(Dynamic)] =
			LVIFesCameraSlot {};
		if (lviFesSelectedCameraType == Dynamic) {
			lviClearCameraTarget(LVICameraScene::FesArchive, nullptr);
		}
	}
	void *blendCamera = self
		? *reinterpret_cast<void **>(
			reinterpret_cast<uintptr_t>(self) + 0x10
		)
		: nullptr;
	if (lviWithArchiveIarcActive &&
		blendCamera &&
		blendCamera == lviWithArchiveBlendCameraOwner) {
		lviResetWithArchiveCameraAdapter();
	}
	if (self && self == lviWithDynamicCameraOwner) {
		lviClearCameraTarget(LVICameraScene::WithMeets, self);
		lviWithDynamicCameraOwner = nullptr;
	}
	original_DynamicCamera_Dispose(self, methodInfo);
}

struct LVIUniRxUnit {
	uint8_t value;
};

static void* (*original_WithLiveCameraFactory)(
	void *self,
	LVIUniRxUnit unit,
	void *methodInfo
) = nullptr;

static void* hooked_WithLiveCameraFactory(
	void *self,
	LVIUniRxUnit unit,
	void *methodInfo
) {
	void *dynamicCamera =
		original_WithLiveCameraFactory(self, unit, methodInfo);
	if (lviWithArchiveIarcActive) {
		if (lviWithDynamicCameraOwner) {
			lviClearCameraTarget(
				LVICameraScene::WithMeets,
				lviWithDynamicCameraOwner
			);
			lviWithDynamicCameraOwner = nullptr;
		}
		return dynamicCamera;
	}
	int sceneType = self
		? *reinterpret_cast<int *>(
			reinterpret_cast<uintptr_t>(self) + 0x14
		)
		: -1;
	if (lviWithMeetsCameraAdapterReady &&
		sceneType != 1 &&
		sceneType != 2) {
		if (lviWithDynamicCameraOwner) {
			lviClearCameraTarget(
				LVICameraScene::WithMeets,
				lviWithDynamicCameraOwner
			);
			lviWithDynamicCameraOwner = nullptr;
		}
		return dynamicCamera;
	}
	if (lviWithMeetsCameraAdapterReady &&
		configBool(@"WithMeets.CameraControl.Enable") &&
		dynamicCamera &&
		(sceneType == 1 || sceneType == 2)) {
		if (lviWithDynamicCameraOwner &&
			lviWithDynamicCameraOwner != dynamicCamera) {
			lviClearCameraTarget(
				LVICameraScene::WithMeets,
				lviWithDynamicCameraOwner
			);
		}
		lviWithDynamicCameraOwner = dynamicCamera;
		if (original_DynamicCamera_GetCamera) {
			Unity::CCamera *camera =
				original_DynamicCamera_GetCamera(dynamicCamera, nullptr);
			bool registered = lviRegisterCameraTarget(
				LVICameraScene::WithMeets,
				dynamicCamera,
				camera
			);
			if (!registered) {
				lviClearCameraTarget(
					LVICameraScene::WithMeets,
					dynamicCamera
				);
			}
		}
	}
	return dynamicCamera;
}

static NSString* replaceStoryLines(NSString *input, NSString *pattern) {
	if (!input || !pattern) {
		return input;
	}

	NSError *error = nil;
	NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern
																	 options:0
																	   error:&error];
	if (!regex || error) {
		NSLog(@"[LinkuraVisualsIOS][Story] Invalid pattern %@: %@", pattern, error);
		return input;
	}

	return [regex stringByReplacingMatchesInString:input
										 options:0
										   range:NSMakeRange(0, input.length)
									withTemplate:@""];
}
struct RefreshRate {
	uint32_t numerator;
	uint32_t denominator;
};
struct Resolution {
	int width;
	int height;
	RefreshRate refreshRate;
};
static_assert(sizeof(Resolution) == 16, "UnityEngine.Resolution ABI mismatch");
enum LiveAreaQuality { Low, Medium, High };
enum LiveScreenOrientation { Landscape, Portrait };

IL2CPP::CClass* get_GlobalInstance() {
	return IL2CPP::Helper::InvokeStaticMethod<IL2CPP::CClass*>(
		"Global",
		"get_Instance"
	);
}

IL2CPP::CClass* get_SaveData() {
	return get_GlobalInstance()->GetPropertyValue<IL2CPP::CClass*>("SaveData");
}

LiveAreaQuality get_RenderTextureQuality() {
	IL2CPP::CClass* saveData = get_SaveData();
	return saveData->GetPropertyValue<LiveAreaQuality>("RenderTextureQuality");
}

void set_RenderTextureQuality(LiveAreaQuality quality) {
	IL2CPP::CClass* saveData = get_SaveData();
	saveData->SetPropertyValue<LiveAreaQuality>("RenderTextureQuality", quality);
}

static bool inAlphaBlend = false;
static const float alphaBlendFactor = 2.0f/3.0f;

typedef Resolution (*OriginalGetResolution_t)(LiveAreaQuality quality, LiveScreenOrientation orientation);
static OriginalGetResolution_t original_GetResolution = nullptr;
Resolution hooked_GetResolution(LiveAreaQuality quality, LiveScreenOrientation orientation)
{
    Resolution customRes;
    int shortSide = 1080, longSide = 1920;
    switch (quality) {
        case Medium:
			shortSide = [qualityConfig[@"LiveStream.Quality.Medium.ShortSide"] intValue];
			longSide = floor(shortSide / 9.0f * 16.0f);
            break;
        case High:
			shortSide = [qualityConfig[@"LiveStream.Quality.High.ShortSide"] intValue];
			longSide = floor(shortSide / 9.0f * 16.0f);
            break;
        default:
			shortSide = [qualityConfig[@"LiveStream.Quality.Low.ShortSide"] intValue];
			longSide = floor(shortSide / 9.0f * 16.0f);
    }
	if (inAlphaBlend) {
		longSide = floor(longSide * alphaBlendFactor);
		shortSide = floor(shortSide * alphaBlendFactor);
	}
    switch (orientation) {
        case Landscape:
            customRes.width = longSide;
            customRes.height = shortSide;
            break;
        default:
            customRes.width = shortSide;
            customRes.height = longSide;
    }
    customRes.refreshRate.numerator = MAX(
		1,
		[qualityConfig[@"TargetFPS"] intValue]
	);
    customRes.refreshRate.denominator = 1;
    return customRes;
    // return original_GetResolution(quality, orientation);
}

// Inspix.AlphaBlendCamera.UpdateAlpha(float newAlpha)
static void (*original_AlphaBlendCamera_UpdateAlpha)(void *self, float newAlpha);
void hooked_AlphaBlendCamera_UpdateAlpha(void *self, float newAlpha) {
    if (newAlpha < 1.0f && !inAlphaBlend) {
		inAlphaBlend = true;
		set_RenderTextureQuality(get_RenderTextureQuality());
	} else if (newAlpha > 0.99f && inAlphaBlend) {
		inAlphaBlend = false;
		set_RenderTextureQuality(get_RenderTextureQuality());
	}
	original_AlphaBlendCamera_UpdateAlpha(self, newAlpha);
}

void loadConfig() {
	NSLog(@"[IL2CPP Tweak] Try load config");
    NSString *tweakName = @"LinkuraVisualsIOS";
    NSString *configFileName = [tweakName stringByAppendingString:@".json"];
    NSString *configPath = [getDylibDirectoryPath() stringByAppendingPathComponent:configFileName];
    
    NSError *error = nil;
    NSData *data = [NSData dataWithContentsOfFile:configPath options:0 error:&error];
    
    if (data && !error) {
        id jsonObject = [NSJSONSerialization JSONObjectWithData:data 
                                                      options:NSJSONReadingAllowFragments 
                                                        error:&error];
        
        if (jsonObject && !error && [jsonObject isKindOfClass:[NSDictionary class]]) {
            NSDictionary *config = (NSDictionary *)jsonObject;

			if (config) {
				[qualityConfig addEntriesFromDictionary:config];
				NSLog(@"[IL2CPP Tweak] Config loaded.");
			}
            
        } else {
            NSLog(@"[IL2CPP Tweak] ERROR: JSON parsing failed: %@", error);
        }
    } else {
        NSLog(@"[IL2CPP Tweak] ERROR: Could not read config file: %@", error);
    }
}

typedef void (*original_set_targetFrameRate_t)(int targetFrameRate);
static original_set_targetFrameRate_t original_set_targetFrameRate = nullptr;
void set_targetFrameRateInternal(int targetFrameRate) {
	IL2CPP::ResolveCall("UnityEngine.Application::set_targetFrameRate(System.Int32)");
}
void hooked_set_targetFrameRate(int targetFrameRate) {
    // set_targetFrameRateInternal([qualityConfig[@"TargetFPS"] intValue]);
	original_set_targetFrameRate([qualityConfig[@"TargetFPS"] intValue]);
}

typedef void (*original_set_antiAliasing_t)(int antiAliasing);
static original_set_antiAliasing_t original_set_antiAliasing = nullptr;
void set_antiAliasingInternal(int antiAliasing) {
	IL2CPP::ResolveCall("UnityEngine.QualitySettings::set_antiAliasing(System.Int32)");
}
void hooked_set_antiAliasing(int antiAliasing) {
    // set_antiAliasingInternal([qualityConfig[@"AntiAliasingSamples"] intValue]);
	original_set_antiAliasing([qualityConfig[@"AntiAliasingSamples"] intValue]);
}

typedef void (*original_fesLiveFixedCameraCtor_t)(void *self, IL2CPP::CClass* camera, IL2CPP::CClass* targetTexture, IL2CPP::CClass* setting, LiveCameraType cameraType);
static original_fesLiveFixedCameraCtor_t original_fesLiveFixedCameraCtor = nullptr;
void hooked_fesLiveFixedCameraCtor(void *self, IL2CPP::CClass* camera, IL2CPP::CClass* targetTexture, IL2CPP::CClass* setting, LiveCameraType cameraType) {
	if (setting) {
		setting->SetMemberValue<float>("moveRadiusLimit", 100000.0f);
		setting->SetMemberValue<float>("rotateAngleLimit", 360.0f);
		setting->SetMemberValue<float>("panSensitivity", 0.05f);
		setting->SetMemberValue<Unity::Vector2>(
			"fovRange",
			Unity::Vector2(10.0f, 150.0f)
		);
	}
	original_fesLiveFixedCameraCtor(
		self,
		camera,
		targetTexture,
		setting,
		cameraType
	);
	if (self && lviFesCameraTypeIsValid(cameraType)) {
		lviFesFixedCameraTypeByOwner[self] = cameraType;
		lviCacheFesCamera(
			cameraType,
			self,
			reinterpret_cast<Unity::CCamera*>(camera)
		);
	}
}

typedef void (*original_idolTargetingCamera_t)(void *self, IL2CPP::CClass* camera, IL2CPP::CClass* targetTexture, IL2CPP::CClass* setting);
static original_idolTargetingCamera_t original_idolTargetingCamera = nullptr;
void hooked_idolTargetingCamera(void *self, IL2CPP::CClass* camera, IL2CPP::CClass* targetTexture, IL2CPP::CClass* setting) {
	if (setting) {
		setting->SetMemberValue<float>("moveRadiusLimit", 100000.0f);
		setting->SetMemberValue<float>("rotateAngleLimit", 360.0f);
		setting->SetMemberValue<float>("panSensitivity", 0.05f);
		setting->SetMemberValue<Unity::Vector2>(
			"fovRange",
			Unity::Vector2(10.0f, 150.0f)
		);
	}
	original_idolTargetingCamera(self, camera, targetTexture, setting);
	lviCacheFesCamera(
		SchoolIdle,
		self,
		reinterpret_cast<Unity::CCamera*>(camera)
	);
}

struct RenderTextureDescriptor {
	int width;
	int height;
	int msaaSamples;
	int volumeDepth;
	int mipCount;
	int graphicsFormat; // enum GraphicsFormat
	int stencilFormat; // enum GraphicsFormat
	int depthStencilFormat; // enum GraphicsFormat
	int dimension; // enum TextureDimension
	int shadowSamplingMode; // enum ShadowSamplingMode
	int vrUsage; // enum VRTexureUsage
	int flags; // enum RenderTextureCreationFlags
	int memoryless; // enum RenderTextureMemoryless
};

struct CameraData {
	float m_ViewMatrix[16];
	float m_ProjectionMatrix[16];
	float m_JitterMatrix[16];
	Unity::CCamera* m_Camera;
	int renderType; // enum CameraRenderType
	IL2CPP::CClass* targetTexture;
	RenderTextureDescriptor cameraTargetDescriptor;
	float pixelRect[4];
	bool useScreenCoordOverride;
	Unity::Vector4 screenSizeOverride;
	Unity::Vector4 screenCoordScaleBias;
	int pixelWidth;
	int pixelHeight;
	float aspectRatio;
	float renderScale;
	int imageScalingMode; // enum ImageScalingMode
	int upscalingFilter; // enum ImageUpscalingFilter
	bool fsrOverrideSharpness;
	float fsrSharpness;
	int hdrColorBufferPrecision; // enum HDRColorBufferPrecision
	bool clearDepth;
	int cameraType; // enum CameraType
	bool isDefaultViewport;
	bool isHdrEnabled;
	bool allowHDROutput;
	bool requiresDepthTexture;
	bool requiresOpaqueTexture;
	bool postProcessingRequiresDepthTexture;
	bool xrRendering;
	bool stackLastCameraOutputToHDR;
	int defaultOpaqueSortFlags; // enum SortingCriteria
	bool isStereoEnabled;
	float maxShadowDistance;
	bool postProcessEnabled;
	bool stackAnyPostProcessingEnabled;
	IL2CPP::CClass* captureActions; // IEnumerator<Action<RenderTargetIdentifier, CommandBuffer>>
	int volumeLayerMask; // struct LayerMask
	IL2CPP::CClass* volumeTrigger;
	bool isStopNaNEnabled;
	bool isDitheringEnabled;
	int antialiasing; // enum AntialiasingMode
	int antialiasingQuality; // enum AntialiasingQuality
	IL2CPP::CClass* renderer; // ScriptableRenderer
	bool resolveFinalTarget;
	Unity::Vector3 worldSpaceCameraPos;
	Unity::Color backgroundColor;
	IL2CPP::CClass* taaPersistentData; // TaaPersistentData
	int taaSettings; // enum TemporalAA.Settings
	Unity::CCamera* baseCamera;
};

// void UnityEngine.Rendering.Universal.UniversalRenderPipeline.InitializeStackedCameraData(Camera* camera, UniversalAdditionalCameraData* additionalCameraData, CameraData* cameraData)
static void (*original_InitializeStackedCameraData)(Unity::CCamera*, IL2CPP::CClass*, CameraData*) = nullptr;
void hooked_InitializeStackedCameraData(Unity::CCamera* camera, IL2CPP::CClass* additionalCameraData, CameraData* cameraData) {
	Unity::System_String* cameraName = camera->GetName();
	if (!cameraName) {
		original_InitializeStackedCameraData(camera, additionalCameraData, cameraData);
		return;
	}
	NSString* nsCameraName = cameraName->ToNSString();
	
	if (!nsCameraName || ![nsCameraName hasPrefix:@"StoryCamera"]) {
		original_InitializeStackedCameraData(camera, additionalCameraData, cameraData);
		return;
	}

	IL2CPP::CClass* targetTexture = camera->GetPropertyValue<IL2CPP::CClass*>("targetTexture");
	if (!targetTexture) {
		original_InitializeStackedCameraData(camera, additionalCameraData, cameraData);
		return;
	}

	int width = targetTexture->GetPropertyValue<int>("width");
	int height = targetTexture->GetPropertyValue<int>("height");

	float storyFactor = 1.0f;
	switch (get_RenderTextureQuality()) {
		case Low:
			storyFactor = [qualityConfig[@"Story.Quality.Low.Factor"] floatValue];
			break;
		case Medium:
			storyFactor = [qualityConfig[@"Story.Quality.Medium.Factor"] floatValue];
			break;
		default:
			storyFactor = [qualityConfig[@"Story.Quality.High.Factor"] floatValue];
	}

	if ([qualityConfig[@"Enable.AntiAliasingHook"] boolValue]) {
		targetTexture->SetPropertyValue<int>("antiAliasing", [qualityConfig[@"AntiAliasingSamples"] intValue]);
	}

	if (![qualityConfig[@"Story.Quality.FSRUpscaling.Enable"] boolValue]) {
		targetTexture->SetPropertyValue<int>("width", floor(width * storyFactor));
		targetTexture->SetPropertyValue<int>("height", floor(height * storyFactor));
	}
	
	original_InitializeStackedCameraData(camera, additionalCameraData, cameraData);

	if ([qualityConfig[@"Story.Quality.FSRUpscaling.Enable"] boolValue]) {
		cameraData->renderScale = storyFactor;
		if (storyFactor > 1.0f) {
			cameraData->imageScalingMode = 2;
		} else {
			cameraData->imageScalingMode = 0;
		}
	}
}

typedef RenderTextureDescriptor (*original_CreateRenderTextureDescriptor_t)(Unity::CCamera* camera, float renderScale, bool isHdrEnabled, int msaaSamples, bool needsAlpha, bool requiresOpaqueTexture);
static original_CreateRenderTextureDescriptor_t original_CreateRenderTextureDescriptor = nullptr;
RenderTextureDescriptor hooked_CreateRenderTextureDescriptor(Unity::CCamera* camera, float renderScale, bool isHdrEnabled, int msaaSamples, bool needsAlpha, bool requiresOpaqueTexture)
{
	Unity::System_String* cameraName = camera->GetName();
	if (!cameraName) {
		return original_CreateRenderTextureDescriptor(camera, renderScale, isHdrEnabled, msaaSamples, needsAlpha, requiresOpaqueTexture);
	}
	NSString* nsCameraName = cameraName->ToNSString();
	
	if (nsCameraName && [nsCameraName hasPrefix:@"StoryCamera"]) {
		IL2CPP::CClass* targetTexture = camera->GetPropertyValue<IL2CPP::CClass*>("targetTexture");
		if (targetTexture) {
			int width = targetTexture->GetPropertyValue<int>("width");
			int height = targetTexture->GetPropertyValue<int>("height");
			if (width && height) {
				float storyFactor = 1.0f;
				switch (get_RenderTextureQuality()) {
					case Low:
						storyFactor = [qualityConfig[@"Story.Quality.Low.Factor"] floatValue];
						break;
					case Medium:
						storyFactor = [qualityConfig[@"Story.Quality.Medium.Factor"] floatValue];
						break;
					default:
						storyFactor = [qualityConfig[@"Story.Quality.High.Factor"] floatValue];
				}

				targetTexture->SetPropertyValue<int>("width", floor(width * storyFactor));
				targetTexture->SetPropertyValue<int>("height", floor(height * storyFactor));
				targetTexture->SetPropertyValue<int>("antiAliasing", [qualityConfig[@"AntiAliasingSamples"] intValue]);
			}
		}
	}
	return original_CreateRenderTextureDescriptor(camera, renderScale, isHdrEnabled, msaaSamples, needsAlpha, requiresOpaqueTexture);
}

typedef void (*original_MagicaManager_SetSimulationFrequency_t)(int frequency);
original_MagicaManager_SetSimulationFrequency_t original_MagicaManager_SetSimulationFrequency = nullptr;
void hooked_MagicaManager_SetSimulationFrequency(int frequency)
{
	original_MagicaManager_SetSimulationFrequency([qualityConfig[@"MagicaCloth.SimulationFrequency"] intValue]);
}

typedef void (*original_MagicaManager_SetMaxSimulationCountPerFrame_t)(int count);
static original_MagicaManager_SetMaxSimulationCountPerFrame_t original_MagicaManager_SetMaxSimulationCountPerFrame = nullptr;
void hooked_MagicaManager_SetMaxSimulationCountPerFrame(int count)
{
	original_MagicaManager_SetMaxSimulationCountPerFrame([qualityConfig[@"MagicaCloth.MaxSimulationCountPerFrame"] intValue]);
}

typedef void (*original_FesLiveSettingsView_InitButtons_t)(void* self);
static original_FesLiveSettingsView_InitButtons_t original_FesLiveSettingsView_InitButtons = nullptr;
void hooked_FesLiveSettingsView_InitButtons(void* self) { 
	original_FesLiveSettingsView_InitButtons(self);

	IL2CPP::CClass* pSelf = reinterpret_cast<IL2CPP::CClass*>(self);

	IL2CPP::CClass* qualityLowRadioButton = pSelf->GetMemberValue<IL2CPP::CClass*>("qualityLowRadioButton");
	IL2CPP::CClass* qualityMiddleRadioButton = pSelf->GetMemberValue<IL2CPP::CClass*>("qualityMiddleRadioButton");
	IL2CPP::CClass* qualityHighRadioButton = pSelf->GetMemberValue<IL2CPP::CClass*>("qualityHighRadioButton");

	qualityLowRadioButton->GetMemberValue<IL2CPP::CClass*>("label")->SetPropertyValue<Unity::System_String*>("text", IL2CPP::String::New(
		[[NSString stringWithFormat:@"%dp\n%.2fx", 
			[qualityConfig[@"LiveStream.Quality.Low.ShortSide"] intValue],
			[qualityConfig[@"Story.Quality.Low.Factor"] floatValue]
			] UTF8String]
	));
	qualityMiddleRadioButton->GetMemberValue<IL2CPP::CClass*>("label")->SetPropertyValue<Unity::System_String*>("text", IL2CPP::String::New(
		[[NSString stringWithFormat:@"%dp\n%.2fx", 
			[qualityConfig[@"LiveStream.Quality.Medium.ShortSide"] intValue],
			[qualityConfig[@"Story.Quality.Medium.Factor"] floatValue]
			] UTF8String]
	));
	qualityHighRadioButton->GetMemberValue<IL2CPP::CClass*>("label")->SetPropertyValue<Unity::System_String*>("text", IL2CPP::String::New(
		[[NSString stringWithFormat:@"%dp\n%.2fx", 
			[qualityConfig[@"LiveStream.Quality.High.ShortSide"] intValue],
			[qualityConfig[@"Story.Quality.High.Factor"] floatValue]
			] UTF8String]
	));
}

/*
 * Fes archive valid-ticket compatibility repair.
 *
 * The static 5.1.0 API replacement can return a 5.0.1-compatible archive
 * object without the user-specific ticket fields. The 5.0.1 and 5.1.0
 * model/enum layouts are otherwise identical. The repair is active only
 * while FesConnectModelsFactory creates the archive CameraSelectModel.
 * It repairs the exact Dynamic-only placeholder in the archive response
 * cache before the model reads it. AFTER admission, purchase state, and
 * non-archive responses are not changed.
 *
 * Enable this only for a ticket the user already owns.
 */
static NSArray<NSNumber*>* configuredFesArchiveCameraTypes() {
	id configured = qualityConfig[@"FesArchive.ValidTicketRepair.SelectableCameraTypes"];
	if (![configured isKindOfClass:[NSArray class]]) {
		return @[];
	}

	NSMutableArray<NSNumber*> *valid = [NSMutableArray array];
	NSMutableSet<NSNumber*> *seen = [NSMutableSet set];
	for (id value in (NSArray*)configured) {
		if (![value respondsToSelector:@selector(intValue)]) {
			continue;
		}
		int cameraType = [value intValue];
		if (cameraType < Dynamic || cameraType > SchoolIdle) {
			continue;
		}
		NSNumber *number = @(cameraType);
		if (![seen containsObject:number]) {
			[seen addObject:number];
			[valid addObject:number];
		}
	}
	return valid;
}

static int configuredFesArchiveTicketRank() {
	int configuredRank = [qualityConfig[@"FesArchive.ValidTicketRepair.TicketRank"] intValue];
	if (configuredRank < 1 || configuredRank > 7) {
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Invalid configured ticket rank %d.",
			configuredRank
		);
		return 0;
	}
	return configuredRank;
}

static IL2CPP::CClass* createConfiguredFesArchiveCameraTypes() {
	NSArray<NSNumber*> *configuredTypes = configuredFesArchiveCameraTypes();
	if (configuredTypes.count == 0) {
		NSLog(@"[LinkuraVisualsIOS][FesArchive] No valid camera types configured; keeping the API value.");
		return nullptr;
	}

	Unity::il2cppClass *cameraTypeClass =
		IL2CPP::Class::Find("Org.OpenAPITools.Model.LiveCameraType");
	if (!cameraTypeClass) {
		NSLog(@"[LinkuraVisualsIOS][FesArchive] LiveCameraType metadata was not found.");
		return nullptr;
	}

	Unity::il2cppArray<int> *cameraTypes =
		Unity::il2cppArray<int>::Create(cameraTypeClass, configuredTypes.count);
	if (!cameraTypes) {
		NSLog(@"[LinkuraVisualsIOS][FesArchive] Failed to allocate the archive camera array.");
		return nullptr;
	}

	for (NSUInteger index = 0; index < configuredTypes.count; ++index) {
		(*cameraTypes)[index] = configuredTypes[index].intValue;
	}
	return reinterpret_cast<IL2CPP::CClass*>(cameraTypes);
}

static int repairFesArchiveTicketRank(int originalValue) {
	if (!configBool(@"FesArchive.ValidTicketRepair.Enable")) {
		return originalValue;
	}

	int configuredRank = configuredFesArchiveTicketRank();
	if (configuredRank == 0) {
		return originalValue;
	}

	// Preserve an S/E (or other explicit) server rank. Only fill a missing
	// value or the static guest placeholder from the user's configuration.
	return originalValue <= 1 ? configuredRank : originalValue;
}

/*
 * The static archive database can contain an exact [DynamicView] placeholder
 * even when TicketRank is already S. Preserve every other camera combination.
 */
static bool hasOnlyDynamicCameraType(IL2CPP::CClass* allowedCameraTypes) {
	if (!allowedCameraTypes) {
		return false;
	}

	void *getCount = allowedCameraTypes->GetMethodPointer("get_Count", 0);
	void *getItem = allowedCameraTypes->GetMethodPointer("get_Item", 1);
	if (!getCount || !getItem) {
		return false;
	}

	int count = allowedCameraTypes->CallMethodSafe<int>(getCount);
	if (count != 1) {
		return false;
	}
	return allowedCameraTypes->CallMethodSafe<int, int>(getItem, 0) == Dynamic;
}

static bool isFesArchiveRepairCandidateRank(int ticketRank) {
	int configuredRank = configuredFesArchiveTicketRank();
	if (configuredRank == 0) {
		return false;
	}

	// 0/Guest are the missing/static placeholder values. The configured rank
	// and E are also accepted because the observed defect is S + [Dynamic].
	return ticketRank <= 1 || ticketRank == configuredRank || ticketRank == 7;
}

static bool configuredFesArchiveCameraTypesContain(int cameraType) {
	if (cameraType == Undefined) {
		return true;
	}
	return [configuredFesArchiveCameraTypes() containsObject:@(cameraType)];
}

static bool replaceManagedFesArchiveCameraTypeList(IL2CPP::CClass* cameraTypes) {
	if (!cameraTypes) {
		return false;
	}

	NSArray<NSNumber*> *configuredTypes = configuredFesArchiveCameraTypes();
	if (configuredTypes.count == 0) {
		return false;
	}

	void *clear = cameraTypes->GetMethodPointer("Clear", 0);
	void *add = cameraTypes->GetMethodPointer("Add", 1);
	void *getCount = cameraTypes->GetMethodPointer("get_Count", 0);
	void *getItem = cameraTypes->GetMethodPointer("get_Item", 1);
	if (!clear || !add || !getCount || !getItem) {
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Managed camera list methods "
			 "were not resolved; keeping the cached response unchanged."
		);
		return false;
	}

	cameraTypes->CallMethodSafe<void>(clear);
	for (NSNumber *cameraType in configuredTypes) {
		cameraTypes->CallMethodSafe<void, int>(add, cameraType.intValue);
	}

	int count = cameraTypes->CallMethodSafe<int>(getCount);
	if (count != (int)configuredTypes.count) {
		cameraTypes->CallMethodSafe<void>(clear);
		cameraTypes->CallMethodSafe<void, int>(add, Dynamic);
		return false;
	}
	for (int index = 0; index < count; ++index) {
		int actual = cameraTypes->CallMethodSafe<int, int>(getItem, index);
		if (actual != configuredTypes[(NSUInteger)index].intValue) {
			cameraTypes->CallMethodSafe<void>(clear);
			cameraTypes->CallMethodSafe<void, int>(add, Dynamic);
			return false;
		}
	}
	return true;
}

/*
 * Fes 2025-12-28 is present in the static 5.1.0 archive data in both forms:
 * an ALST/IARC .md motion archive and a fixed HLS video.  The stock 5.0.1
 * selector reads the response backing fields directly and chooses the HLS
 * route while VideoUrl remains non-null.
 *
 * 0.8.10 hooked get_VideoUrl and then read the bare "VideoUrl" member from
 * inside that hook.  The actual field is named
 * "<VideoUrl>k__BackingField"; the resolver therefore fell back to the
 * hooked property getter and recursed until the stack was exhausted.  The
 * failure occurred before the A/S confirmation and affected every Fes
 * archive, including the otherwise-working 2026-03-30 entry.
 *
 * Keep this route repair on one ordinary, archive-specific object boundary:
 * FesArchiveEnterResponseCache::.ctor.  On this exact binary the stock
 * constructor has already resolved and stored Value when it returns.  Read
 * only exact backing fields.  If the response already contains the verified
 * 12/28 HLS/.md pair, clear VideoUrl through its stock setter.  The observed
 * 5.0.1-compatible response can instead contain only the same exact HLS URL;
 * in that case require the independently verified JSON mapping, fill the
 * missing ArchiveUrl through its stock write-barrier setter, verify the
 * stored value, and only then clear VideoUrl.  Do not hook either eight-byte
 * getter, do not traverse the global content selector, and do not alter
 * timelines, ticket data, or camera lists here.  A non-empty unexpected
 * ArchiveUrl, an unknown HLS URL, and 2026-03-30 therefore retain their stock
 * response byte-for-byte.
 */
static NSString *const kLVIFesArchive1228HLSURL =
	@"https://assets.link-like-lovelive.app/archive/hls/20251228/index.m3u8";
static NSString *const kLVIFesArchive1228MotionURL =
	@"https://assets.link-like-lovelive.app/archive/alst/"
	 "20251228195000-5f0cc1ec-e91e-4287-9263-0327686c0b07/"
	 "811c9dc5a5f86.md";

static NSString* lviConfiguredVerifiedFesArchive1228MotionURL() {
	id configured =
		qualityConfig[@"FesArchive.MotionCaptureReplay.UrlMap"];
	if (![configured isKindOfClass:[NSDictionary class]]) {
		return nil;
	}

	id candidate =
		((NSDictionary*)configured)[kLVIFesArchive1228HLSURL];
	if (![candidate isKindOfClass:[NSString class]] ||
		![(NSString*)candidate
			isEqualToString:kLVIFesArchive1228MotionURL]) {
		return nil;
	}
	// The external config acts only as an exact-match permit.  Store the
	// immutable built-in URL so a mutable config object cannot change after
	// validation and before IL2CPP::String::New copies it.
	return kLVIFesArchive1228MotionURL;
}

typedef void (*original_FesArchiveEnterResponseCacheCtor_t)(
	void *self,
	void *scope,
	void *methodInfo
);
static original_FesArchiveEnterResponseCacheCtor_t
	original_FesArchiveEnterResponseCache_ctor = nullptr;

static IL2CPP::CClass* lviFesArchiveResponseFromEnterCache(
	void *cacheSelf
) {
	IL2CPP::CClass *cache =
		reinterpret_cast<IL2CPP::CClass*>(cacheSelf);
	if (!lviManagedObjectIsExactClass(
		cache,
		"School.LiveMain",
		"FesArchiveEnterResponseCache"
	)) {
		return nullptr;
	}

	IL2CPP::CClass *response = nullptr;
	if (!lviReadExactInstanceField(cache, "Value", response) ||
		!lviManagedObjectIsExactClass(
			response,
			"Org.OpenAPITools.Model",
			"GetFesArchiveDataResponse"
		)) {
		return nullptr;
	}
	return response;
}

static bool lviPrepareExactFesArchive1228MotionResponse(
	IL2CPP::CClass *response
) {
	if (!configBool(@"FesArchive.MotionCaptureReplay.Enable") ||
		!lviManagedObjectIsExactClass(
			response,
			"Org.OpenAPITools.Model",
			"GetFesArchiveDataResponse"
		)) {
		return false;
	}

	Unity::System_String *archiveUrl = nullptr;
	Unity::System_String *videoUrl = nullptr;
	if (!lviReadExactInstanceField(
			response,
			"<ArchiveUrl>k__BackingField",
			archiveUrl
		) ||
		!lviReadExactInstanceField(
			response,
			"<VideoUrl>k__BackingField",
			videoUrl
		) ||
		!videoUrl) {
		return false;
	}

	// This must remain a raw value comparison.  Canonicalizing would also
	// accept query/fragment variants that have not been independently
	// verified for the static 5.1.0 mapping.
	NSString *videoURL = videoUrl->ToNSString();
	if (![videoURL isEqualToString:kLVIFesArchive1228HLSURL]) {
		return false;
	}

	NSString *archiveURL =
		archiveUrl && archiveUrl->ToLength() > 0
			? archiveUrl->ToNSString()
			: nil;
	bool archiveAlreadyVerified =
		[archiveURL isEqualToString:kLVIFesArchive1228MotionURL];
	bool archiveMissing = archiveURL.length == 0;
	if (!archiveAlreadyVerified && !archiveMissing) {
		return false;
	}

	void *setArchiveUrl =
		response->GetMethodPointer("set_ArchiveUrl", 1);
	void *setVideoUrl = response->GetMethodPointer("set_VideoUrl", 1);
	if (!setArchiveUrl || !setVideoUrl) {
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Exact 2025-12-28 response "
			 "matched, but a stock URL setter was unavailable; "
			 "keeping the fixed-video route."
		);
		return false;
	}

	if (archiveMissing) {
		NSString *mappedURL =
			lviConfiguredVerifiedFesArchive1228MotionURL();
		if (!mappedURL) {
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Exact 2025-12-28 HLS "
				 "matched, but the verified JSON mapping was unavailable; "
				 "keeping the fixed-video route."
			);
			return false;
		}

		Unity::System_String *managedArchiveURL =
			IL2CPP::String::New([mappedURL UTF8String]);
		if (!managedArchiveURL) {
			return false;
		}
		response->CallMethodSafe<void, Unity::System_String*>(
			setArchiveUrl,
			managedArchiveURL
		);

		Unity::System_String *storedArchiveUrl = nullptr;
		if (!lviReadExactInstanceField(
				response,
				"<ArchiveUrl>k__BackingField",
				storedArchiveUrl
			) ||
			!storedArchiveUrl ||
			![storedArchiveUrl->ToNSString()
				isEqualToString:kLVIFesArchive1228MotionURL]) {
			response->CallMethodSafe<void, Unity::System_String*>(
				setArchiveUrl,
				archiveUrl
			);
			Unity::System_String *rolledBackArchiveUrl =
				reinterpret_cast<Unity::System_String*>(1);
			bool rollbackVerified =
				lviReadExactInstanceField(
					response,
					"<ArchiveUrl>k__BackingField",
					rolledBackArchiveUrl
				) &&
				rolledBackArchiveUrl == archiveUrl;
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Exact 2025-12-28 "
				 "ArchiveUrl repair did not persist; rollback %@.",
				rollbackVerified ? @"verified" : @"could not be verified"
			);
			return false;
		}
	}

	response->CallMethodSafe<void, Unity::System_String*>(
		setVideoUrl,
		nullptr
	);

	Unity::System_String *storedVideoUrl =
		reinterpret_cast<Unity::System_String*>(1);
	if (!lviReadExactInstanceField(
			response,
			"<VideoUrl>k__BackingField",
			storedVideoUrl
		) ||
		storedVideoUrl != nullptr) {
		response->CallMethodSafe<void, Unity::System_String*>(
			setVideoUrl,
			videoUrl
		);
		if (archiveMissing) {
			response->CallMethodSafe<void, Unity::System_String*>(
				setArchiveUrl,
				archiveUrl
			);
		}

		Unity::System_String *rolledBackVideoUrl = nullptr;
		Unity::System_String *rolledBackArchiveUrl = nullptr;
		bool videoRollbackVerified =
			lviReadExactInstanceField(
				response,
				"<VideoUrl>k__BackingField",
				rolledBackVideoUrl
			) &&
			rolledBackVideoUrl == videoUrl;
		bool archiveRollbackVerified =
			!archiveMissing ||
			(lviReadExactInstanceField(
				response,
				"<ArchiveUrl>k__BackingField",
				rolledBackArchiveUrl
			) &&
			rolledBackArchiveUrl == archiveUrl);
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Exact 2025-12-28 response "
			 "matched, but VideoUrl clearing could not be verified; "
			 "rollback %@.",
			videoRollbackVerified && archiveRollbackVerified
				? @"verified"
				: @"could not be verified"
		);
		return false;
	}

	static bool loggedExactCacheRepair = false;
	if (!loggedExactCacheRepair) {
		loggedExactCacheRepair = true;
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Exact 2025-12-28 motion "
			 "route prepared at the Fes response-cache boundary "
			 "(ArchiveUrl %@).",
			archiveMissing ? @"repaired from verified mapping" : @"verified"
		);
	}
	return true;
}

static void hooked_FesArchiveEnterResponseCache_ctor(
	void *self,
	void *scope,
	void *methodInfo
) {
	if (original_FesArchiveEnterResponseCache_ctor) {
		original_FesArchiveEnterResponseCache_ctor(
			self,
			scope,
			methodInfo
		);
	}

	IL2CPP::CClass *response =
		lviFesArchiveResponseFromEnterCache(self);
	if (!response) {
		static bool loggedMissingCacheValue = false;
		if (!loggedMissingCacheValue) {
			loggedMissingCacheValue = true;
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Response-cache Value "
				 "was unavailable after construction; preserving the "
				 "stock route."
			);
		}
		return;
	}
	lviPrepareExactFesArchive1228MotionResponse(response);
}

static bool managedStringsHaveEqualValue(
	Unity::System_String* left,
	Unity::System_String* right
) {
	if (left == right) {
		return true;
	}
	if (!left || !right) {
		return false;
	}
	NSString *leftValue = left->ToNSString();
	NSString *rightValue = right->ToNSString();
	return [leftValue isEqualToString:rightValue];
}

static bool configuredFesArchiveTargetAllows(
	Unity::System_String *liveId
) {
	id configured =
		qualityConfig[@"FesArchive.ValidTicketRepair.TargetArchiveIds"];
	if (!liveId ||
		![configured isKindOfClass:[NSArray class]] ||
		[(NSArray*)configured count] == 0) {
		return false;
	}
	NSString *liveIdValue = liveId->ToNSString();
	for (id candidate in (NSArray*)configured) {
		if ([candidate isKindOfClass:[NSString class]] &&
			[(NSString*)candidate isEqualToString:liveIdValue]) {
			return true;
		}
	}
	return false;
}

static thread_local bool fesArchiveTargetAllowed = false;

/*
 * FesConnectModelsFactory owns the archive-only response cache. Repairing its
 * retained List<LiveCameraType> makes every later consumer, including the UI
 * node IsAllowed calculation, observe the same valid-ticket camera set.
 */
static bool repairFesArchiveResponseCache(void* factorySelf) {
	if (!configBool(@"FesArchive.ValidTicketRepair.Enable") ||
		!fesArchiveTargetAllowed ||
		!factorySelf) {
		return false;
	}

	IL2CPP::CClass *factory = reinterpret_cast<IL2CPP::CClass*>(factorySelf);
	IL2CPP::CClass *cache =
		factory->GetMemberValue<IL2CPP::CClass*>("_enterResponseCache");
	IL2CPP::CClass *response =
		cache ? cache->GetMemberValue<IL2CPP::CClass*>("Value") : nullptr;
	IL2CPP::CClass *cameraTypes =
		response
			? response->GetMemberValue<IL2CPP::CClass*>("SelectableCameraTypes")
			: nullptr;
	if (!response || !hasOnlyDynamicCameraType(cameraTypes)) {
		return false;
	}

	int ticketRank = response->GetMemberValue<int>("TicketRank");
	int currentCameraType = response->GetMemberValue<int>("CurrentCameraType");
	if (!isFesArchiveRepairCandidateRank(ticketRank) ||
		!configuredFesArchiveCameraTypesContain(currentCameraType)) {
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Dynamic-only cache was not "
			 "repaired (rank=%d, currentCameraType=%d).",
			ticketRank,
			currentCameraType
		);
		return false;
	}

	if (!replaceManagedFesArchiveCameraTypeList(cameraTypes)) {
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Failed to replace the "
			 "Dynamic-only cached camera list."
		);
		return false;
	}

	int repairedRank = repairFesArchiveTicketRank(ticketRank);
	if (repairedRank != ticketRank) {
		response->SetMemberValue<int>("TicketRank", repairedRank);
	}
	if (currentCameraType == Undefined &&
		configuredFesArchiveCameraTypesContain(Dynamic)) {
		response->SetMemberValue<int>("CurrentCameraType", Dynamic);
	}

	static bool loggedCacheRepair = false;
	if (!loggedCacheRepair) {
		loggedCacheRepair = true;
		NSLog(
			@"[LinkuraVisualsIOS][FesArchive] Repaired the archive response "
			 "cache (rank %d -> %d, camera types [1,2,3,4]).",
			ticketRank,
			repairedRank
		);
	}
	return true;
}

/*
 * CameraSelectModel native ABI for iOS 5.0.1:
 *   self, liveId, allowed types, selected type, character IDs,
 *   focused character ID, ticket rank, content type, MethodInfo.
 * The MethodInfo argument is the ninth native argument and therefore arrives
 * on the stack on arm64; keeping it in the typedef is required.
 */
typedef void (*original_CameraSelectModel_ctor_t)(
	void* self,
	Unity::System_String* liveId,
	IL2CPP::CClass* allowedCameraTypes,
	int selectedCameraType,
	IL2CPP::CClass* characterIds,
	int focusedCharacterId,
	int ticketRank,
	int contentType,
	void* methodInfo
);
static original_CameraSelectModel_ctor_t original_CameraSelectModel_ctor = nullptr;

static thread_local uint32_t fesArchiveCameraFactoryDepth = 0;
static thread_local Unity::System_String *fesArchiveExpectedLiveId = nullptr;
static thread_local int fesArchiveExpectedContentType = 0;

class FesArchiveCameraFactoryScope {
	Unity::System_String *previousLiveId;
	int previousContentType;
	bool previousTargetAllowed;

public:
	explicit FesArchiveCameraFactoryScope(void* factorySelf)
		: previousLiveId(fesArchiveExpectedLiveId),
		  previousContentType(fesArchiveExpectedContentType),
		  previousTargetAllowed(fesArchiveTargetAllowed) {
		++fesArchiveCameraFactoryDepth;

		IL2CPP::CClass *pSelf = reinterpret_cast<IL2CPP::CClass*>(factorySelf);
		IL2CPP::CClass *liveId = pSelf
			? pSelf->GetMemberValue<IL2CPP::CClass*>("_liveId")
			: nullptr;
		fesArchiveExpectedLiveId = liveId
			? liveId->GetMemberValue<Unity::System_String*>("Value")
			: nullptr;
		fesArchiveExpectedContentType = pSelf
			? pSelf->GetMemberValue<int>("_contentType")
			: 0;
		fesArchiveTargetAllowed =
			configuredFesArchiveTargetAllows(fesArchiveExpectedLiveId);
	}
	~FesArchiveCameraFactoryScope() {
		fesArchiveExpectedLiveId = previousLiveId;
		fesArchiveExpectedContentType = previousContentType;
		fesArchiveTargetAllowed = previousTargetAllowed;
		if (fesArchiveCameraFactoryDepth > 0) {
			--fesArchiveCameraFactoryDepth;
		}
	}
};

typedef IL2CPP::CClass* (*original_FesConnectModelsFactory_CreateCameraSelectModel_t)(
	void* self,
	void* methodInfo
);
static original_FesConnectModelsFactory_CreateCameraSelectModel_t
	original_FesConnectModelsFactory_CreateCameraSelectModel = nullptr;
static original_FesConnectModelsFactory_CreateCameraSelectModel_t
	original_FesConnectModelsFactory_CreateCameraSelectModelDirect = nullptr;

IL2CPP::CClass* hooked_FesConnectModelsFactory_CreateCameraSelectModel(
	void* self,
	void* methodInfo
) {
	FesArchiveCameraFactoryScope archiveScope(self);
	repairFesArchiveResponseCache(self);
	return original_FesConnectModelsFactory_CreateCameraSelectModel(self, methodInfo);
}

IL2CPP::CClass* hooked_FesConnectModelsFactory_CreateCameraSelectModelDirect(
	void* self,
	void* methodInfo
) {
	FesArchiveCameraFactoryScope archiveScope(self);
	repairFesArchiveResponseCache(self);
	return original_FesConnectModelsFactory_CreateCameraSelectModelDirect(
		self,
		methodInfo
	);
}

void hooked_CameraSelectModel_ctor(
	void* self,
	Unity::System_String* liveId,
	IL2CPP::CClass* allowedCameraTypes,
	int selectedCameraType,
	IL2CPP::CClass* characterIds,
	int focusedCharacterId,
	int ticketRank,
	int contentType,
	void* methodInfo
) {
	if (configBool(@"FesArchive.ValidTicketRepair.Enable") &&
		fesArchiveCameraFactoryDepth > 0 &&
		fesArchiveTargetAllowed &&
		fesArchiveExpectedLiveId &&
		managedStringsHaveEqualValue(liveId, fesArchiveExpectedLiveId) &&
		contentType == fesArchiveExpectedContentType &&
		hasOnlyDynamicCameraType(allowedCameraTypes) &&
		isFesArchiveRepairCandidateRank(ticketRank)) {
		NSArray<NSNumber*> *configuredTypes = configuredFesArchiveCameraTypes();
		bool selectedTypeIsConfigured =
			[configuredTypes containsObject:@(selectedCameraType)] ||
			(selectedCameraType == Undefined &&
			 [configuredTypes containsObject:@(Dynamic)]);
		IL2CPP::CClass *configuredCameraTypes = selectedTypeIsConfigured
			? createConfiguredFesArchiveCameraTypes()
			: nullptr;

		if (configuredCameraTypes) {
			allowedCameraTypes = configuredCameraTypes;
			if (selectedCameraType == Undefined) {
				selectedCameraType = Dynamic;
			}
			ticketRank = repairFesArchiveTicketRank(ticketRank);
		} else {
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Repair skipped because the "
				 "configured camera list is invalid or excludes the selected camera."
			);
		}

		static bool loggedRepair = false;
		if (configuredCameraTypes && !loggedRepair) {
			loggedRepair = true;
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Applied the user-configured "
				 "valid-ticket camera repair to the archive CameraSelectModel."
			);
		}
	}

	original_CameraSelectModel_ctor(
		self,
		liveId,
		allowedCameraTypes,
		selectedCameraType,
		characterIds,
		focusedCharacterId,
		ticketRank,
		contentType,
		methodInfo
	);
}

// Tecotec.QuestLive.Live.QuestLiveHeartObject.PlayParticles()
typedef void (*original_QuestLiveHeartObject_PlayParticles_t)(void* self);
static original_QuestLiveHeartObject_PlayParticles_t original_QuestLiveHeartObject_PlayParticles = nullptr;
void hooked_QuestLiveHeartObject_PlayParticles(void* self) {
	IL2CPP::CClass *pSelf = reinterpret_cast<IL2CPP::CClass*>(self);
	pSelf->CallMethodSafe<void>("StopParticles");
}

// Tecotec.QuestLive.Live.QuestLiveHeartObject.ShowHeart(bool show)
static void (*original_QuestLiveHeartObject_ShowHeart)(void* self, bool show);
static void hooked_QuestLiveHeartObject_ShowHeart(void* self, bool show) {
	original_QuestLiveHeartObject_ShowHeart(self, false);
}

// Tecotec.QuestLive.Live.QuestLiveCutinCharacter.PlaySkillAnimation()
typedef void (*original_QuestLiveCutinCharacter_PlaySkillAnimation_t)(void* self);
static original_QuestLiveCutinCharacter_PlaySkillAnimation_t original_QuestLiveCutinCharacter_PlaySkillAnimation = nullptr;
void hooked_QuestLiveCutinCharacter_PlaySkillAnimation(void* self) {}

// Inspix.PlayerGameViewUtilsImpl.SetPortraitImpl()
static void (*original_PlayerGameViewUtilsImpl_SetPortraitImpl)(
	void* self,
	void* methodInfo
) = nullptr;
void hooked_PlayerGameViewUtilsImpl_SetPortraitImpl(
	void* self,
	void* methodInfo
) {
	if (lviOrientationPassthroughActive() &&
		original_PlayerGameViewUtilsImpl_SetPortraitImpl) {
		original_PlayerGameViewUtilsImpl_SetPortraitImpl(self, methodInfo);
	}
}

// Inspix.PlayerGameViewUtilsImpl.SetLandscapeImpl()
static void (*original_PlayerGameViewUtilsImpl_SetLandscapeImpl)(
	void* self,
	void* methodInfo
) = nullptr;
void hooked_PlayerGameViewUtilsImpl_SetLandscapeImpl(
	void* self,
	void* methodInfo
) {
	if (lviOrientationPassthroughActive() &&
		original_PlayerGameViewUtilsImpl_SetLandscapeImpl) {
		original_PlayerGameViewUtilsImpl_SetLandscapeImpl(self, methodInfo);
	}
}

// Inspix.PlayerGameViewUtilsImpl.CurrentOrientationIsImpl(enum deviceOrientation)
static bool (*original_PlayerGameViewUtilsImpl_CurrentOrientationIsImpl)(
	void* self,
	int deviceOrientation,
	void* methodInfo
) = nullptr;
bool hooked_PlayerGameViewUtilsImpl_CurrentOrientationIsImpl(
	void* self,
	int deviceOrientation,
	void* methodInfo
) {
	if (lviOrientationPassthroughActive() &&
		original_PlayerGameViewUtilsImpl_CurrentOrientationIsImpl) {
		return original_PlayerGameViewUtilsImpl_CurrentOrientationIsImpl(
			self,
			deviceOrientation,
			methodInfo
		);
	}
	return true;
}

// UniTask Inspix.LiveMain.BasePopup.OpenAsync()
// UniTask is a 16-byte value type on this arm64 IL2CPP build. Preserve both
// return registers and the trailing MethodInfo argument instead of treating
// the result as a managed object pointer.
struct alignas(8) LVIUniTaskResult {
	void *source;
	int16_t token;
	uint8_t padding[6];
};
static_assert(
	sizeof(LVIUniTaskResult) == 16,
	"5.0.1 UniTask ABI must remain a 16-byte value return"
);

static LVIUniTaskResult
(*original_LiveMain_BasePopup_OpenAsync)(
	void *self,
	void *methodInfo
) = nullptr;

static LVIUniTaskResult hooked_LiveMain_BasePopup_OpenAsync(
	void *self,
	void *methodInfo
) {
	float width = (float)IL2CPP::Helper::InvokeStaticMethod<int>(
		"UnityEngine.Screen",
		"get_width"
	);
	float height = (float)IL2CPP::Helper::InvokeStaticMethod<int>(
		"UnityEngine.Screen",
		"get_height"
	);
	if (width > height) {
		// NSLog(@"[IL2CPP Tweak] Screen size: %f x %f", width, height);
		IL2CPP::CClass* pSelf = reinterpret_cast<IL2CPP::CClass*>(self);
		pSelf->CallMethodSafe<void, float>("SetLandscapeScaleIfNeed", height / width);
	}
	if (!original_LiveMain_BasePopup_OpenAsync) {
		return {};
	}
	return original_LiveMain_BasePopup_OpenAsync(self, methodInfo);
}

// static string Tecotec.StoryScene.LoadStoryData(string storyText)
typedef Unity::System_String* (*original_StoryScene_LoadStoryData_t)(
	Unity::System_String* storyText,
	void* methodInfo
);
static original_StoryScene_LoadStoryData_t original_StoryScene_LoadStoryData = nullptr;

Unity::System_String* hooked_StoryScene_LoadStoryData(
	Unity::System_String* storyText,
	void* methodInfo
) {
	Unity::System_String* loaded =
		original_StoryScene_LoadStoryData(storyText, methodInfo);
	if (!loaded) {
		return loaded;
	}

	bool hideBackground = configBool(@"ActivityRecord.HideBackground");
	bool hideTransition = configBool(@"ActivityRecord.HideTransition");
	bool hideNonCharacter3D = configBool(@"ActivityRecord.HideNonCharacter3D");
	bool hideDepthOfField = configBool(@"ActivityRecord.HideDepthOfField");
	bool hidePresetEffect = configBool(@"ActivityRecord.HidePresetEffect");
	if (!hideBackground && !hideTransition && !hideNonCharacter3D &&
		!hideDepthOfField && !hidePresetEffect) {
		return loaded;
	}

	NSString *originalText = loaded->ToNSString();
	if (!originalText) {
		return loaded;
	}
	NSString *processed = originalText;

	if (hideBackground) {
		processed = replaceStoryLines(
			processed,
			@"#?\\[?背景(表示|移動|回転)[^\\n]*(?:\\n|$)"
		);
		processed = replaceStoryLines(
			processed,
			@"[^\\n]*runbg[^\\n]*(?:\\n|$)"
		);
	}
	if (hideTransition) {
		processed = replaceStoryLines(
			processed,
			@"[^\\n]*暗転_イン[^\\n]*(?:\\n|$)"
		);
		processed = replaceStoryLines(
			processed,
			@"[^\\n]*###[^\\n]*(?:\\n|$)"
		);
	}
	if (hideNonCharacter3D) {
		processed = replaceStoryLines(
			processed,
			@"[^\\n]*3Dオブジェクト[^\\n]*(?:\\n|$)"
		);
	}
	if (hideDepthOfField) {
		processed = replaceStoryLines(
			processed,
			@"\\[?被写界深度[^\\n]*(?:\\n|$)"
		);
	}
	if (hidePresetEffect) {
		processed = replaceStoryLines(
			processed,
			@"\\[?プリセットポストエフェクト[^\\n]*(?:\\n|$)"
		);
	}

	if ([processed isEqualToString:originalText]) {
		return loaded;
	}
	NSLog(@"[LinkuraVisualsIOS][Story] Applied activity-record visual filters.");
	return IL2CPP::String::New([processed UTF8String]);
}

// Tecotec.StoryUIWindow.Setup(bool skipReturn, int skipLine, float timesec, bool seekbar)
static void (*original_StoryUIWindow_Setup)(void* self, bool skipReturn, int skipLine, float timesec, bool seekbar) = nullptr;
void hooked_StoryUIWindow_Setup(void* self, bool skipReturn, int skipLine, float timesec, bool seekbar) {
	original_StoryUIWindow_Setup(self, skipReturn, skipLine, timesec, seekbar);
	IL2CPP::CClass* pSelf = reinterpret_cast<IL2CPP::CClass*>(self);
	if ([qualityConfig[@"Story.Utils.Novel.OpenWithAuto.Enable"] boolValue]) {
		pSelf->CallMethodSafe<void, int>("NovelAutoSpeed", [qualityConfig[@"Story.Utils.Novel.WaitInterval"] intValue]);
		pSelf->CallMethodSafe<void, int>("SetNovelWaitInterval", [qualityConfig[@"Story.Utils.Novel.WaitInterval"] intValue]);
		pSelf->CallMethodSafe<void, int>("SetNovelTextSpeedMove", [qualityConfig[@"Story.Utils.Novel.TextDisplaySpeed"] intValue]);
	}

	if ([qualityConfig[@"Story.Utils.AutoCloseSubtitle.Enable"] boolValue]) {
		IL2CPP::CClass* menu = pSelf->GetMemberValue<IL2CPP::CClass*>("menu");
		if (menu) {
			bool isSubtitle = menu->GetMemberValue<bool>("isSubtitle");
			if (isSubtitle) {
				pSelf->CallMethodSafe<void>("OnClickSwitchSubtitle");
			}
		}
	}
}

// void School.Story.NovelView.Initialize(Camera storySpaceCamera)
static void (*original_NovelView_Initialize)(void* self, Unity::CCamera* storySpaceCamera) = nullptr;
void hooked_NovelView_Initialize(void* self, Unity::CCamera* storySpaceCamera) {
	original_NovelView_Initialize(self, storySpaceCamera);
	IL2CPP::CClass* pSelf = reinterpret_cast<IL2CPP::CClass*>(self);
	pSelf->CallMethodSafe<void, float>("ChangeSpeed", [qualityConfig[@"Story.Utils.Novel.TextDisplayAniSpeed"] floatValue]);
}

// float Tecotec.AddNovelTextCommand.GetDisplayTime(StoryMnemonic mnemonic)
struct AddNovelTextCommand_GetText_Return {
	Unity::System_String* Item1;
	Unity::il2cppArray<IL2CPP::CClass*>* Item2;
};
static float (*original_AddNovelTextCommand_GetDisplayTime)(IL2CPP::CClass* mnemonic) = nullptr;
float hooked_AddNovelTextCommand_GetDisplayTime(IL2CPP::CClass* mnemonic) {
	IL2CPP::CClass* operands = mnemonic->GetMemberValue<IL2CPP::CClass*>("operands");
	if (operands) {
		Unity::il2cppArray<Unity::System_String*>* sValues = operands->GetMemberValue<Unity::il2cppArray<Unity::System_String*>*>("sValues");
		if (sValues && sValues->m_uMaxLength <= 1) {
			AddNovelTextCommand_GetText_Return result = IL2CPP::Helper::InvokeStaticMethod<AddNovelTextCommand_GetText_Return, IL2CPP::CClass*>(
				"Tecotec.AddNovelTextCommand",
				"GetText",
				mnemonic
			);
			return (float)result.Item1->_stringLength * [qualityConfig[@"Story.Utils.Novel.TextDisplayTime"] floatValue] + [qualityConfig[@"Story.Utils.Novel.PlainTextExtend"] floatValue];
		}
	}
	return original_AddNovelTextCommand_GetDisplayTime(mnemonic) + [qualityConfig[@"Story.Utils.Novel.VoiceTextExtend"] floatValue];
}

// Tecotec.TPopupQuestLiveSettings.SetHeartShowLimitValue(int32_t value, bool playSe)
static void (*original_TPopupQuestLiveSettings_SetHeartShowLimitValue)(void* self, int32_t value, bool playSe) = nullptr;
void hooked_TPopupQuestLiveSettings_SetHeartShowLimitValue(void* self, int value, bool playSe) {
	IL2CPP::CClass* globalInstance = get_GlobalInstance();
	IL2CPP::CClass* pSelf = reinterpret_cast<IL2CPP::CClass*>(self);

	if (playSe) {
		IL2CPP::CClass* soundManager = globalInstance->GetMemberValue<IL2CPP::CClass*>("<SoundManager>k__BackingField");
		Unity::System_String* cueName = nullptr;
		bool isQuestScene = IL2CPP::Helper::InvokeStaticMethod<bool>(
			"GameDefine.QuestScene",
			"IsQuestScene"
		);
		if (isQuestScene) { 
			cueName = IL2CPP::Helper::InvokeStaticMethod<Unity::System_String*>(
				"Tecotec.CriCueName",
				"QuestTap",
				1
			);
		} else {
			cueName = IL2CPP::Helper::InvokeStaticMethod<Unity::System_String*>(
				"Tecotec.CriCueName",
				"UiTap",
				3
			);
		}
		if (cueName != nullptr) {
			soundManager->CallMethodSafe<void, Unity::System_String*, int>("PlaySystemSe", cueName, 0);
		}
	}

	int clampedValue = MIN(MAX(value, 0), 100);
	IL2CPP::CClass* saveData = globalInstance->GetMemberValue<IL2CPP::CClass*>("<SaveData>k__BackingField");
	
	if (saveData != nullptr) {
		IL2CPP::CClass* heartShowLimitCount = saveData->GetMemberValue<IL2CPP::CClass*>("HeartShowLimitCount");
		if (heartShowLimitCount != nullptr) {
			int currentValue = heartShowLimitCount->CallMethodSafe<int>("get_Value");
			if (currentValue != clampedValue) {
				heartShowLimitCount->SetMemberValue<int>("internalValue", clampedValue);
			}
		}
	}

	IL2CPP::CClass* heartLimitText = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartLimitText");
	if (heartLimitText != nullptr) {
		std::string text = std::to_string(clampedValue);
		Unity::System_String* textString = IL2CPP::String::New(text);
		heartLimitText->CallMethodSafe<void, Unity::System_String*>("set_text", textString);
	}

	IL2CPP::CClass* btnMinus10 = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitbuttonMinus10");
	IL2CPP::CClass* btnPlus10 = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitbuttonPlus10");
	IL2CPP::CClass* btnMin = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitbuttonMin");
	IL2CPP::CClass* btnMax = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitbuttonMax");
	IL2CPP::CClass* imgMinus10Off = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitimageMinus10Off");
	IL2CPP::CClass* imgPlus10Off = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitimagePlus10Off");
	IL2CPP::CClass* imgMinOff = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitimageMinOff");
	IL2CPP::CClass* imgMaxOff = pSelf->GetMemberValue<IL2CPP::CClass*>("_heartShowLimitimageMaxOff");

	if (btnMinus10 != nullptr) btnMinus10->CallMethodSafe<void, bool>("set_interactable", clampedValue > 0);
	if (btnMin != nullptr) btnMin->CallMethodSafe<void, bool>("set_interactable", clampedValue > 0);
	if (imgMinus10Off != nullptr) imgMinus10Off->CallMethodSafe<void, bool>("set_enabled", clampedValue < 1);
	if (imgMinOff != nullptr) imgMinOff->CallMethodSafe<void, bool>("set_enabled", clampedValue < 1);

	if (btnPlus10 != nullptr) btnPlus10->CallMethodSafe<void, bool>("set_interactable", clampedValue < 100);
	if (btnMax != nullptr) btnMax->CallMethodSafe<void, bool>("set_interactable", clampedValue < 100);
	if (imgPlus10Off != nullptr) imgPlus10Off->CallMethodSafe<void, bool>("set_enabled", clampedValue > 99);
	if (imgMaxOff != nullptr) imgMaxOff->CallMethodSafe<void, bool>("set_enabled", clampedValue > 99);
}

static bool findMethodAndHook(const char* className, const char* methodName, int paramCount, void* hookFunc, void** originalFunc) { 
	void* pMethod = IL2CPP::Class::Utils::GetMethodPointer(className, methodName, paramCount);
	if (pMethod) {
		MSHookFunction_p(
			pMethod,
			hookFunc,
			originalFunc
		);
		NSLog(@"[IL2CPP Tweak] Hooked %s::%s", className, methodName);
		return true;
	} else {
		NSLog(@"[IL2CPP Tweak][Failed] Cannot find %s::%s, %d params", className, methodName, paramCount);
	}
	return false;
}

static bool findMethodAndHook(Unity::il2cppClass* pClass, const char* methodName, int paramCount, void* hookFunc, void** originalFunc) { 
	void* pMethod = IL2CPP::Class::Utils::GetMethodPointer(pClass, methodName, paramCount);
	if (pMethod) {
		MSHookFunction_p(
			pMethod,
			hookFunc,
			originalFunc
		);
		NSLog(@"[IL2CPP Tweak] Hooked %s::%s", pClass->m_pName, methodName);
		return true;
	} else {
		NSLog(@"[IL2CPP Tweak][Failed] Cannot find %s::%s, %d params", pClass->m_pName, methodName, paramCount);
	}
	return false;
}

static bool findInstanceBoolFuncMethodAndHook(
	const char* className,
	const char* methodName,
	void* hookFunc,
	void** originalFunc
) {
	Unity::il2cppClass *declaringClass =
		IL2CPP::Class::Find(className);
	Unity::il2cppMethodInfo *method = declaringClass
		? IL2CPP::Class::Utils::GetMethod(
			declaringClass,
			methodName,
			1
		)
		: nullptr;
	if (!method ||
		!method->m_pMethodPointer ||
		method->m_pClass != declaringClass ||
		method->m_uArgsCount != 1 ||
		(method->m_uFlags & 0x0010) != 0) {
		NSLog(
			@"[IL2CPP Tweak][Failed] Invalid instance predicate "
			 "%s::%s",
			className,
			methodName
		);
		return false;
	}
	Unity::il2cppClass *returnClass =
		method->m_pReturnType
			? IL2CPP::Class::Utils::ClassFromType(
				method->m_pReturnType
			)
			: nullptr;
	Unity::il2cppType *parameterType =
		IL2CPP::Class::Utils::GetMethodParamType(method, 0);
	Unity::il2cppClass *parameterClass = parameterType
		? IL2CPP::Class::Utils::ClassFromType(parameterType)
		: nullptr;
	bool exactSignature =
		returnClass &&
		returnClass->m_pNamespace &&
		returnClass->m_pName &&
		strcmp(returnClass->m_pNamespace, "System") == 0 &&
		strcmp(returnClass->m_pName, "Boolean") == 0 &&
		parameterClass &&
		parameterClass->m_pNamespace &&
		parameterClass->m_pName &&
		strcmp(parameterClass->m_pNamespace, "System") == 0 &&
		strcmp(parameterClass->m_pName, "Func`1") == 0;
	if (!exactSignature) {
		NSLog(
			@"[IL2CPP Tweak][Failed] Signature mismatch for "
			 "%s::%s",
			className,
			methodName
		);
		return false;
	}
	MSHookFunction_p(
		method->m_pMethodPointer,
		hookFunc,
		originalFunc
	);
	NSLog(
		@"[IL2CPP Tweak] Hooked exact predicate %s::%s",
		className,
		methodName
	);
	return true;
}

static bool installLVIWithArchiveSeekLimitHook() {
	if (original_ArchiveSeekBarView_SetSeekLimit) {
		return true;
	}
	return findMethodAndHook(
		"School.LiveMain.ArchiveSeekBarView",
		"SetSeekLimit",
		1,
		(void*)hooked_ArchiveSeekBarView_SetSeekLimit,
		(void**)&original_ArchiveSeekBarView_SetSeekLimit
	);
}

static bool installLVIWithArchivePlayableLengthHook() {
	if (original_LiveConnectPlayPositionModel_SetPlayableLengthRate) {
		return true;
	}
	return findMethodAndHook(
		"School.LiveMain.LiveConnectPlayPositionModel",
		"SetPlayableLengthRate",
		1,
		(void*)
			hooked_LiveConnectPlayPositionModel_SetPlayableLengthRate,
		(void**)
			&original_LiveConnectPlayPositionModel_SetPlayableLengthRate
	);
}

static bool installLVIWithArchiveReplayOverlayHook() {
	bool endStateReady =
		original_LiveConnectPlayPositionModel_IsPlayToEnd != nullptr;
	if (!endStateReady) {
		endStateReady = findInstanceBoolFuncMethodAndHook(
			"School.LiveMain.LiveConnectPlayPositionModel",
			"IsPlayToEnd",
			(void*)hooked_LiveConnectPlayPositionModel_IsPlayToEnd,
			(void**)&original_LiveConnectPlayPositionModel_IsPlayToEnd
		);
	}

	bool replayPredicateReady =
		original_ArchiveReplayButtonPresenter_ReplayPredicate != nullptr;
	if (replayPredicateReady) {
		return endStateReady;
	}
	Unity::il2cppClass *replayClosure =
		IL2CPP::Class::Utils::GetNestedClass(
			"School.LiveMain.ArchiveReplayButtonPresenter",
			"<>c__DisplayClass5_0"
		);
	if (!replayClosure) {
		// IsPlayToEnd is the primary correction.  The presenter closure is a
		// legacy fallback that some app builds may not expose.
		return endStateReady;
	}
	lviWithArchiveReplayPredicateClosureClass.store(
		replayClosure,
		std::memory_order_release
	);
	replayPredicateReady = findMethodAndHook(
		replayClosure,
		"<School.LiveMain.ILiveSystemPresenter.Initialize>b__0",
		0,
		(void*)hooked_ArchiveReplayButtonPresenter_ReplayPredicate,
		(void**)&original_ArchiveReplayButtonPresenter_ReplayPredicate
	);
	if (!replayPredicateReady) {
		lviWithArchiveReplayPredicateClosureClass.store(
			nullptr,
			std::memory_order_release
		);
	}
	return endStateReady;
}

#if LVI_WM_DIAGNOSTIC
static void installLVIWMClockDiagnosticHooks(
	bool seekLimitReady,
	bool setPlayableLengthRateReady
) {
	bool setContentsLengthReady = findMethodAndHook(
		"School.LiveMain.LiveConnectPlayPositionModel",
		"SetContentsLength",
		1,
		(void*)hooked_LiveConnectPlayPositionModel_SetContentsLength,
		(void**)&original_LiveConnectPlayPositionModel_SetContentsLength
	);
	bool nextSeekTimeReady = findMethodAndHook(
		"School.LiveMain.LiveConnectPlayPositionModel",
		"OnNextSeekTime",
		1,
		(void*)hooked_LiveConnectPlayPositionModel_OnNextSeekTime,
		(void**)&original_LiveConnectPlayPositionModel_OnNextSeekTime
	);
	bool setControllerReady = findMethodAndHook(
		"School.LiveMain.LiveConnectControlModel",
		"SetContentsController",
		1,
		(void*)hooked_LiveConnectControlModel_SetContentsController,
		(void**)&original_LiveConnectControlModel_SetContentsController
	);
	bool controlPositionReady = findMethodAndHook(
		"School.LiveMain.LiveConnectControlModel",
		"GetPlayingPosition",
		0,
		(void*)hooked_LiveConnectControlModel_GetPlayingPosition,
		(void**)&original_LiveConnectControlModel_GetPlayingPosition
	);
	bool controlEndReady = findMethodAndHook(
		"School.LiveMain.LiveConnectControlModel",
		"get_IsPlayToEnd",
		0,
		(void*)hooked_LiveConnectControlModel_get_IsPlayToEnd,
		(void**)&original_LiveConnectControlModel_get_IsPlayToEnd
	);
	bool controllerLengthReady = findMethodAndHook(
		"School.LiveMain.RealtimeRenderingArchiveController",
		"get_ContentsLength",
		0,
		(void*)
			hooked_RealtimeRenderingArchiveController_get_ContentsLength,
		(void**)
			&original_RealtimeRenderingArchiveController_get_ContentsLength
	);
	bool controllerPositionReady = findMethodAndHook(
		"School.LiveMain.RealtimeRenderingArchiveController",
		"School.LiveMain.ILiveConnectContentsController.get_PlayingPosition",
		0,
		(void*)
			hooked_RealtimeRenderingArchiveController_get_PlayingPosition,
		(void**)
			&original_RealtimeRenderingArchiveController_get_PlayingPosition
	);
	bool controllerEndReady = findMethodAndHook(
		"School.LiveMain.RealtimeRenderingArchiveController",
		"get_IsPlayToEnd",
		0,
		(void*)
			hooked_RealtimeRenderingArchiveController_get_IsPlayToEnd,
		(void**)
			&original_RealtimeRenderingArchiveController_get_IsPlayToEnd
	);

	Unity::il2cppClass *seekClosure =
		IL2CPP::Class::Utils::GetNestedClass(
			"School.LiveMain.VideoArchiveSeekBarPresenter",
			"<>c__DisplayClass4_0"
		);
	bool seekBeginReady = false;
	bool seekingReady = false;
	bool seekEndReady = false;
	if (seekClosure) {
		seekBeginReady = findMethodAndHook(
			seekClosure,
			"<School.LiveMain.ILiveSystemPresenter.Initialize>b__0",
			1,
			(void*)hooked_VideoArchiveSeekBarPresenter_SeekBegin,
			(void**)&original_VideoArchiveSeekBarPresenter_SeekBegin
		);
		seekingReady = findMethodAndHook(
			seekClosure,
			"<School.LiveMain.ILiveSystemPresenter.Initialize>b__1",
			1,
			(void*)hooked_VideoArchiveSeekBarPresenter_Seeking,
			(void**)&original_VideoArchiveSeekBarPresenter_Seeking
		);
		seekEndReady = findMethodAndHook(
			seekClosure,
			"<School.LiveMain.ILiveSystemPresenter.Initialize>b__2",
			1,
			(void*)hooked_VideoArchiveSeekBarPresenter_SeekEnd,
			(void**)&original_VideoArchiveSeekBarPresenter_SeekEnd
		);
	}

	Unity::il2cppClass *replayClosure =
		lviWithArchiveReplayPredicateClosureClass.load(
			std::memory_order_acquire
		);
	bool replayPredicateReady =
		replayClosure != nullptr &&
		original_ArchiveReplayButtonPresenter_ReplayPredicate != nullptr;
	bool falseEndSuppressionReady =
		original_LiveConnectPlayPositionModel_IsPlayToEnd != nullptr;

	bool coreReady =
		setContentsLengthReady &&
		setPlayableLengthRateReady &&
		nextSeekTimeReady &&
		seekLimitReady &&
		setControllerReady &&
		controlPositionReady &&
		controlEndReady &&
		seekBeginReady &&
		seekingReady &&
		seekEndReady &&
		falseEndSuppressionReady;
	lviWriteWMDiagnostic(@{
		@"stage": @"wm-clock-hook-install",
		@"pipelineVersion": @4,
		@"setContentsLength": @(setContentsLengthReady),
		@"setPlayableLengthRate": @(setPlayableLengthRateReady),
		@"nextSeekTime": @(nextSeekTimeReady),
		@"seekLimit": @(seekLimitReady),
		@"setContentsController": @(setControllerReady),
		@"controlPlayingPosition": @(controlPositionReady),
		@"controlEndState": @(controlEndReady),
		@"controllerContentsLength": @(controllerLengthReady),
		@"controllerPlayingPosition": @(controllerPositionReady),
		@"controllerEndState": @(controllerEndReady),
		@"seekClosureFound": @(seekClosure != nullptr),
		@"seekBegin": @(seekBeginReady),
		@"seeking": @(seekingReady),
		@"seekEnd": @(seekEndReady),
		@"replayClosureFound": @(replayClosure != nullptr),
		@"replayPredicate": @(replayPredicateReady),
		@"falseEndSuppression": @(falseEndSuppressionReady),
		@"coreReady": @(coreReady)
	});
}
#endif

static void installLVICameraControlHooks() {
	lviComponentGetTransform =
		reinterpret_cast<LVIComponentGetTransform_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Component",
				"get_transform",
				0
			)
		);
	lviTransformGetPosition =
		reinterpret_cast<LVITransformGetPositionInjected_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Transform",
				"get_position_Injected",
				1
			)
		);
	lviTransformSetPosition =
		reinterpret_cast<LVITransformSetPositionInjected_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Transform",
				"set_position_Injected",
				1
			)
		);
	lviTransformGetRotation =
		reinterpret_cast<LVITransformGetRotationInjected_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Transform",
				"get_rotation_Injected",
				1
			)
		);
	lviTransformSetRotation =
		reinterpret_cast<LVITransformSetRotationInjected_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Transform",
				"set_rotation_Injected",
				1
			)
		);
	lviCameraGetFieldOfView =
		reinterpret_cast<LVICameraGetFloat_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Camera",
				"get_fieldOfView",
				0
			)
		);
	lviCameraSetFieldOfView =
		reinterpret_cast<LVICameraSetFloat_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Camera",
				"set_fieldOfView",
				1
			)
		);
	lviCameraGetOrthographicSize =
		reinterpret_cast<LVICameraGetFloat_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Camera",
				"get_orthographicSize",
				0
			)
		);
	lviCameraSetOrthographicSize =
		reinterpret_cast<LVICameraSetFloat_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Camera",
				"set_orthographicSize",
				1
			)
		);
	lviCameraGetOrthographic =
		reinterpret_cast<LVICameraGetBool_t>(
			IL2CPP::Class::Utils::GetMethodPointer(
				"UnityEngine.Camera",
				"get_orthographic",
				0
			)
		);
	if (!lviCameraBaseFunctionsReady()) {
		NSLog(
			@"[LinkuraVisualsIOS][Camera] One or more required Unity camera "
			 "endpoints were not found."
		);
		return;
	}
	if (!lviCameraOrthographicFunctionsReady()) {
		NSLog(
			@"[LinkuraVisualsIOS][Camera] Orthographic endpoints were not "
			 "found; perspective controls remain available."
		);
	}

	bool renderHookReady = findMethodAndHook(
		"UnityEngine.Rendering.RenderPipeline",
		"BeginCameraRendering",
		2,
		(void*)hooked_RenderPipeline_BeginCameraRendering,
		(void**)&original_RenderPipeline_BeginCameraRendering
	);
	if (!renderHookReady || !original_RenderPipeline_BeginCameraRendering) {
		NSLog(
			@"[LinkuraVisualsIOS][Camera] Render hook unavailable; "
			 "camera adapters will not be enabled."
		);
		return;
	}

	if (configBool(@"ActivityRecord.CameraControl.Enable")) {
		Unity::il2cppClass *activityClosure =
			IL2CPP::Class::Utils::GetNestedClass(
				"Tecotec.ActivityRecordSceneController",
				"<>c__DisplayClass16_0"
			);
		bool callbackHookReady = false;
		if (activityClosure) {
			callbackHookReady = findMethodAndHook(
				activityClosure,
				"<CreateTPopupPlayBackDialogAsync>b__1",
				3,
				(void*)hooked_ActivityPlaybackCallback,
				(void**)&original_ActivityPlaybackCallback
			);
		}
		bool setupHookReady = findMethodAndHook(
			"Tecotec.StoryModelSpaceManager",
			"Setup",
			4,
			(void*)hooked_StoryModelSpaceManager_Setup,
			(void**)&original_StoryModelSpaceManager_Setup
		);
		bool releaseHookReady = findMethodAndHook(
			"Tecotec.StoryModelSpaceManager",
			"Release",
			0,
			(void*)hooked_StoryModelSpaceManager_Release,
			(void**)&original_StoryModelSpaceManager_Release
		);
		lviActivityCameraAdapterReady =
			callbackHookReady && setupHookReady && releaseHookReady;
		if (!lviActivityCameraAdapterReady) {
			NSLog(
				@"[LinkuraVisualsIOS][Camera] Activity Record adapter "
				 "incomplete; it will remain disabled."
			);
		}
	}

	bool sharedDynamicCameraHooksNeeded =
		configBool(@"WithMeets.CameraControl.Enable") ||
		configBool(@"FesArchive.CameraControl.Enable");
	bool getDynamicCameraHookReady = true;
	bool disposeDynamicCameraHookReady = true;
	bool liveSystemDisposeHookReady = true;
	if (sharedDynamicCameraHooksNeeded) {
		getDynamicCameraHookReady =
			original_DynamicCamera_GetCamera != nullptr ||
			findMethodAndHook(
				"School.LiveMain.DynamicCamera",
				"GetCamera",
				0,
				(void*)hooked_DynamicCamera_GetCamera,
				(void**)&original_DynamicCamera_GetCamera
			);
		disposeDynamicCameraHookReady =
			original_DynamicCamera_Dispose != nullptr ||
			findMethodAndHook(
				"School.LiveMain.DynamicCamera",
				"Dispose",
				0,
				(void*)hooked_DynamicCamera_Dispose,
				(void**)&original_DynamicCamera_Dispose
			);
		liveSystemDisposeHookReady =
			original_LiveSystemModels_Dispose != nullptr ||
			findMethodAndHook(
				"School.LiveMain.LiveSystemModels",
				"Dispose",
				0,
				(void*)hooked_LiveSystemModels_Dispose,
				(void**)&original_LiveSystemModels_Dispose
			);
	}

	if (configBool(@"WithMeets.CameraControl.Enable")) {
		bool archiveInitializeHookReady = findMethodAndHook(
			"School.LiveMain.LiveConnectMrsPlayerPresenter",
			"Initialize",
			1,
			(void*)hooked_LiveConnectMrsPlayerPresenter_Initialize,
			(void**)&original_LiveConnectMrsPlayerPresenter_Initialize
		);
		bool archiveMainCameraHookReady = findMethodAndHook(
			"Inspix.AlphaBlendCamera",
			"UpdateCameras",
			3,
			(void*)hooked_AlphaBlendCamera_UpdateCameras,
			(void**)&original_AlphaBlendCamera_UpdateCameras
		);
		bool archiveBlendDisposeHookReady = findMethodAndHook(
			"Inspix.AlphaBlendCamera",
			"Dispose",
			0,
			(void*)hooked_AlphaBlendCamera_Dispose,
			(void**)&original_AlphaBlendCamera_Dispose
		);
		bool archiveDisposeHookReady = liveSystemDisposeHookReady;
		lviWithMeetsArchiveCameraAdapterReady =
			archiveInitializeHookReady &&
			archiveMainCameraHookReady &&
			archiveBlendDisposeHookReady &&
			archiveDisposeHookReady;
		if (!lviWithMeetsArchiveCameraAdapterReady) {
			NSLog(
				@"[LinkuraVisualsIOS][Camera] With×MEETS archive "
				 "adapter incomplete; archive controls will remain disabled."
			);
		}
		Unity::il2cppClass *withClosure =
			IL2CPP::Class::Utils::GetNestedClass(
				"School.LiveMain.WithLiveCameraReference",
				"<>c__DisplayClass0_0"
			);
		bool factoryHookReady = false;
		if (withClosure) {
			factoryHookReady = findMethodAndHook(
				withClosure,
				"<.ctor>b__2",
				1,
				(void*)hooked_WithLiveCameraFactory,
				(void**)&original_WithLiveCameraFactory
			);
		}
		lviWithMeetsCameraAdapterReady =
			getDynamicCameraHookReady &&
			disposeDynamicCameraHookReady &&
			factoryHookReady;
		if (!lviWithMeetsCameraAdapterReady) {
			NSLog(
				@"[LinkuraVisualsIOS][Camera] With×MEETS realtime "
				 "adapter incomplete; realtime controls will remain disabled."
			);
		}
	}

	if (configBool(@"FesArchive.CameraControl.Enable")) {
		bool fixedCtorHookReady =
			original_fesLiveFixedCameraCtor != nullptr ||
			findMethodAndHook(
				"School.LiveMain.FesLiveFixedCamera",
				".ctor",
				4,
				(void*)hooked_fesLiveFixedCameraCtor,
				(void**)&original_fesLiveFixedCameraCtor
			);
		bool idolCtorHookReady =
			original_idolTargetingCamera != nullptr ||
			findMethodAndHook(
				"School.LiveMain.IdolTargetingCamera",
				".ctor",
				3,
				(void*)hooked_idolTargetingCamera,
				(void**)&original_idolTargetingCamera
			);
		bool fixedGetCameraHookReady = findMethodAndHook(
			"School.LiveMain.FesLiveFixedCamera",
			"GetCamera",
			0,
			(void*)hooked_FesLiveFixedCamera_GetCamera,
			(void**)&original_FesLiveFixedCamera_GetCamera
		);
		bool idolGetCameraHookReady = findMethodAndHook(
			"School.LiveMain.IdolTargetingCamera",
			"GetCamera",
			0,
			(void*)hooked_IdolTargetingCamera_GetCamera,
			(void**)&original_IdolTargetingCamera_GetCamera
		);
		bool switchCameraHookReady = findMethodAndHook(
			"School.LiveMain.FesLiveCameraSwitcher",
			"SwitchCamera",
			1,
			(void*)hooked_FesLiveCameraSwitcher_SwitchCamera,
			(void**)&original_FesLiveCameraSwitcher_SwitchCamera
		);
		// Switcher.Dispose is a precise cleanup boundary when present. Some
		// 5.0.1 metadata variants expose cleanup only through
		// LiveSystemModels.Dispose, so this hook is intentionally optional.
		findMethodAndHook(
			"School.LiveMain.FesLiveCameraSwitcher",
			"Dispose",
			0,
			(void*)hooked_FesLiveCameraSwitcher_Dispose,
			(void**)&original_FesLiveCameraSwitcher_Dispose
		);
		lviFesArchiveCameraAdapterReady =
			fixedCtorHookReady &&
			idolCtorHookReady &&
			fixedGetCameraHookReady &&
			idolGetCameraHookReady &&
			switchCameraHookReady &&
			getDynamicCameraHookReady &&
			disposeDynamicCameraHookReady &&
			liveSystemDisposeHookReady;
		if (!lviFesArchiveCameraAdapterReady) {
			lviResetFesArchiveCameraAdapter();
			NSLog(
				@"[LinkuraVisualsIOS][Camera] Fes archive adapter "
				 "incomplete; Fes controls will remain disabled."
			);
		}
	}
}

static std::unordered_map<const char*, void*> il2cppFuncMap;

static BOOL (*original_didFinishLaunchingWithOptions)(id self, SEL _cmd, UIApplication *application, NSDictionary *launchOptions) = NULL;
BOOL hooked_didFinishLaunchingWithOptions(id self, SEL _cmd, UIApplication *application, NSDictionary *launchOptions) {

    NSLog(@"[Substrate Hook] C++ IL2CPP Hook logic initiated.");

	BOOL result = original_didFinishLaunchingWithOptions(self, _cmd, application, launchOptions);

	bool Unity2022_3_62F = false;

	// The IPA presents itself as 5.1.0 to the API, but its native executable is
	// still the decrypted 5.0.1 build. Always select resolver offsets from the
	// real executable version instead of trusting Info.plist.
	NSString* app_version = qualityConfig[@"Compatibility.BinaryVersion"];
	NSArray* app_version_parts = [app_version componentsSeparatedByString:@"."];
	int app_version_major = [app_version_parts[0] intValue];
	int app_version_minor = [app_version_parts[1] intValue];
	int app_version_patch = [app_version_parts[2] intValue];
	if ((app_version_major == 4 && app_version_minor >= 9) || app_version_major > 4) {
		if (!testSearch(il2cppFuncMap, app_version)) {
			NSLog(@"[IL2CPP Tweak] IL2CPP symbols hidden mode. Search failed.");
			return result;
		}

		if (!IL2CPP::Initialize(dlopen(IL2CPP_FRAMEWORK(BINARY_NAME), RTLD_NOLOAD), il2cppFuncMap)) {
			return result;
		}
		NSLog(@"[IL2CPP Tweak] IL2CPP symbols hidden mode.");
		Unity2022_3_62F = true;
	} else if (!IL2CPP::Initialize(dlopen(IL2CPP_FRAMEWORK(BINARY_NAME), RTLD_NOLOAD))) {
		return result;
	}
	NSLog(@"[IL2CPP Tweak] IL2CPP Initialized.");

	bool withArchiveOrientationRepair =
		lviWithArchiveOrientationRepairEnabled();
	bool withArchiveRenderImageCoverSuppression =
		lviWithArchiveRenderImageCoverSuppressionEnabled();
	bool withArchivePlayPauseButton =
		lviWithArchivePlayPauseButtonEnabled();
	bool withArchiveMotionReplay =
		configBool(@"WithMeets.Archive.MotionCaptureReplay.Enable");
	bool withArchiveIarcFullSeek =
		lviWithArchiveIarcFullSeekEnabled();
	bool fesArchiveSeekBar =
		configBool(@"FesArchive.SeekBar.Enable");
	bool withArchiveReplayOverlaySuppression =
		lviWithArchiveIarcReplayOverlaySuppressionEnabled();
	bool withMeetsValidAfterRepair =
		lviWithMeetsValidAfterRepairEnabled();
#if LVI_WM_DIAGNOSTIC
	if (withMeetsValidAfterRepair) {
		lviWriteAfterRuntimeSchemaDiagnostic();
	}
#endif
	bool withArchiveSelectorNeeded =
		withArchiveMotionReplay ||
		withArchiveOrientationRepair ||
		withArchiveRenderImageCoverSuppression ||
		withMeetsValidAfterRepair;
	if (withArchiveSelectorNeeded) {
		lviWithArchiveSelectorReady = findMethodAndHook(
			"School.LiveMain.WithArchiveContentTypeSelector",
			"Execute",
			0,
			(void*)hooked_WithArchiveContentTypeSelector_Execute,
			(void**)&original_WithArchiveContentTypeSelector_Execute
		);
		if (!lviWithArchiveSelectorReady) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] Motion-capture replay "
				"selector hook is unavailable; stock playback remains active."
			);
		}
#if LVI_WM_DIAGNOSTIC
		lviWriteWMDiagnostic(@{
			@"stage": @"selector-hook-install",
			@"attempted": @true,
			@"installed": @(lviWithArchiveSelectorReady),
			@"originalAvailable": @(
				original_WithArchiveContentTypeSelector_Execute != nullptr
			)
		});
#endif
	}
	if (withArchiveRenderImageCoverSuppression) {
		bool coverReceiverReady = findMethodAndHook(
			"Inspix.CoverImageCommandReceiver",
			"Awake",
			0,
			(void*)hooked_CoverImageCommandReceiver_Awake,
			(void**)&original_CoverImageCommandReceiver_Awake
		);
		bool coverScreenReady = findMethodAndHook(
			"Inspix.LiveMain.AppsCoverScreen",
			"SetActiveCoverImage",
			1,
			(void*)hooked_AppsCoverScreen_SetActiveCoverImage,
			(void**)&original_AppsCoverScreen_SetActiveCoverImage
		);
		if (!coverReceiverReady || !coverScreenReady) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchiveCover] One or more "
				 "render-cover hooks are unavailable; stock cover behavior "
				 "remains for the missing endpoint."
			);
		}
	}
	if (withArchivePlayPauseButton) {
		lviWithArchiveControlPlay =
			reinterpret_cast<LVIWithArchiveControlAction>(
				IL2CPP::Class::Utils::GetMethodPointer(
					"School.LiveMain.LiveConnectControlModel",
					"Play",
					0
				)
			);
		lviWithArchiveControlPause =
			reinterpret_cast<LVIWithArchiveControlAction>(
				IL2CPP::Class::Utils::GetMethodPointer(
					"School.LiveMain.LiveConnectControlModel",
					"Pause",
					0
				)
			);
		lviWithArchiveControlGetIsLoading =
			reinterpret_cast<LVIWithArchiveControlGetBool>(
				IL2CPP::Class::Utils::GetMethodPointer(
					"School.LiveMain.LiveConnectControlModel",
					"get_IsLoading",
					0
				)
			);
		if (!lviWithArchiveControlPlay ||
			!lviWithArchiveControlPause) {
			withArchivePlayPauseButton = false;
			NSLog(
				@"[LinkuraVisualsIOS][WithArchivePlayPause] Existing "
				 "Play/Pause endpoints are unavailable; button remains "
				 "disabled."
			);
		}
	}
	if (withArchiveMotionReplay ||
		withArchiveOrientationRepair ||
		withArchiveRenderImageCoverSuppression ||
		withArchiveIarcFullSeek ||
		withArchivePlayPauseButton ||
		fesArchiveSeekBar) {
		lviWithMeetsArchiveSeekBarAdapterReady = findMethodAndHook(
			"School.LiveMain.VideoArchiveSeekBarPresenter",
			"School.LiveMain.ILiveSystemPresenter.Initialize",
			1,
			(void*)hooked_VideoArchiveSeekBarPresenter_Initialize,
			(void**)&original_VideoArchiveSeekBarPresenter_Initialize
		);
		if (!lviWithMeetsArchiveSeekBarAdapterReady) {
			NSLog(
				@"[LinkuraVisualsIOS][ArchiveSeekBar] Stock seek-bar "
				 "adapter is unavailable; playback remains usable without it."
			);
		}
	}
	bool seekLimitHookNeeded = withArchiveIarcFullSeek;
#if LVI_WM_DIAGNOSTIC
	seekLimitHookNeeded = true;
#endif
	bool seekLimitHookReady = false;
	if (seekLimitHookNeeded) {
		seekLimitHookReady = installLVIWithArchiveSeekLimitHook();
		if (!seekLimitHookReady) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] Archive seek-limit "
				 "hook is unavailable; stock IARC seek range remains."
			);
		}
	}
	bool playableLengthHookNeeded = withArchiveIarcFullSeek;
#if LVI_WM_DIAGNOSTIC
	playableLengthHookNeeded = true;
#endif
	bool playableLengthHookReady = false;
	if (playableLengthHookNeeded) {
		playableLengthHookReady =
			installLVIWithArchivePlayableLengthHook();
		if (!playableLengthHookReady) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] Playable-length "
				 "hook is unavailable; stock WM end state remains."
			);
		}
	}
	bool replayOverlayHookNeeded =
		withArchiveReplayOverlaySuppression;
#if LVI_WM_DIAGNOSTIC
	replayOverlayHookNeeded = true;
#endif
	if (replayOverlayHookNeeded) {
		bool replayOverlayHookReady =
			installLVIWithArchiveReplayOverlayHook();
		if (!replayOverlayHookReady) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] REPLAY overlay "
				 "suppression is unavailable; stock overlay remains."
			);
		}
	}
#if LVI_WM_DIAGNOSTIC
	installLVIWMClockDiagnosticHooks(
		seekLimitHookReady,
		playableLengthHookReady
	);
	if (!withArchiveSelectorNeeded) {
		lviWriteWMDiagnostic(@{
			@"stage": @"selector-hook-install",
			@"attempted": @false,
			@"installed": @false,
			@"originalAvailable": @false
		});
	}
#endif

	if (withMeetsValidAfterRepair) {
		// The archive-list response is the entitlement source shown by the
		// list's stars. Capture it only after the stock view-model methods
		// return, then bind the selected ArchivesId at the exact detail-request
		// constructor. The selector may correct only the resulting one-shot
		// detail response.
		bool archiveListCreateReady = findMethodAndHook(
			"Tecotec.SchoolConnectArchiveListViewModel",
			"CreateArchiveList",
			2,
			(void*)hooked_SchoolConnectArchiveListViewModel_CreateArchiveList,
			(void**)&original_SchoolConnectArchiveListViewModel_CreateArchiveList
		);
		bool archiveListAddReady = findMethodAndHook(
			"Tecotec.SchoolConnectArchiveListViewModel",
			"AddToArchiveList",
			2,
			(void*)hooked_SchoolConnectArchiveListViewModel_AddToArchiveList,
			(void**)&original_SchoolConnectArchiveListViewModel_AddToArchiveList
		);
		bool archiveRequestReady = findMethodAndHook(
			"Org.OpenAPITools.Model.GetWithArchiveDataRequest",
			".ctor",
			1,
			(void*)hooked_GetWithArchiveDataRequest_ctor,
			(void**)&original_GetWithArchiveDataRequest_ctor
		);
		bool playerFactoryReady = findMethodAndHook(
			"School.LiveMain.WithConnectModelsFactory",
			"School.LiveMain.ILiveSystemModelsFactory.CreateOwnGiftPointModel",
			0,
			(void*)
				hooked_WithConnectModelsFactory_CreateOwnGiftPointModel,
			(void**)
				&original_WithConnectModelsFactory_CreateOwnGiftPointModel
		);
		bool playerModelReady = findMethodAndHook(
			"School.LiveMain.GiftPointModel",
			".ctor",
			6,
			(void*)hooked_GiftPointModel_ctor,
			(void**)&original_GiftPointModel_ctor
		);
#if LVI_WM_DIAGNOSTIC
		bool chapterAdmissionDiagnosticReady = findMethodAndHook(
			"School.LiveMain.LiveConnectChapterModel",
			"SetExtraAdmission",
			1,
			(void*)hooked_LiveConnectChapterModel_SetExtraAdmission,
			(void**)&original_LiveConnectChapterModel_SetExtraAdmission
		);
#endif
		bool ready =
			lviWithArchiveSelectorReady &&
			original_WithArchiveContentTypeSelector_Execute != nullptr &&
			archiveListCreateReady &&
			original_SchoolConnectArchiveListViewModel_CreateArchiveList !=
				nullptr &&
			archiveListAddReady &&
			original_SchoolConnectArchiveListViewModel_AddToArchiveList !=
				nullptr &&
			archiveRequestReady &&
			original_GetWithArchiveDataRequest_ctor != nullptr &&
			playerFactoryReady &&
			original_WithConnectModelsFactory_CreateOwnGiftPointModel !=
				nullptr &&
			playerModelReady &&
			original_GiftPointModel_ctor != nullptr;
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-hook-install", @{
			@"enabled": @true,
			@"selectorHookInstalled": @(lviWithArchiveSelectorReady),
			@"selectorOriginalAvailable": @(
				original_WithArchiveContentTypeSelector_Execute != nullptr
			),
			@"listCreateHookInstalled": @(archiveListCreateReady),
			@"listCreateOriginalAvailable": @(
				original_SchoolConnectArchiveListViewModel_CreateArchiveList !=
					nullptr
			),
			@"listAddHookInstalled": @(archiveListAddReady),
			@"listAddOriginalAvailable": @(
				original_SchoolConnectArchiveListViewModel_AddToArchiveList !=
					nullptr
			),
			@"requestConstructorHookInstalled": @(archiveRequestReady),
			@"requestConstructorOriginalAvailable": @(
				original_GetWithArchiveDataRequest_ctor != nullptr
			),
			@"playerFactoryHookInstalled": @(playerFactoryReady),
			@"playerFactoryOriginalAvailable": @(
				original_WithConnectModelsFactory_CreateOwnGiftPointModel !=
					nullptr
			),
			@"playerModelConstructorHookInstalled": @(playerModelReady),
			@"playerModelConstructorOriginalAvailable": @(
				original_GiftPointModel_ctor != nullptr
			),
			@"chapterAdmissionDiagnosticHookInstalled":
				@(chapterAdmissionDiagnosticReady),
			@"chapterAdmissionDiagnosticOriginalAvailable": @(
				original_LiveConnectChapterModel_SetExtraAdmission != nullptr
			),
			@"pipelineReady": @(ready)
		});
#endif
		lviWithMeetsValidAfterRepairReady.store(
			ready,
			std::memory_order_release
		);
		if (!ready) {
			lviClearWithMeetsAfterEvidence();
			NSLog(
				@"[LinkuraVisualsIOS][WithAfter] Admission repair is "
				 "incomplete; all corrections remain disabled."
			);
		}
	} else {
#if LVI_WM_DIAGNOSTIC
		lviWriteAfterDiagnostic(@"after-hook-install", @{
			@"enabled": @false,
			@"chapterAdmissionDiagnosticHookInstalled": @false,
			@"chapterAdmissionDiagnosticOriginalAvailable": @false,
			@"pipelineReady": @false
		});
#endif
		lviWithMeetsValidAfterRepairReady.store(
			false,
			std::memory_order_release
		);
		lviClearWithMeetsAfterEvidence();
	}

	if (configBool(@"ActivityRecord.CameraControl.Enable") ||
		configBool(@"WithMeets.CameraControl.Enable") ||
		configBool(@"FesArchive.CameraControl.Enable")) {
		installLVICameraControlHooks();
	}
	if ((withArchiveOrientationRepair ||
		 withArchiveRenderImageCoverSuppression) &&
		!original_LiveConnectMrsPlayerPresenter_Initialize) {
		bool orientationInitializeHookReady = findMethodAndHook(
			"School.LiveMain.LiveConnectMrsPlayerPresenter",
			"Initialize",
			1,
			(void*)hooked_LiveConnectMrsPlayerPresenter_Initialize,
			(void**)&original_LiveConnectMrsPlayerPresenter_Initialize
		);
		if (!orientationInitializeHookReady) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchiveOrientation] "
				 "LiveConnectMrsPlayerPresenter.Initialize hook is "
				 "unavailable; IARC activation will rely on the "
				 "seek-bar presenter."
			);
		}
	}
	if ((withArchiveOrientationRepair ||
		 withArchiveRenderImageCoverSuppression ||
		 withArchiveIarcFullSeek ||
		 withArchivePlayPauseButton) &&
		!original_LiveSystemModels_Dispose) {
		bool orientationDisposeHookReady = findMethodAndHook(
			"School.LiveMain.LiveSystemModels",
			"Dispose",
			0,
			(void*)hooked_LiveSystemModels_Dispose,
			(void**)&original_LiveSystemModels_Dispose
		);
		if (!orientationDisposeHookReady) {
			NSLog(
				@"[LinkuraVisualsIOS][WithArchive] "
				 "LiveSystemModels.Dispose hook is unavailable; "
				 "session cleanup will rely on the next initializer."
			);
		}
	}

	if ([qualityConfig[@"Enable.QuestLive.NoParticlesHook"] boolValue]) {
		// Tecotec.QuestLive.Live.QuestLiveHeartObject.PlayParticles
		findMethodAndHook(
			"Tecotec.QuestLive.Live.QuestLiveHeartObject",
			"PlayParticles",
			0,
			(void*)hooked_QuestLiveHeartObject_PlayParticles,
			(void**)&original_QuestLiveHeartObject_PlayParticles
		);
	}

	if ([qualityConfig[@"Enable.QuestLive.NoThrowAndWaitHook"] boolValue] &&
		((app_version_major == 4 && app_version_minor == 11 && app_version_patch >= 1) ||
		 (app_version_major == 4 && app_version_minor > 11) ||
		 app_version_major > 4)) {
		// Tecotec.TPopupQuestLiveSettings.SetHeartShowLimitValue(int32_t value, bool playSe)
		findMethodAndHook(
			"Tecotec.TPopupQuestLiveSettings",
			"SetHeartShowLimitValue",
			2,
			(void*)hooked_TPopupQuestLiveSettings_SetHeartShowLimitValue,
			(void**)&original_TPopupQuestLiveSettings_SetHeartShowLimitValue
		);
	} else if ([qualityConfig[@"Enable.QuestLive.NoThrowAndWaitHook"] boolValue]) {
		// Tecotec.QuestLive.Live.QuestLiveHeartObject.ShowHeart(bool show)
		findMethodAndHook(
			"Tecotec.QuestLive.Live.QuestLiveHeartObject",
			"ShowHeart",
			1,
			(void*)hooked_QuestLiveHeartObject_ShowHeart,
			(void**)&original_QuestLiveHeartObject_ShowHeart
		);
	}

	if ([qualityConfig[@"Enable.QuestLive.NoCutinCharacterHook"] boolValue]) {
		// Tecotec.QuestLive.Live.QuestLiveCutinCharacter.PlaySkillAnimation()
		findMethodAndHook(
			"Tecotec.QuestLive.Live.QuestLiveCutinCharacter",
			"PlaySkillAnimation",
			0,
			(void*)hooked_QuestLiveCutinCharacter_PlaySkillAnimation,
			(void**)&original_QuestLiveCutinCharacter_PlaySkillAnimation
		);
	}

	if ([qualityConfig[@"Enable.LiveStreamQualityHook"] boolValue]) {
		findMethodAndHook(
			"School.LiveMain.SchoolResolution",
			"GetResolution",
			2,
			(void*)hooked_GetResolution,
			(void**)&original_GetResolution
		);

		// Inspix.AlphaBlendCamera.UpdateAlpha(float newAlpha)
		findMethodAndHook(
			"Inspix.AlphaBlendCamera",
			"UpdateAlpha",
			1,
			(void*)hooked_AlphaBlendCamera_UpdateAlpha,
			(void**)&original_AlphaBlendCamera_UpdateAlpha
		);
	}

	if ([qualityConfig[@"Enable.FrameRateHook"] boolValue]) { 
		findMethodAndHook(
			"UnityEngine.Application",
			"set_targetFrameRate",
			1,
			(void*)hooked_set_targetFrameRate,
			(void**)&original_set_targetFrameRate
		);
	}

	if ([qualityConfig[@"Enable.LiveStreamQualityHook"] boolValue] &&
		[qualityConfig[@"Enable.StoryQualityHook"] boolValue]) {
		if (Unity2022_3_62F) {
			findMethodAndHook(
				"Tecotec.FesLiveSettingsView",
				"Initialize",
				0,
				(void*)hooked_FesLiveSettingsView_InitButtons,
				(void**)&original_FesLiveSettingsView_InitButtons
			);
		} else {
			findMethodAndHook(
				"Tecotec.FesLiveSettingsView",
				"InitButtons",
				0,
				(void*)hooked_FesLiveSettingsView_InitButtons,
				(void**)&original_FesLiveSettingsView_InitButtons
			);
		}
	}

	if ([qualityConfig[@"Enable.AntiAliasingHook"] boolValue]) {
		findMethodAndHook(
			"UnityEngine.QualitySettings",
			"set_antiAliasing",
			1,
			(void*)hooked_set_antiAliasing,
			(void**)&original_set_antiAliasing
		);
	}

	if ([qualityConfig[@"Enable.MagicaClothHook"] boolValue]) {
		findMethodAndHook(
			"MagicaCloth2.MagicaManager",
			"SetSimulationFrequency",
			1,
			(void*)hooked_MagicaManager_SetSimulationFrequency,
			(void**)&original_MagicaManager_SetSimulationFrequency
		);

		findMethodAndHook(
			"MagicaCloth2.MagicaManager",
			"SetMaxSimulationCountPerFrame",
			1,
			(void*)hooked_MagicaManager_SetMaxSimulationCountPerFrame,
			(void**)&original_MagicaManager_SetMaxSimulationCountPerFrame
		);
	}

	if ([qualityConfig[@"Enable.StoryQualityHook"] boolValue]) {
		if (!Unity2022_3_62F) {
			findMethodAndHook(
				"UnityEngine.Rendering.Universal.UniversalRenderPipeline",
				"CreateRenderTextureDescriptor",
				6,
				(void*)hooked_CreateRenderTextureDescriptor,
				(void**)&original_CreateRenderTextureDescriptor
			);
		} else {
			// void UnityEngine.Rendering.Universal.UniversalRenderPipeline.InitializeStackedCameraData(Camera* camera, UniversalAdditionalCameraData* additionalCameraData, CameraData* cameraData)
			findMethodAndHook(
				"UnityEngine.Rendering.Universal.UniversalRenderPipeline",
				"InitializeStackedCameraData",
				3,
				(void*)hooked_InitializeStackedCameraData,
				(void**)&original_InitializeStackedCameraData
			);
		}
	}

	if ([qualityConfig[@"Enable.FesCameraHook"] boolValue] &&
		!original_fesLiveFixedCameraCtor) {
		findMethodAndHook(
			"School.LiveMain.FesLiveFixedCamera",
			".ctor",
			4,
			(void*)hooked_fesLiveFixedCameraCtor,
			(void**)&original_fesLiveFixedCameraCtor
		);
	}

	if ([qualityConfig[@"Enable.FesCameraHook"] boolValue] &&
		!original_idolTargetingCamera) {
		findMethodAndHook(
			"School.LiveMain.IdolTargetingCamera",
			".ctor",
			3,
			(void*)hooked_idolTargetingCamera,
			(void**)&original_idolTargetingCamera
		);
	}

	if (configBool(@"FesArchive.MotionCaptureReplay.Enable")) {
		bool fesArchiveResponseCacheReady = findMethodAndHook(
			"School.LiveMain.FesArchiveEnterResponseCache",
			".ctor",
			1,
			(void*)hooked_FesArchiveEnterResponseCache_ctor,
			(void**)&original_FesArchiveEnterResponseCache_ctor
		);
		if (!fesArchiveResponseCacheReady ||
			!original_FesArchiveEnterResponseCache_ctor) {
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Response-cache "
				 "constructor hook is unavailable; keeping every Fes "
				 "archive on its stock route."
			);
		}
	}

	if (configBool(@"FesArchive.ValidTicketRepair.Enable")) {
		void *explicitFactory =
			IL2CPP::Class::Utils::GetMethodPointer(
				"School.LiveMain.FesConnectModelsFactory",
				"School.LiveMain.ILiveSystemModelsFactory.CreateCameraSelectModel",
				0
			);
		void *directFactory =
			IL2CPP::Class::Utils::GetMethodPointer(
				"School.LiveMain.FesConnectModelsFactory",
				"CreateCameraSelectModel",
				0
			);
		bool explicitFactoryReady = false;
		bool directFactoryReady = false;
		if (explicitFactory) {
			MSHookFunction_p(
				explicitFactory,
				(void*)hooked_FesConnectModelsFactory_CreateCameraSelectModel,
				(void**)&original_FesConnectModelsFactory_CreateCameraSelectModel
			);
			explicitFactoryReady =
				original_FesConnectModelsFactory_CreateCameraSelectModel != nullptr;
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Hooked the explicit "
				 "CreateCameraSelectModel entry point."
			);
		}
		if (directFactory && directFactory != explicitFactory) {
			MSHookFunction_p(
				directFactory,
				(void*)hooked_FesConnectModelsFactory_CreateCameraSelectModelDirect,
				(void**)&original_FesConnectModelsFactory_CreateCameraSelectModelDirect
			);
			directFactoryReady =
				original_FesConnectModelsFactory_CreateCameraSelectModelDirect !=
				nullptr;
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Hooked the direct "
				 "CreateCameraSelectModel entry point."
			);
		} else if (directFactory && directFactory == explicitFactory) {
			directFactoryReady = explicitFactoryReady;
		}
		bool cameraSelectCtorReady = findMethodAndHook(
			"School.LiveMain.CameraSelectModel",
			".ctor",
			7,
			(void*)hooked_CameraSelectModel_ctor,
			(void**)&original_CameraSelectModel_ctor
		);
		if ((!explicitFactoryReady && !directFactoryReady) ||
			!cameraSelectCtorReady ||
			!original_CameraSelectModel_ctor) {
			NSLog(
				@"[LinkuraVisualsIOS][FesArchive] Valid-ticket repair "
				 "pipeline is incomplete; corrections remain fail-closed."
			);
		}
	}

	if ([qualityConfig[@"Enable.NoOrientationHook"] boolValue]) {
		// Inspix.PlayerGameViewUtilsImpl.SetPortraitImpl()
		findMethodAndHook(
			"Inspix.PlayerGameViewUtilsImpl",
			"SetPortraitImpl",
			0,
			(void*)hooked_PlayerGameViewUtilsImpl_SetPortraitImpl,
			(void**)&original_PlayerGameViewUtilsImpl_SetPortraitImpl
		);

		// Inspix.PlayerGameViewUtilsImpl.SetLandscapeImpl()
		findMethodAndHook(
			"Inspix.PlayerGameViewUtilsImpl",
			"SetLandscapeImpl",
			0,
			(void*)hooked_PlayerGameViewUtilsImpl_SetLandscapeImpl,
			(void**)&original_PlayerGameViewUtilsImpl_SetLandscapeImpl
		);

		// Inspix.PlayerGameViewUtilsImpl.CurrentOrientationIsImpl(int deviceOrientation)
		findMethodAndHook(
			"Inspix.PlayerGameViewUtilsImpl",
			"CurrentOrientationIsImpl",
			1,
			(void*)hooked_PlayerGameViewUtilsImpl_CurrentOrientationIsImpl,
			(void**)&original_PlayerGameViewUtilsImpl_CurrentOrientationIsImpl
		);
	}

	if ([qualityConfig[@"Enable.LandscapePopupSizeFixHook"] boolValue]) {
		// Inspix.LiveMain.BasePopup.OpenAsync()
		findMethodAndHook(
			"Inspix.LiveMain.BasePopup",
			"OpenAsync",
			0,
			(void*)hooked_LiveMain_BasePopup_OpenAsync,
			(void**)&original_LiveMain_BasePopup_OpenAsync
		);
	}

	if (configBool(@"ActivityRecord.HideBackground") ||
		configBool(@"ActivityRecord.HideTransition") ||
		configBool(@"ActivityRecord.HideNonCharacter3D") ||
		configBool(@"ActivityRecord.HideDepthOfField") ||
		configBool(@"ActivityRecord.HidePresetEffect")) {
		findMethodAndHook(
			"Tecotec.StoryScene",
			"LoadStoryData",
			1,
			(void*)hooked_StoryScene_LoadStoryData,
			(void**)&original_StoryScene_LoadStoryData
		);
	}

	if ([qualityConfig[@"Story.Utils.AutoCloseSubtitle.Enable"] boolValue] || [qualityConfig[@"Story.Utils.Novel.OpenWithAuto.Enable"] boolValue]) {
		// Tecotec.StoryUIWindow.Setup(bool skipReturn, int skipLine, float timesec, bool seekbar)
		findMethodAndHook(
			"Tecotec.StoryUIWindow",
			"Setup",
			4,
			(void*)hooked_StoryUIWindow_Setup,
			(void**)&original_StoryUIWindow_Setup
		);
	}

	if ([qualityConfig[@"Story.Utils.Novel.Advanced.Enable"] boolValue]) {
		// void School.Story.NovelView.Initialize(Camera storySpaceCamera)
		findMethodAndHook(
			"School.Story.NovelView",
			"Initialize",
			1,
			(void*)hooked_NovelView_Initialize,
			(void**)&original_NovelView_Initialize
		);

		// float Tecotec.AddNovelTextCommand.GetDisplayTime(StoryMnemonic mnemonic)
		findMethodAndHook(
			"Tecotec.AddNovelTextCommand",
			"GetDisplayTime",
			1,
			(void*)hooked_AddNovelTextCommand_GetDisplayTime,
			(void**)&original_AddNovelTextCommand_GetDisplayTime
		);
	}

	return result;
}

void WaitForSymbolAndHook() {
    Class targetClass = NULL;
	
    int maxAttempts = 20;
    int attempts = 0;

    while ((targetClass == NULL || !MSHookFunction_p) && attempts < maxAttempts) {
        targetClass = NSClassFromString(@"UnityAppController");
		if (!MSHookFunction_p) {
			if (has_txm()) {
				MSHookFunction_p = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "DobbyHook");
			} else {
				MSHookFunction_p = (MSHookFunction_t)dlsym(RTLD_DEFAULT, "MSHookFunction");
			}
		}
		
        if (targetClass == NULL || !MSHookFunction_p) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            attempts++;
            NSLog(@"[IL2CPP Tweak] Attempt %d", attempts);
        }
    }

    if (targetClass == NULL) {
        NSLog(@"[IL2CPP Tweak] Failed to find UnityAppController.");
        return;
    } else {
		NSLog(@"[IL2CPP Tweak] Found UnityAppController.");
	}
	if (!MSHookFunction_p) {
        NSLog(@"[IL2CPP Tweak] Failed to find MSHookFunction.");
        return;
    } else {
        NSLog(@"[IL2CPP Tweak] Found MSHookFunction.");
    }

    MSHookMessageEx_p(
        targetClass,
        @selector(application:didFinishLaunchingWithOptions:),
        (IMP)hooked_didFinishLaunchingWithOptions,
        (IMP *)&original_didFinishLaunchingWithOptions
    );
}

__attribute__((constructor))
static void tweakConstructor() {

    NSLog(@"[LinkuraVisualsIOS] Loaded.");

    MSHookMessageEx_p = (MSHookMessageEx_t)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
    if (!MSHookMessageEx_p) {
        NSLog(@"[IL2CPP Tweak] Failed to find MSHookMessageEx.");
        return;
    } else {
        NSLog(@"[IL2CPP Tweak] Found MSHookMessageEx.");
    }

	qualityConfig = [NSMutableDictionary dictionaryWithObjectsAndKeys:
			@"5.0.1", @"Compatibility.BinaryVersion",
		@720, @"LiveStream.Quality.Low.ShortSide",
		@1080, @"LiveStream.Quality.Medium.ShortSide",
		@1440, @"LiveStream.Quality.High.ShortSide",
		@0.6f, @"Story.Quality.Low.Factor",
		@1.0f, @"Story.Quality.Medium.Factor",
		@1.4f, @"Story.Quality.High.Factor",
		@false, @"Story.Quality.FSRUpscaling.Enable",
		@false, @"Story.Utils.AutoCloseSubtitle.Enable",
		@false, @"Story.Utils.Novel.OpenWithAuto.Enable",
		@1, @"Story.Utils.Novel.WaitInterval",
		@1, @"Story.Utils.Novel.TextDisplaySpeed",
		@false, @"Story.Utils.Novel.Advanced.Enable",
		@1.0, @"Story.Utils.Novel.TextDisplayAniSpeed",
		@0.06, @"Story.Utils.Novel.TextDisplayTime",
		@0.0, @"Story.Utils.Novel.VoiceTextExtend",
		@0.0, @"Story.Utils.Novel.PlainTextExtend",
		@false, @"ActivityRecord.HideBackground",
		@false, @"ActivityRecord.HideTransition",
		@false, @"ActivityRecord.HideNonCharacter3D",
		@false, @"ActivityRecord.HideDepthOfField",
		@false, @"ActivityRecord.HidePresetEffect",
		@false, @"ActivityRecord.CameraControl.Enable",
		@false, @"WithMeets.CameraControl.Enable",
		@false, @"WithMeets.Archive.MotionCaptureReplay.Enable",
		@false, @"WithMeets.Archive.IarcFullSeek.Enable",
		@true, @"WithMeets.Archive.IarcReplayOverlay.Suppress",
		@true, @"WithMeets.Archive.OrientationRepair.Enable",
		@5.0f, @"WithMeets.Archive.OrientationRepair.RebindGraceSeconds",
		@false, @"WithMeets.After.ValidAdmissionRepair.Enable",
		@true, @"CameraControl.UI.Enable",
		@true, @"CameraControl.UI.ScreenshotHide.Enable",
		@0.15f, @"CameraControl.MoveStep",
		@3.0f, @"CameraControl.RotateStepDegrees",
		@2.0f, @"CameraControl.PerspectiveZoomStep",
		@10.0f, @"CameraControl.PerspectiveZoomMinimum",
		@100.0f, @"CameraControl.PerspectiveZoomMaximum",
		@0.5f, @"CameraControl.OrthographicZoomStep",
		@0.5f, @"CameraControl.OrthographicZoomMinimum",
			@30.0f, @"CameraControl.OrthographicZoomMaximum",
			@false, @"FesArchive.CameraControl.Enable",
			@false, @"FesArchive.SeekBar.Enable",
			@false, @"FesArchive.MotionCaptureReplay.Enable",
			@{}, @"FesArchive.MotionCaptureReplay.UrlMap",
			@false, @"FesArchive.ValidTicketRepair.Enable",
			@6, @"FesArchive.ValidTicketRepair.TicketRank",
			@[@1, @2, @3, @4], @"FesArchive.ValidTicketRepair.SelectableCameraTypes",
			@[
				@"af23d18c-ba54-41cd-b69e-af391744a6e9",
				@"8ccceeea-2c46-4ecd-a57d-703376ac5c81"
			], @"FesArchive.ValidTicketRepair.TargetArchiveIds",
			@60, @"MagicaCloth.SimulationFrequency",
		@3, @"MagicaCloth.MaxSimulationCountPerFrame",
		@60, @"TargetFPS",
		@4, @"AntiAliasingSamples",
		@true, @"Enable.LiveStreamQualityHook",
		@true, @"Enable.StoryQualityHook",
		@true, @"Enable.MagicaClothHook",
		@true, @"Enable.FesCameraHook",
		@true, @"Enable.FrameRateHook",
		@true, @"Enable.AntiAliasingHook",
		@false, @"Enable.QuestLive.NoParticlesHook",
		@false, @"Enable.QuestLive.NoThrowAndWaitHook",
		@false, @"Enable.QuestLive.NoCutinCharacterHook",
		@false, @"Enable.NoOrientationHook",
		@false, @"Enable.LandscapePopupSizeFixHook",
		nil
	];

	if ([UIDevice currentDevice].userInterfaceIdiom > 0) {
		[qualityConfig setObject:@true forKey:@"Enable.NoOrientationHook"];
		[qualityConfig setObject:@true forKey:@"Enable.LandscapePopupSizeFixHook"];
		NSLog(@"[IL2CPP Tweak] Running on device can be landscape");
	}

	loadConfig();

#if LVI_WM_DIAGNOSTIC
	lviWriteWMDiagnostic(@{
		@"stage": @"run-start",
		@"diagnosticVersion": @2,
		@"motionReplayEnabled": @(
			configBool(@"WithMeets.Archive.MotionCaptureReplay.Enable")
		),
		@"iarcFullSeekEnabled": @(
			lviWithArchiveIarcFullSeekEnabled()
		),
		@"iarcReplayOverlaySuppressionEnabled": @(
			lviWithArchiveIarcReplayOverlaySuppressionEnabled()
		),
		@"afterRepairCompiled": @(LVI_WITH_AFTER_REPAIR != 0),
		@"afterRepairEnabled": @(
			lviWithMeetsValidAfterRepairEnabled()
		)
	}, true);
#endif

    std::thread hook_thread(WaitForSymbolAndHook);
    hook_thread.detach();
}
