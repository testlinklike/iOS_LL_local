#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
VERSION="0.8.7"
NAME="LinkuraVisualsIOS-${VERSION}-unified-camera-ui-hide"
DYLIB="${ROOT}/build/LinkuraVisualsIOS.dylib"
DIST="${ROOT}/dist"
ARCHIVE="${DIST}/${NAME}.zip"
STANDALONE="${DIST}/${NAME}.dylib"
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/linkura-visuals-release.XXXXXX")"

cleanup() {
  rm -rf "${STAGE}"
}
trap cleanup EXIT

[[ -f "${DYLIB}" ]] || {
  print -u2 "Missing build artifact: ${DYLIB}"
  exit 1
}

# Refuse to package a stale, unsigned, single-slice, feature-incomplete, or
# metadata-mismatched build even when this script is invoked directly.
"${ROOT}/verify_build.sh"

if [[ -e "${ARCHIVE}" || -e "${STANDALONE}" ]]; then
  print -u2 "Refusing to overwrite existing release:"
  print -u2 "  ${ARCHIVE}"
  print -u2 "  ${STANDALONE}"
  exit 1
fi

mkdir -p "${DIST}" "${STAGE}/${NAME}/Install" "${STAGE}/${NAME}/Source"

cp "${DYLIB}" "${STAGE}/${NAME}/Install/"
cp "${ROOT}/LinkuraVisualsIOS.json" "${STAGE}/${NAME}/Install/"
cp "${ROOT}/IL2CPP_OFFSETS_5.0.1.json" "${STAGE}/${NAME}/Install/"

cp "${ROOT}/README_JA.md" "${STAGE}/${NAME}/"
cp "${ROOT}/NOTICE.md" "${STAGE}/${NAME}/"
cp "${ROOT}/LICENSE-AGPL-3.0" "${STAGE}/${NAME}/"
cp "${ROOT}/LICENSE-MIT-UPSTREAM" "${STAGE}/${NAME}/"

rsync -a \
  --exclude '.DS_Store' \
  --exclude 'build' \
  --exclude 'dist' \
  "${ROOT}/" "${STAGE}/${NAME}/Source/"

(
  cd "${STAGE}/${NAME}"
  {
    shasum -a 256 Install/LinkuraVisualsIOS.dylib
    shasum -a 256 Install/LinkuraVisualsIOS.json
    shasum -a 256 Install/IL2CPP_OFFSETS_5.0.1.json
  } > SHA256SUMS
)

(
  cd "${STAGE}"
  COPYFILE_DISABLE=1 /usr/bin/zip -q -r -X "${ARCHIVE}" "${NAME}"
)

cp "${DYLIB}" "${STANDALONE}"

print "Packaged: ${ARCHIVE}"
/usr/bin/shasum -a 256 "${ARCHIVE}"
print "Standalone: ${STANDALONE}"
/usr/bin/shasum -a 256 "${STANDALONE}"
